# AI API Testing Platform — Diagram prompts

One prompt per diagram, in pack order. Each prompt is self-contained: paste it alone into Lucidchart AI, draw.io (Generate diagram), Miro AI, or any LLM that emits draw.io XML / Mermaid / Lucid text.

**How to use**
1. Paste the *Common conventions* block first (or include it at the top of the prompt you paste — every prompt below already references it).
2. Paste the prompt for the page you want.
3. If the tool truncates, ask it to "continue from column C" (or whichever section stopped).
4. Tools differ in how much text fits in a box; if a box overflows, shorten the bullet text — do not drop boxes or arrows.

---

## Common conventions (include with every prompt)

```
CONVENTIONS FOR THIS DIAGRAM
Canvas: landscape, about 1900 x 1100 px. Font: Inter / Segoe UI / Arial. Rounded rectangles, 8 px radius, thin 1.5 px borders.
Colours (fill / border):
  white box     #FFFFFF / #1F2937  = code that runs without AI (release 1 unless tagged)
  blue box      #EFF6FF / #2563EB  = AI is involved (release 2 or later; AI only drafts)
  green box     #ECFDF5 / #059669  = a human gate (a person approves / edits / rejects / dismisses)
  purple box    #F5F3FF / #7C3AED  = release 3 (triage, defects, reruns, dashboards)
  red box       #FEF2F2 / #DC2626  = secrets, or a stop
  amber box     #FFFBEB / #D97706  = a loop, or a status waiting for a person
  grey box      #F3F4F6 / #9CA3AF  = cross-cutting notes (runs on every request, deployment notes)
  lane/column background #FAFAFA with #9CA3AF border, 12 px radius
Tags: a small pill in the top-right corner of a box: "MVP" (grey), "R2" (blue), "R3" (purple) = the release the box ships in.
Shapes: numbered circle = a step (numbers match the "step by step" list); diamond = a human gate; small filled dot = start; ring with dot = end; dashed border = optional branch.
Arrows: 1.5 px, filled arrowhead; black = main path; blue = AI path; amber = loop; red dashed = stop; green = approval.
Text style: short plain-English bullets; monospace for file paths, table names, endpoints and status names.
Do not add anything not listed. Do not rename anything. Keep the reading order left to right, top to bottom.
```

---

## 1. End-to-end process flow (v4)

```
Use the CONVENTIONS above.
Title (top-left, bold 22 px): "AI API Testing Platform — End-to-end process flow"
Subtitle (grey): "Six phases · 24 steps · 5 human gates · 5 loops · 1 stop. Read left to right; each lane ends in the workflow state that lets the next lane start. AI proposes (blue), the QE decides (green), execution is deterministic."
Top-right small grey text: "release tags: MVP = no LLM on the critical path · R2 = AI graphs, Jira stories, Zephyr, CSV · R3 = triage, defects, rerun loop"

LAYOUT: six vertical lanes side by side, each 290 px wide with a light grey background. Each lane has a grey header box at the top (phase number, name, "in:" line), then up to five step boxes stacked vertically (82 px tall, 16 px gap), then a dashed "exit state" strip at the bottom aligned across all lanes.
Every step box shows: a numbered circle (or a diamond for gates) at top-left, the step title bold, an actor pill top-right (Platform / AI / QE gate / Zephyr / Jira / Runner / Platform + AI), two lines of grey description, and a release tag bottom-right.
Vertical black arrows connect consecutive steps in a lane. A black arrow leaves the last MAIN step of each lane from its right edge, runs up the gutter, and enters the first step of the next lane.

LANE 1 "1 Onboard" — in: OpenAPI 3 / Swagger 2, env config, credential profiles; optional: samples, Jira stories, CSV, existing suite, Kafka
  1  Ingest [Platform][MVP]: credentials → own endpoint → Secret Manager, first; normalize + lint spec; stable target key; DLP guard
  2a Smoke check [Platform][MVP]: safe endpoints only: connectivity, auth per profile, contract conformance; samples, CSV, Kafka checks
  2b Readiness gate ◆ [QE gate][MVP] (green): red blocks until inputs are fixed · yellow passes with an ack_reason · green auto-accepts
  Amber loop from 2b's left edge back into step 1, labelled "red: fix inputs, re-upload".
  Start dot to the left of step 1 labelled "QE creates a workflow".
  Exit state strip: spec_version.accepted — readiness report (green, or yellow with ack_reason)

LANE 2 "2 Understand" — in: accepted spec version
  3a Discover [Platform][MVP]: endpoint inventory, field catalog, dependency edges (explicit + heuristic), auth model, coverage universe
  3b Extract rules [AI][R2] (blue): business rules from Jira stories, each with its source sentence + confidence; PHI guard on text
  4  Rules review ◆ [QE gate][R2] (green): confirm / reject rules and low-confidence edges; add unwritten rules; decisions → few-shot feedback. Italic note: skipped when no stories
  Above the header, an amber pill with an arrow down into the header: "New spec version re-enters here · impacted targets only / unchanged cases keep approval; locked cases flagged stale"
  Exit state: api_model.confirmed — API model, versioned with the spec

LANE 3 "3 Design" — in: confirmed API model
  5a Test design [Platform][MVP]: rule engine: structural, status codes, schema, boundary, dependency, security → assertion DSL
  5b Cases for gaps [AI][R2] (blue): business-rule and semantic cases aimed only at the coverage gaps measured in 6
  6  Coverage + contract [Platform][MVP]: measure 7 dimensions; reject cases that break the contract; dedup; priority; confidence score
  7  QE approval ◆ [QE gate][MVP] (green): all P1 decided; bulk-approve high confidence only; low confidence one by one; QE lead accepts gaps
  8  Publish to Zephyr [Zephyr][R2] (grey, dashed border): optional per team; async + batched; upsert by case_id; approved P1 / P2 by default
  The arrow from 7 to 8 is grey dashed labelled "optional". The lane's exit arrow leaves from 7, not from 8.
  Amber loop from 6's left edge back into 5b, labelled "gaps → next round (≤ 3) · then review regardless".
  Exit state: suite.approved — canonical test cases + assertion DSL (source of truth)

LANE 4 "4 Build" — in: approved suite · CSV, samples, data catalog
  9a Test data [Platform][MVP]: base payload per target; one mutation per case; catalog bindings; runtime placeholders
  9b CSV mapping [AI][R2] (blue): column → field mapping; semantic values kept consistent across a scenario
  10 Data review ◆ [QE gate][R2] (green): blocked bindings list exactly what QA must add; unmatched cases run as blocked. Italic: only when a CSV was uploaded
  11 Scripts [Platform + AI][MVP · R2 AI] (blue): templates first; AI only for business flows, state transitions, Kafka; auto-repair ≤ 2
  12 Dry run [Platform][MVP · R2 mock]: parse + static + contract checks; mock run against Prism; commit to Git; locks respected
  Amber loop from 12's left edge back into 11, labelled "invalid → needs_attention · QE fixes or regenerates".
  Exit state: suite.ready — data sets + valid Karate project, committed to Git

LANE 5 "5 Run" — in: Karate project @ pinned commit, environment, trigger
  Above the header, a white pill with black border and an arrow down into the header: "Run triggers: manual · nightly · CI deploy · rerun · Jira webhook / scope p1 · full · defect:{key} · duplicates within 60 s coalesced"
  13 Pre-flight [Platform][MVP]: freeze window + concurrency → queue with position; tokens per profile; one safe call; allocate records
  Row 2 is a FORK, not a box: a black arrow labelled "green" goes straight down the left side of the lane from 13 to 14; a red dashed arrow labelled "any red" goes from 13's bottom-right into a red box in the right half of the row: "Stop: run.env_not_ready / notify QE + env owner once, not per case"
  14 Execute [Runner][MVP]: Kubernetes Job at pinned commit; parallel shards; rate-limited; retry network / 5xx once → flaky
  15 Results [Platform][MVP]: ingest summary; mask evidence in-pod; fingerprint failures; clean up created resources (ledger + sweeper)
  15b Zephyr cycle [Zephyr][R2] (grey, dashed): test cycle + executions per run, linked to evidence and the run report. Arrow 15→15b grey dashed "optional". Lane exit leaves from 15.
  Exit state: run.completed — immutable run record + masked evidence (→ synced)

LANE 6 "6 Close the loop" — in: run results + failure fingerprints
  16 Triage [Platform + AI][R3] (blue): signals first (env, data, drift, flaky); AI classifies the rest; cluster by root cause
  17 Defect review ◆ [QE gate][R3] (green): confirm, reclassify or dismiss category + defect draft; every decision feeds triage back
  18 Jira defect [Jira][R3] (grey dashed): dedup by fingerprint: open → comment occurrence; closed → new issue with regression_of link
  19 Report [Platform + AI][MVP · R3 AI] (blue): every number computed; AI writes the summary only; run, workflow, portfolio, readiness views
  A black bypass arrow from 16's right edge, down the right margin, into 19's top-right, labelled "always, from run.completed".
  Row 5: an amber pill "Loop: rerun on fix (R3) / Jira → ready-for-QA webhook → run scope defect:{key} / linked cases + same endpoint + dependency chain". An amber arrow leaves its bottom, runs below all the exit-state strips, and enters step 13 (lane 5) from the left, labelled on the horizontal run "result is commented on the Jira issue; the run record links the defect".
  End ring-with-dot to the right of 19 labelled "release decision".
  Exit state: triage.decided — defects in Jira, rerun evidence, report + dashboards

LEGEND (bottom row): white box "Deterministic (Platform / Runner)"; blue box "AI-assisted — drafts only, validated into a model or rejected"; green diamond "Human gate: approve · edit · reject(reason) · regenerate(comment)"; grey dashed box "Sync to an external system (optional branch)"; amber arrow "Loop"; red dashed arrow "Stop"; the three release pills "Release the step ships in".
Second legend line, italic: "a / b = the same stage: deterministic first, AI only for what rules cannot do. A gate's reject / regenerate returns to the step above it. Dashed grey boxes are optional and never on the main path."
```

---

## 2. Phase 1 · Onboard

```
Use the CONVENTIONS above.
Title: "Phase 1 · Onboard — what to build and how it works"
Two grey subtitle lines:
"What the user does: a QE (tester) creates a workflow for one API, adds the test environment and its login credentials, and uploads the API's OpenAPI spec."
"What the platform does: the API stores the upload and answers at once; a background worker cleans the spec, checks it, does a quick live check against the environment and writes a readiness report (green / yellow / red)."
Top-right small grey: "Phase 1 of 6 · Onboard · everything on this page is in the first release (MVP)" and "no AI and no test runner yet · two pod groups of the SAME image: platform-api (answers requests) and platform-worker (does the slow steps)"

THREE COLUMNS with light grey backgrounds, then a status strip, then four bottom panels.

COLUMN A (left, 340 px) "QE in the browser" — subtitle "Angular app · screens only, all logic is in the API". Six white cards, each with a numbered circle:
 ① Sign in — company single sign-on (OIDC); → GET /me returns the user's team + role
 ② Create workflow — a workflow = one API under test; → POST /workflows
 ③ Add environment — dev | qa | staging (never prod): base URL, concurrency, requests/sec, freeze windows; → POST /workflows/{id}/environments
 ④ Add credential profiles — a named login the tests will use (default, member_b …) · the secret is typed ONCE here; → POST /environments/{id}/credential-profiles
 ⑤ Upload spec — OpenAPI 3 or Swagger 2 · file or URL; optional: example payloads; → POST /workflows/{id}/spec-versions
 ⑦ Readiness report — green · yellow · red + findings list; yellow → user types a reason → POST …/accept; red → fix the inputs and upload again
 Footer italic: "live updates arrive on GET /events/stream (server-sent events)"
 A thick black double-headed arrow to column B labelled "REST + SSE / login token".

COLUMN B (middle, 800 px) "platform-api + platform-worker" — subtitle "one code base, one image · api pods answer HTTP in < 1 s · worker pods take jobs from a queue and run the slow steps · both use the same core/ and the same DB". Contents top to bottom:
 Grey strip "core/ — happens on every request, before the router code runs": 1 check the login token and look up the user's team and role  2 call authorize(user, action, entity) — no route without a permission  3 tell Postgres which team this is (so row-level security hides other teams' rows)  4 write an audit_event row on every status change  5 push live updates to the browser (SSE)  6 same POST twice = same result
 Label "api/ — routers", then four cards in a row:
   ② workflows.py: POST/GET /workflows · GET/PATCH/DELETE /workflows/{id}
   ③ environments.py: POST/GET /workflows/{id}/environments · PATCH /environments/{id}
   ④ credentials.py (RED): POST …/credential-profiles → {secret_ref} · GET (never returns values) · DELETE · …/verify · own file · request body is NEVER logged
   ⑤ spec_versions.py: POST /workflows/{id}/spec-versions → 202 (stores the file, queues a job, replies at once) · GET …/readiness · …/diff · POST …/accept
 Label "modules/intake/ — the Onboard module. The first step runs in an api pod; the worker runs the other six in order", then seven small chips connected by arrows:
   upload (white): save the raw file; create spec_version row status=uploaded; queue a job · API POD
   normalize (white): convert Swagger 2 to OpenAPI 3, resolve $ref; save the clean JSON · WORKER POD
   lint (white): find problems: missing operationId, schema, examples… → findings list
   target_key+diff (white): give each endpoint a stable id; compare with the previous version
   dlp_guard (purple): scan example payloads for real personal data; block or mask it
   smoke (blue): quick live check against the env, in the background (box below)
   readiness (green): decide green | yellow | red; save the report; notify the browser
   Italic under the chips: "suggested files, one per step: normalize.py · lint.py · target_key.py · diff.py · dlp.py · smoke/ · readiness.py (router.py · service.py · repository.py are required in every module)"
 Blue box ⑥ "smoke check — a quick live check of the environment, run by the worker once per uploaded spec (whole job < 60 s)": 1 fetch each credential profile's secret from Secret Manager (kept in memory only)  2 can we reach the environment's base URL over TLS (client certificate if the profile needs one)?  3 can we get a token / does the key work, for each profile?  4 call ONE read-only endpoint per profile  5 does that response match what the spec says it should look like?  6 if example payloads were uploaded: do they fit the spec's schemas?  Result: any blocking failure = red · warnings only = yellow · nothing found = green. Red text line: "Never call endpoints that change data, never touch production, never write a secret value into logs or the report. Make this a package of its own: Phase 5 pre-flight reuses it."
 Grey strip at the bottom "Where it runs (GKE): one image → platform-api Deployment (2–20 pods, Service + Ingress, scales on HTTP load) + platform-worker Deployment (1–N pods, no Service, scales on queue depth, long shutdown grace so a running job finishes). Both deploy together with the same image tag. The code never knows which pod it is in — the entrypoint decides."

COLUMN C (right, 560 px) "Stores and external systems" — subtitle "pods authenticate to Google Cloud with their service account (Workload Identity) — no keys in config". Boxes top to bottom, each with the step numbers it serves in the top-right:
 Cloud SQL · PostgreSQL 16 (white) ②③④⑤⑦⑧: team · team_member · api_key / workflow (name, status, current_spec_version_id) / environment (base_url, limits, freeze_windows, security_tests_allowed) / credential_profile (name, auth_type, scopes, secret_ref) ← the reference, never the value / spec_version (version, format, raw_uri, normalized_uri, lint, diff_from_previous, readiness, readiness_report, status) ← never updated; a change = a new row / audit_event · outbox · every table has team_id and a row-level security policy
 Cloud Storage · bucket inputs (white) ⑤: the raw upload, the cleaned-up spec (JSON), example payloads · versioned
 Secret Manager (RED) ④⑥: the ONLY place a secret value lives. credentials.py writes it once; the DB keeps just the address projects/{p}/secrets/{name}/versions/{v} (= secret_ref). Worker pods read it by that address.
 Sensitive Data Protection (DLP) (purple) ⑤: Google's scanner for personal data. Example payloads are scanned before they are stored; SSN or medical record numbers block the upload, other findings are masked
 Pub/Sub · topic platform-jobs (white) ⑤: the queue between api pods and worker pods. The api pod writes the job in the same DB transaction as the spec_version row (outbox table); a relay publishes it. A worker may get a job twice — skip duplicates.
 The API under test · dev / qa / staging (blue) ⑥: only the smoke check talks to it, only read-only endpoints; production is never reachable
 Arrows from column B's right edge to each store, labelled: "rows" (double-headed, to Cloud SQL), "⑤ files" (to Storage), "⑤ job" (double, to Pub/Sub), "④ write" red (to Secret Manager), "⑥ read" red dashed (to Secret Manager), "⑤ scan" purple dashed (to DLP), "⑥ call" blue dashed (to API under test).

STATUS STRIP (full width, dashed border) titled "orchestration/spec_version.py — the status a spec version moves through. Each arrow is one function: check it is allowed → write the new status → write an audit_event, all in one DB transaction". Pills left to right: uploaded → normalized ("cleaned and linted") → checking (blue; "smoke check starts") → fan-out to three pills stacked: ready · green (green, "no findings"), ready · yellow (amber, "warnings"), red (red, "blocking check failed") → green goes to accepted (green, "automatic"); yellow goes to accepted ("QE accepts and gives a reason"); red has a red dashed arrow back to uploaded ("never accepted: fix the inputs and upload again = a new version") → accepted → superseded (grey, "next version accepted"). Right of the strip: "Phase 2 (Understand) starts from accepted: it reads the cleaned spec + the endpoint ids".

BOTTOM PANELS (four, left to right):
 "How it works, step by step (numbers match the diagram)":
 ① The QE signs in with company single sign-on. The API checks the token and finds the user's team and role.
 ② POST /workflows creates the workflow row (one row per API under test).
 ③ POST /workflows/{id}/environments adds dev / qa / staging with base URL, rate limits and freeze windows.
 ④ POST /environments/{id}/credential-profiles: the request body carries the secret exactly once. Write it to Secret Manager, store only the returned address (secret_ref) in Postgres, return that address. POST …/verify fetches a token with it, so the user knows the login works before uploading anything.
 ⑤ POST /workflows/{id}/spec-versions (api pod): save the raw file, insert a new spec_version row (never overwrite the old one), write a job to the queue in the same transaction, reply 202 with the version id. A worker pod picks the job up: convert Swagger 2 to OpenAPI 3, lint, give every endpoint a stable id, compare with the previous version, scan example payloads for personal data.
 ⑥ Same worker job, smoke check: get secrets, reach the environment, get a token per profile, call one read-only endpoint, compare the response with the spec. Save the report and the colour.
 ⑦ Push a live update; the Readiness screen shows the colour, the lint findings, the endpoint list and the diff.
 ⑧ green: accepted automatically. yellow: the QE presses accept and types a reason (stored in audit_event). red: nothing can continue; the QE fixes the inputs and uploads again, which creates the next version.
 Bold: Result: a spec_version with status accepted. Phase 2 starts from it.

 "Build order — three chunks, each merged on its own":
 1 · Skeleton (before any Onboard feature): FastAPI app + worker entrypoint (same image) · Alembic · auth (SSO + API keys) · audit_event · outbox table + relay · queue consumer · row-level security policy on every table with a test · SSE endpoint · Helm chart with api + worker · CI
 2 · Teams, workflows, environments, credentials: the four routers on this page · Secret Manager client · authorize() with the role matrix (only a QE lead may delete a credential profile)
 3 · Spec ingest: upload · normalize · lint · endpoint ids + diff · DLP scan · smoke check · readiness
 Files you will create or touch: backend/apitest/api/{workflows,environments,credentials,spec_versions}.py · backend/apitest/modules/intake/{router,service,repository}.py + smoke/ · backend/apitest/orchestration/spec_version.py · alembic/versions/ · docs/openapi/platform.yaml (generated) · web/features/workflows/

 "Done when — and the rules you must not break" (green border):
 You are done when a QE can do this without help: ☐ create a team, a workflow, a QA environment and two credential profiles; the secret value appears nowhere in DB, logs or Git ☐ upload an OpenAPI 3 spec and a Swagger 2 spec; both convert; findings and endpoint ids are listed; report is green within 60 s ☐ upload a changed spec; the diff lists added, removed, changed endpoints ☐ a user from another team gets 404 for all of it — via the API and via SQL
 Rules: • credentials go to Secret Manager before anything else is stored • the DB, logs, code and prompts hold only the secret's address, never its value • every table has team_id + a row-level security policy • a spec version is never edited; a change is a new version • endpoint id = operationId if present, else METHOD + path with {} for params • every table row has an audit trail; every POST is safe to retry

 "Words you will see": api pod / worker pod — same image; api answers HTTP, worker runs queued jobs · outbox — a DB table of 'messages to send'; written with the data, published after · workflow — one API under test, with its environments, specs and tests · spec version — one uploaded copy of the API spec; version 1, 2, 3 … · target / endpoint id — one operation in the spec and its stable name · credential profile — a named login the tests will use (default, member_b …) · secret_ref — the address of a secret in Secret Manager, not the secret · readiness — green = go · yellow = go, warning acknowledged · red = stop · smoke check — a quick, read-only, live check that the environment works · row-level security (RLS) — Postgres hides rows of other teams automatically · Workload Identity — pods log in to Google Cloud as a service account, no key files · SSE — server-sent events; how the browser gets live updates without polling · audit_event — append-only table: who changed what, before and after
```

---

## 3. Phase 2 · Understand

```
Use the CONVENTIONS above. Same three-column + status strip + four panels layout as Phase 1.
Title: "Phase 2 · Understand — what to build and how it works"
Subtitles: "What the platform does: a worker pod reads the accepted spec and turns it into the API model — a list of endpoints, a catalog of every field, the dependencies between endpoints, and the 'coverage universe' (everything a test must cover)." / "What the user does: nothing in the first release except look. In release 2 a QE can attach Jira stories; AI proposes business rules from them and the QE confirms or rejects each one."
Top-right: "Phase 2 of 6 · Understand · input: spec_version.accepted from Phase 1" / "white = release 1 (MVP, no AI) · blue = release 2 (AI reads Jira stories) · same pods as Phase 1, plus ai-worker in R2"

COLUMN A "QE in the browser":
 ③ Discover view [MVP]: shows the API model for a spec version: endpoints · fields · dependencies (with confidence) · coverage universe; → GET /spec-versions/{v}/targets | fields | dependency-edges | coverage-universe
 ④ Confirm or reject a dependency [MVP]: a guessed edge can be confirmed or rejected; → PATCH /dependency-edges/{id}
 ⑤ Attach Jira stories [R2, blue]: by story ids, an epic, or a JQL query; → POST /spec-versions/{v}/stories (starts the AI rules job, returns 202)
 ⑧ Rules review [R2, blue]: each proposed rule with its source sentence and confidence: confirm · edit · reject; add a rule the stories never wrote down; → PATCH /business-rules/{id}; → POST /spec-versions/{v}/rules/confirm
 Footer: "live updates arrive on GET /events/stream (job.updated)"

COLUMN B "platform-api + platform-worker (+ ai-worker in R2)" — subtitle "same image and pods as Phase 1 · api pods serve the screens; the worker pod runs Discover · same core/ checks on every request":
 Grey strip ①: "Trigger: when a spec version becomes accepted (Phase 1, step ⑧) the api pod queues a 'run Discover' job; a worker pod picks it up. No user action." / "Re-runs on every new accepted version; the API model is versioned with the spec, so Phase 3 always knows which model it used."
 Routers, two cards: ③ api_model.py [MVP]: GET /spec-versions/{v}/targets · …/fields · GET …/dependency-edges · …/coverage-universe · PATCH /dependency-edges/{id} (confirm | reject)   ⑤ rules.py [R2, blue]: POST /spec-versions/{v}/stories → 202 {job_id} · GET/PATCH /business-rules/{id} · POST /spec-versions/{v}/rules/confirm (the gate)
 Label "modules/discovery/ — the Understand module. service.py runs these four steps in order, in a WORKER pod", four boxes ② connected by arrows:
   inventory: one target row per operation: method, path, endpoint id, auth scopes, documented responses, safety = safe | idempotent | mutating (from method)
   field_catalog: flatten every request and response schema into field rows: path (a.b[].c), type, required, min/max, pattern, enum, example, and sensitive = true/false
   dependency_edges: explicit: the spec's own links. heuristic: POST /x returns id → GET /x/{id} uses it; same field name in response and path/body. each edge has a confidence
   coverage_universe: the checklist Phase 3 must cover: every endpoint, every documented response code, every request field, every constrained field, every edge, every security check
   Italic: "sensitive fields (dob, ssn, email, member id …) are flagged here and masked everywhere later — never in a log or an AI prompt. The guessed-edge rules are a starting point; agree them with the QE lead."
 Blue box ⑥ "release 2 · business rules from Jira stories — the API only queues the job; a separate ai-worker process does the AI part": ① rules.py fetches the stories from Jira (summary, description, acceptance criteria — never comments), runs the personal-data guard on the text, and inserts an ai_job row (kind = rules) plus a queue message in the same DB transaction. It replies 202 with the job id. ② ai-worker picks the job up. It gives the model ONLY: the masked story text, the endpoint names and paths, and the field names of the resources the stories mention. Never the full spec, never real data, never credentials. ③ The model must answer as a list of rules; each rule needs the exact source sentence it came from and a confidence. An answer that does not fit that shape is retried once with the error attached; a second failure marks the job failed. Nothing invalid is ever saved. ④ Good rules are saved as business_rule rows with status = proposed and the api_model moves to awaiting_review. The QE decides each one on screen (step ⑧); every decision is kept, so later prompts can show the model examples of what the team accepted.
 Grey strip "Where it runs (GKE): api pods serve the routes and queue jobs · worker pods run Discover · (R2) ai-worker pods: a third Deployment of the same image, entrypoint "worker --ai", in its own namespace, the only pods with network access to the model and the only service account allowed to call it. Scales 0–N on the ai-jobs queue."

COLUMN C "Stores and external systems" — subtitle "white = release 1 · blue = release 2 only":
 Cloud SQL · PostgreSQL 16 — the API model tables ②④⑦: target (spec_version_id, target_key, method, path, safety, auth_scopes, responses) / field (target_id, direction req|resp, path, type, required, constraints, sensitive) / dependency_edge (from_target, to_target, field_mapping, source, confidence, status) / business_rule (rule_text, applies_to…, source_sentence, confidence, status) R2 / ai_job (kind, status, prompt_version, tokens, cost, attempts, error) R2 / same rules as Phase 1: team_id + row-level security on every table; audit_event on status changes
 Cloud Storage · bucket inputs ②: the worker READS the cleaned-up spec JSON that Phase 1 saved (normalized_uri)
 Pub/Sub — topic platform-jobs (R1) · ai-jobs, ai-results (R2) ①⑥: platform-jobs: 'spec accepted → run Discover', taken by a platform-worker pod (same as Phase 1) / R2 ai-jobs / ai-results: between api pods and ai-worker pods. Always via the outbox table; skip duplicates.
 ai-worker — the process that talks to the model (blue) ⑥: same code base as platform-api, started with the worker entrypoint; scales with queue depth / the only process allowed to import the model client; runs the rules graph (fixed steps, no free-form agent)
 Jira Cloud · Gemini on Vertex AI (blue) ⑥: Jira: read stories only (REST, service account). Gemini: the model, always called through one LLMProvider interface so a fake provider can replace it in tests. Every prompt is a versioned file; every call records tokens and cost.
 Arrows from column B: "rows" double to Cloud SQL, "read" to Storage, "① job" double to Pub/Sub, "⑥ job" blue to Pub/Sub, "⑥ runs" blue double to ai-worker, "⑤ stories" blue dashed to Jira/Gemini.

STATUS STRIP "orchestration/api_model.py — the status the API model moves through …": (spec accepted) grey → draft ("Discover runs (steps ②)") → awaiting_review blue ("R2: stories attached, rules proposed") → confirmed green ("QE confirms: every low-confidence rule and edge has a decision"). A green bypass arrow below from draft straight to confirmed labelled "MVP, or no stories attached: goes straight to confirmed — the review gate is skipped". Right: "Phase 3 (Design) starts from confirmed: it reads targets, fields, edges, confirmed rules and the coverage universe".

PANELS:
 Step by step: ① A spec version becomes accepted (end of Phase 1). The api pod queues a job; a worker pod runs discovery.service.run(spec_version_id). ② Discover, in order: inventory → field catalog → dependency edges → coverage universe. Pure functions over the cleaned-up spec JSON; results are rows in target, field, dependency_edge. Status: api_model draft. ③ The QE opens the Discover view and sees endpoints, fields, edges with confidence, and the universe. ④ A guessed edge can be confirmed or rejected. Confirmed edges count as 100% certain from then on. Release 2 only: ⑤ The QE attaches Jira stories. The API fetches them, masks personal data, writes an ai_job + queue message, replies 202 with the job id. ⑥ ai-worker runs the rules graph and saves proposed business_rule rows; status → awaiting_review. ⑦ A live update tells the browser the job is done. ⑧ Rules review: the QE confirms, edits or rejects each rule (and any low-confidence edge), can add rules the stories never wrote down, then presses confirm. Status → confirmed. Result: an api_model with status confirmed. Phase 3 (Design) starts from it.
 Build order: Release 1 · Discover (build order step 4 of the platform): the four discovery steps as pure functions: input = cleaned spec JSON, output = rows. No network calls. Unit-test each one against the sample 'Claims' spec that ships with the repo. api_model.py router · Discover screen · confirm/reject an edge. Release 2 · Rules from stories: Jira client (read stories) · personal-data guard · ai_job table + queue · ai-worker entrypoint · the rules graph · rules.py router · Rules review screen · the confirm gate · decisions kept as feedback. Files: backend/apitest/modules/discovery/{router,service,repository}.py · backend/apitest/api/{api_model,rules}.py · orchestration/api_model.py · backend/apitest/ai/graphs/rules/ + ai/llm/ (R2) · worker/ai_jobs.py (R2) · web/features/workflows/discover/ · web/features/review/rules/ (R2)
 Done when: ☐ open a spec version and see every endpoint with method, path, id, safety and documented responses ☐ see every request and response field with type, constraints and whether it is sensitive ☐ see explicit and guessed dependencies with a confidence, and confirm or reject a guessed one ☐ see the coverage universe: what tests will have to cover, per dimension ☐ (R2) attach stories, get proposed rules with source sentence and confidence, decide each one, confirm. Rules: • Discover is deterministic: same spec in, same model out, no AI • the AI only ever proposes; a rule counts only after a QE confirms it • a rule without its source sentence is rejected before it is saved • the model never sees the full spec, real data, or credentials
 Words: API model — everything the platform knows about one spec version · target — one operation in the spec (GET /members/{id}); has a stable id · safety — safe = read-only · idempotent = repeatable · mutating = changes data · field catalog — every request/response field as a row, with its constraints · sensitive field — personal data (dob, ssn…); masked in logs, evidence, prompts · dependency edge — 'call A before B, pass this value'; explicit or guessed · confidence — how sure we are (0–1 for edges; high/medium/low for rules) · coverage universe — the full checklist of things tests must cover · dimension — a kind of coverage: structural, response code, schema, boundary, dependency, security, business rule · business rule — a behaviour the API must have, written in a Jira story · ai_job — one AI task: what was asked, prompt version, tokens, cost, result · graph — a fixed sequence of steps around one model call (LangGraph)
```

---

## 4. Phase 3 · Design

```
Use the CONVENTIONS above. Same layout as Phase 1/2.
Title: "Phase 3 · Design — what to build and how it works"
Subtitles: "What the platform does: a worker pod turns the API model into test cases with a RULE ENGINE (no AI), checks every case against the spec, removes duplicates, sets priority, and measures coverage against the universe from Phase 2." / "What the user does: reviews the cases in a queue (approve · edit · reject), bulk-approves the high-confidence ones, and approves the suite. A QE lead can accept a coverage gap. AI (release 2) only proposes cases for the gaps the engine cannot fill."
Top-right: "Phase 3 of 6 · Design · input: api_model.confirmed from Phase 2" / "white = release 1 (MVP, rule engine only) · blue = release 2 (AI for gaps, Zephyr publish)"

COLUMN A: ① Generate [MVP]: one button per spec version; → POST /spec-versions/{v}/suites → 202 {job_id} · ⑤ Coverage matrix [MVP]: endpoints × dimensions: covered / total / gaps; → GET /suites/{id}/coverage · ⑥ Review queue [MVP]: filter by endpoint, dimension, confidence, status; each case: approve · edit · reject (reason); bulk approve with a filter (high confidence only); add a manual case · edit sends If-Match: row_version; → GET /suites/{id}/test-cases?…; → PATCH /test-cases/{id} · POST …/approve | reject; → POST /suites/{id}/test-cases:bulk · ⑦ Approve the suite [MVP, green]: allowed only when every P1 case is decided and every dimension meets its threshold or has an accepted gap · QE lead: POST /suites/{id}/accept-gap; → POST /suites/{id}/approve · ⑧ Regenerate · Publish [R2, blue]: regenerate with a comment and a scope (R2); → POST /suites/{id}/regenerate; publish approved P1/P2 to Zephyr (R2); → POST /suites/{id}/publish. Footer: "live updates: suite.updated on GET /events/stream"

COLUMN B "platform-api + platform-worker (+ ai-worker in R2)" — subtitle "api pods serve the review screens and record every decision; the worker pod generates and measures · same core/ checks on every request":
 Routers: ① suites.py [MVP]: POST /spec-versions/{v}/suites (generate) → 202 · GET /suites/{id} · GET …/coverage (the matrix) · POST …/approve · …/accept-gap (lead) · …/regenerate · …/publish (R2)   ⑥ test_cases.py [MVP]: GET /suites/{id}/test-cases?endpoint=&dimension=&confidence=&status= · GET/PATCH /test-cases/{id} (If-Match: row_version, 409 on a stale edit) · POST …/approve · …/reject · POST /suites/{id}/test-cases:bulk · POST (manual case)
 Label "modules/design/ — the Design module. The worker runs these five steps in order; steps 2–4 are pure functions", five boxes:
   ② rule_engine: 6 generators, one per coverage dimension (list below). Input: the API model. Output: test case JSON drafts
   ② contract_check: every draft is checked against the spec: endpoint exists, status documented, assertion paths real. error = drop, warning = keep
   ③ consolidate: remove duplicates; set priority P1/P2/P3; set confidence high | medium; cap per endpoint (default 40), log 'capped'
   ③ measure: coverage per dimension = covered / universe. matrix + gap list; snapshot saved on the suite for history
   ④ hand over: insert test_case rows status = draft, mint case_id TC-XXX-0001; suite → awaiting_review; notify the browser
 Table box "the 6 rule-engine generators — what each one writes, from the API model alone": structural — one happy-path case per endpoint: smallest valid body, expect the documented success status and the response schema · response_code — one case per documented error code: 400 (drop a required field) · 401 (no login) · 403 (wrong role) · 404 (unknown id) · 405 (wrong method) · schema — one data-driven case per endpoint with rows: each required field removed / null / wrong type; optional fields wrong type; extra field · boundary — rows for every constrained field: min-1, min, max, max+1, empty, too short, too long, bad enum, bad format (date, email, uuid) · dependency — for each confirmed edge: create → get → update → delete → get again (404); wrong order; reuse of a deleted id · security — protected endpoints: no token, expired token, wrong scope, another user's record (member_b), injection strings (4xx, never 500)
 Two boxes side by side: grey "one test case = one JSON document (test_case.spec)": case_id: TC-CLM-0142 title, type (positive|negative|boundary|security), priority / steps: [ {alias, target_key, credential_profile, request: {path_params, query, body: {base, mutations[]}}, expect: {status, body assertions[], schema_ref}} … ] / coverage_targets: ["op:updateClaim:409", "field:…", "rule:R-12"] / cleanup: [ which created things to delete afterwards ] / "Phase 4 renders Karate from this; Zephyr steps and reports come from it too."   Blue ④ "release 2 · AI proposes cases ONLY for gaps the engine cannot fill": after 'measure', if a dimension is under its threshold — in practice business rules and realistic ('semantic') data — the worker queues one ai_job per endpoint with gaps. ai-worker gives the model: that endpoint's schema slice, its documented responses, the confirmed rules that touch it, the gap list, 3 approved example cases. The answer must be test-case JSON; every draft goes through the SAME contract_check; invalid ones go back once with the error, then are dropped. case_id is never chosen by AI. Loop: generate → check → measure → gaps, at most 3 rounds, then review regardless.
 Grey strip "Where it runs (GKE): api pods serve the review queue and record every decision (audit_event per case) · worker pods run the five steps — 50 endpoints must generate in under 60 s · (R2) ai-worker pods run the design graph for gaps, same queue mechanism as Phase 2. The rule engine is a plain Python package: unit-test it without any pod."

COLUMN C: Cloud SQL — the suite tables ③④⑥⑦: suite (spec_version_id, version, status, coverage_snapshot, generation_round, approved_by) / test_case (suite_id, case_id, title, type, priority, status draft|approved|rejected, confidence, origin rule_engine|ai|manual, spec jsonb, locked, row_version) / test_case_target (which endpoints a case touches, in order) / coverage_link (test_case_id, dimension, target_ref) ← coverage = GROUP BY on this table / READS from Phase 2: target, field, dependency_edge (confirmed), business_rule (confirmed) / a suite freezes on approval · a new spec version makes a new suite, copying unchanged approved cases · Pub/Sub · topic platform-jobs (R2: ai-jobs, ai-results) ①④: 'generate suite {id}' → a worker pod · (R2) 'design gaps for endpoint X' → an ai-worker pod; always via the outbox table in the same DB transaction; a duplicate message is skipped · ai-worker · Gemini on Vertex AI (blue) ④: runs the design graph: generate → contract_check → regenerate only what failed, at most 3 rounds; the model never sees the whole spec, real data or credentials; every call logged with tokens + cost · Zephyr (test management) (blue) ⑧: optional per team. After approval the worker pushes approved P1/P2 cases in batches, keyed by case_id so a re-push updates instead of duplicating. Steps are rendered from the case JSON. · Amber box "Do we need AI to generate tests? Short answer: not for release 1.": 6 of the 7 coverage dimensions come from facts already in the spec: which endpoints exist, which status codes, which fields, their limits, which calls depend on which, who may call what. A rule engine writes those cases exactly, every time, and can be unit-tested. AI would add cost, randomness and review effort for cases that need neither. The one dimension that needs AI is BUSINESS RULES: behaviour written in prose in Jira stories ('an adjudicated claim cannot be updated'). No rule engine can read prose. That is release 2, and even there AI only fills the gap list, and every draft passes the same contract check. Decide after R2 pilot: if QEs reject > 30 % of AI drafts, keep AI for rules only.
 Arrows: "rows" double to Cloud SQL, "① job" double to Pub/Sub, "④ gaps" blue dashed double to ai-worker, "⑧ publish" blue dashed to Zephyr.

STATUS STRIP "orchestration/suite.py — the status a suite moves through …": generating → measuring ("rule engine done (R2: + AI drafts)") → awaiting_review amber ("thresholds met, or 3 rounds done") → approved green ("QE approves: P1 decided, thresholds met or gap accepted") → published blue ("R2, optional: pushed to Zephyr") ; superseded grey at the far right. Blue loop below from measuring back to generating "R2: gaps left and round < 3 → AI round". Amber self-loop on awaiting_review "approve / edit / reject a case: stays here". Grey loop from approved to superseded below "a new spec version creates a new suite; unchanged approved cases are copied over with the same case_id". Right: "Phase 4 (Build) starts from approved".

PANELS — step by step ①…⑧ as in the numbered boxes (① Generate → suite row generating, queue, 202; ② rule_engine + contract_check, engine errors fail loudly; ③ consolidate + measure, insert drafts with minted case_ids; ④ (R2) AI for gaps ≤ 3 rounds; ⑤ awaiting_review, matrix; ⑥ review queue, row_version → 409; ⑦ approve, guards, suite freezes; ⑧ (R2) Zephyr; Result: suite approved). Build order: Release 1 — the test-case JSON model (Pydantic) FIRST; contract_check pure; the six generators one at a time with unit tests against the sample 'Claims' spec; consolidate; measure; suites.py + test_cases.py; state machine with approve guard; screens: coverage matrix, review queue, approve. Release 2 — design graph, regenerate, Zephyr client. Files: backend/apitest/domain/test_case.py · backend/apitest/modules/design/{router,service,repository}.py · modules/design/{rule_engine/,contract_check.py,coverage.py} · api/{suites,test_cases}.py · orchestration/suite.py · web/features/coverage/ · web/features/review/ · ai/graphs/design/ (R2). Done when: ☐ generate: cases for all six dimensions; every case passes the contract check; the matrix meets every default threshold except business rules ☐ a 50-endpoint spec generates in under 60 s and respects the per-endpoint cap; dropped cases show as 'capped' gaps ☐ filter the queue; bulk-approve high confidence; edit with If-Match and see 409 on a concurrent edit; reject with a reason and see the matrix drop below threshold at once; approve blocked until P1 reviewed ☐ a QE lead accepts a gap; the suite approves and freezes. Rules: • the engine never guesses: no case for a status or field the spec doesn't document • low-confidence cases cannot be bulk-approved — one by one, always • case_id is minted by the platform and never changes across versions • an approved suite is frozen; changes happen in the next suite • a case has at most ONE deliberate mutation (so a failure has one cause). Words: suite · rule engine · generator · contract check · mutation · data-driven case · coverage matrix · threshold · accepted gap · confidence · row_version · P1/P2/P3 · capped (one-line definitions as on the page).
```

---

## 5. Phase 4 · Build

```
Use the CONVENTIONS above. Same layout.
Title: "Phase 4 · Build — what to build and how it works"
Subtitles: "What the platform does: for every approved test case, a worker pod prepares the test data and writes the Karate script from a template, checks the script, and commits everything to Git." / "What the user does: normally nothing. A QE can open a script, edit it (which locks it against regeneration), and — in release 2 — upload a CSV of test data and confirm how its columns map to fields."
Top-right: "Phase 4 of 6 · Build · input: suite.approved from Phase 3" / "white = release 1 (templates only) · blue = release 2 (CSV mapping, AI for complex scripts, mock run)"

COLUMN A: ① Build starts by itself [MVP]: the moment a suite is approved (Phase 3); no button; progress shows as a live update · ⑤ Scripts list [MVP]: one row per test case: template used, valid / needs attention, locked or not, Git commit; → GET /suites/{id}/scripts · ⑥ Script editor [MVP]: open a script, edit it in the browser; saving LOCKS it so regeneration never overwrites it; → GET/PUT /scripts/{id} (If-Match: row_version); → POST /scripts/{id}/validate · …/unlock · ③ Upload test data CSV [R2, blue]: a CSV of real-looking rows for one endpoint; AI proposes column → field mapping, QE confirms; → POST /suites/{id}/csv; → GET/PATCH /csv/{id}/mapping · POST …/confirm · ④ Blocked cases [R2, blue]: cases that need a data record nobody has: shows exactly what QA must add; → GET /suites/{id}/blocked

COLUMN B "platform-api + platform-worker (+ ai-worker in R2)":
 Routers: ⑤ scripts.py [MVP]: GET /suites/{id}/scripts · GET/PUT /scripts/{id} · PUT saves through Git and locks the file · POST /scripts/{id}/validate · …/unlock   ③ data.py [R2, blue]: POST /suites/{id}/csv · GET/PATCH /csv/{id}/mapping · …/confirm · GET /environments/{id}/catalog · POST …/catalog (upload) · GET /test-cases/{id}/data-sets · GET /suites/{id}/blocked
 Label "modules/data/ + modules/scripts/ — the Build modules. The worker runs four steps per approved case", four boxes ②: test data — build the request body: start from the sample or smallest valid body, apply the case's one mutation. for data-driven cases write a rows file. Save to Storage · pick template — a fixed rule picks one of 6 templates from the case type (table below). no template fits → R2: AI writes the scenario; R1: 'needs attention' · render — fill the template: one .feature file per endpoint, one Scenario per case, tags @TC-id @p1 @type. values from earlier steps become Karate variables · check + commit — 1 parse 2 static rules 3 contract check 4 (R2) run against a mock; all pass → commit to Git, store the commit id on the script row · else needs attn
 Two boxes side by side: "the 6 templates (release 1) — hand-written first, against the pilot API": positive_schema_match — happy path: call, expect status, compare body to the schema · status_only — 401 / 403 / 404 / 405: switch login profile, expect the status · field_negatives_outline — one Scenario Outline, one row per bad field value · dependency_chain — create → get → update → delete, values passed along, cleanup · security_identity — call with another user's login, expect 403 or 404 · injection_outline — one row per injection string, expect 400 or 422, never 500.   "the static check — a script fails if it has": • a hard-coded URL (must come from karate-config) • anything that looks like a secret or an Authorization header (logins are injected by the runner as variables) • a missing @TC- tag • anything that looks like personal data • a variable used before any step defined it
 Blue ④ "release 2 · three additions, all optional per team": CSV mapping: AI sees the column names and 5 masked rows and proposes column → field for one endpoint; the QE confirms (a gate only when a CSV exists). Complex scripts: when no template fits (multi-step flows, state transitions, Kafka) ai-worker writes the scenario inside the same framework; same checks apply. Mock run + repair: every script runs against a mock server built from the spec (Prism) before any real environment; a failure goes back to AI with the error, twice at most.
 Grey strip "Where it runs (GKE): api pods serve the screens and the editor (edits go through Git) · worker pods build data + scripts and commit · (R2) the mock run is a runner Job in 'validate' mode with a Prism sidecar (no real environment touched) · (R2) ai-worker pods write and repair complex scripts. Nothing in this phase calls the API under test."

COLUMN C: Cloud SQL ②⑤⑥: script (test_case_id, repo_path, commit_sha, generated_by template|ai, validation_status valid|needs_attention, locked, row_version) / data_set (test_case_id, environment_id, uri, rows_uri, placeholders) / data_record · data_binding (R2: the QA data catalog, which case uses which record) / READS from Phase 3: test_case.spec (the JSON) · a suite is frozen, so inputs never move · Git · repo test-assets ②⑥: one folder per workflow: karate-config.js, auth/, helpers/, features/{endpoint}.feature, data/{env}/, schemas/, manifest.json. One commit per generation by a service account; QE edits are commits with the user's name. Nobody pushes directly. Every run pins one commit id. · Cloud Storage · bucket inputs ②: the built data files per case and environment (JSON body, CSV rows), and (R2) uploaded CSVs · Pub/Sub · topic platform-jobs (R2: ai-jobs) ①④: 'build suite {id}' → a worker pod · (R2) 'write / repair script for case X' → ai-worker · Runner Job in validate mode + Prism mock (blue) ④: the same Karate runner image as Phase 5, but pointed at a mock server generated from the spec. Proves the script logic; never a real environment. Dynamic chains that need real ids are skipped with a warning. · ai-worker · Gemini on Vertex AI (blue) ④: csv_mapping (fast model) and scripts (strong model) graphs; sees one case + the spec slice + 2 examples
 Arrows: "rows" double to Cloud SQL, "commit" double to Git, "data" to Storage, "① job" double to Pub/Sub, "④ mock" blue dashed double to Runner Job, "④ AI" blue dashed to ai-worker.

STATUS STRIP "orchestration/suite.py (continued) — the status a suite moves through in this phase": approved green → building ("Build starts by itself (Phase 3 approval)") → fan-out: ready green above ("every script valid and committed") and needs_attention amber below ("one or more scripts failed the checks (R2: after 2 AI repairs)"); amber dashed loop from needs_attention back into building "QE fixes the script in the editor, or asks for regeneration → build again"; ready → superseded grey ("a new spec version arrives"). Right: "Phase 5 (Run) needs the suite to be ready".

PANELS — step by step ①…⑥ (① approval → building, queue; ② per case: data → template → render → checks → script row; ONE commit per suite; ③ (R2) CSV mapping + blocked list; ④ (R2) AI scripts, mock run, ≤ 2 repairs; ⑤ scripts list; ⑥ editor locks; Result: suite ready — data files + a valid Karate project at one Git commit). Build order: Step 0 · write the reference project BY HAND against the pilot API (karate-config.js, auth, helpers, one feature per template; make it run; the generator only fills what you wrote here). Release 1 · data builder · select_template (a fixed rule, returns None if no fit) · renderer · parse + static + contract checks · Git client · scripts.py · list + editor screens · lock/unlock. Release 2 · CSV mapping, AI scripts, mock run. Files: karate-reference/ · backend/apitest/modules/data/{router,service,repository,builder}.py · modules/scripts/{router,service,repository}.py · modules/scripts/{templates/,render,checks,git_client}.py · web/features/scripts/ · ai/graphs/{csv_mapping,scripts}/ (R2). Done when: ☐ approve a suite and get a Karate project in Git with one tag per scenario; every script passes parse and static checks ☐ open a script, edit it, save; it is locked; regenerate the suite and the edited file is untouched, marked stale if the spec changed ☐ a run (Phase 5) can start from the commit id on the script rows. Rules: • templates first; AI only when no template fits (and only in R2) • a script never contains a URL, a secret or an Authorization header • every script has a @TC- tag: the runner selects by tags only • a locked script is never overwritten by the generator • every run pins one Git commit, so it can be repeated exactly • nothing in this phase calls the real API under test. Words: Karate · feature / Scenario · Scenario Outline · template · render · test data · mutation · static check · contract check · lock · stale · mock run (R2) · needs_attention.
```

---

## 6. Phase 4a · From test case to .feature (worked example)

```
Use the CONVENTIONS above. This page is two worked examples plus two reference boxes; no columns.
Title: "Phase 4a · How a test case becomes a .feature file — one worked example"
Subtitles: "A test case is a small JSON document (Phase 3). Build turns it into a Karate script in three moves: pick a template from the case's type → copy the case's values into the template's holes → check the result." / "No AI is involved for the six standard shapes. AI is asked only when no template fits, and even then it must write inside the same project and pass the same checks."

EXAMPLE 1 heading "Example 1 — a negative case (release 1, template only)". Three boxes in a row joined by thick arrows:
 Box ① "the test case JSON (test_case.spec, written by Phase 3)" — monospace, keep indentation:
 { "case_id": "TC-CLM-0031", "title": "Reject claim without member id", "type": "negative", "priority": "p1", "steps": [{ "alias": "create", "target_key": "createClaim", // POST /claims, "credential_profile": "default", "request": { "body": { "base": "sample", "mutations": [{ "op": "remove", "path": "/memberId", "label": "memberId missing" }] } }, "expect": { "status": 400, "body": [{ "path": "$.errorCode", "op": "eq", "value": "MISSING_FIELD" }] } }], "coverage_targets": ["op:createClaim:400", "field:createClaim:req:/memberId"], "cleanup": [] }
 Colour the case_id line blue, type/priority green, target_key purple, the mutation lines red, the expect lines amber.
 Grey box "② pick the template — a fixed rule" (a small decision table): type = positive → positive_schema_match / type = negative, one step, status only, no body check → status_only / type = negative|boundary, one mutation on the body → field_negatives_outline ✓ (bold green) / type = security, other login → security_identity / type = security, injection → injection_outline / 2+ steps, values passed on → dependency_chain / anything else → None (see example 2). Note: "the rule is ~30 lines of Python: select_template(case). Same input, same answer, every time. Unit-test it." Then "③ render = copy values into holes": case_id → the @TC- tag · target → the URL path · mutation → one Outline row · expect → the match lines · base: sample → read('data/{env}/TC-CLM-0031.json') · credential_profile → which token variable to use.
 Box ④ "the generated file features/createClaim.feature (committed to Git)" — monospace, keep indentation, with the same colours on the matching lines:
 # generated: suite 12 case TC-CLM-0031 v1 template field_negatives_outline@3
 Feature: createClaim  (POST /claims)
   Background:
     * url baseUrl                          # from karate-config.js, never typed here
     * def token = call read('auth/token.feature') { profile: 'default' }
     * header Authorization = 'Bearer ' + token.value
   @TC-CLM-0031 @p1 @negative @endpoint:createClaim
   Scenario Outline: Reject claim without member id — <label>
     * def body = read('data/<env>/TC-CLM-0031.json')
     * call read('helpers/mutate.feature') { body: '#(body)', op: '<op>', path: '<path>' }
     Given path '/claims'
     And request body
     When method POST
     Then status <status>
     And match response.errorCode == 'MISSING_FIELD'
     Examples:
       | op     | path      | status | label            |
       | remove | /memberId | 400    | memberId missing |
 Green strip ⑤ "before the commit, three checks on the generated text (no execution): parse — is it valid Gherkin/Karate, does every read() file exist, is every variable defined before use? static — no hard-coded URL, no secret, no Authorization typed in, @TC- tag present, no personal data. contract — status 400 is documented for POST /claims and $.errorCode exists in the 400 response schema. All three pass → the file is committed and the script row says valid. Any failure → needs_attention."

EXAMPLE 2 heading "Example 2 — when no template fits (release 2, AI writes the scenario)" with the grey line "The rule engine and templates cover single-endpoint cases and simple chains. A business rule from a Jira story usually needs several steps with logic in between. select_template returns None → in release 1 the case is marked needs_attention for a QE to write; in release 2 it goes to ai-worker." Three boxes:
 White box "the test case JSON (3 steps, a value passed from step 1 to steps 2 and 3, a business rule R-12)": case TC-CLM-0142 "Reject update of an adjudicated claim", type negative, p1, steps create (createClaim, expect 201) → adjudicate (adjudicateClaim, path_params claimId = ${create.response.body.claimId}, expect 200 and $.status == ADJUDICATED) → update (updateClaim, body base sample with mutation set /amount 500, expect 409 and $.errorCode == CLAIM_LOCKED); coverage_targets ["op:updateClaim:409","rule:R-12"]; cleanup delete via deleteClaim.
 Blue box "what ai-worker is given (and nothing else)": • this one case JSON • the spec slice for the 3 endpoints (schemas, responses) • the helper features that exist (names + parameters) • the conventions guide (how our features are written) • 2 finished examples of the closest pattern. "what it must return": • one Scenario as text, plus the list of helpers it used. "what happens to the answer": • the SAME parse / static / contract checks as example 1 • (R2) a run against a mock server built from the spec • any failure → sent back once with the error message • second failure → needs_attention, a QE takes over • the file header says 'generated by ai' so it is visible • AI never picks the case_id, the tags or the URL: those are stamped by the platform after the answer
 Blue-bordered box "what comes back — one Scenario inside features/updateClaim.feature": # generated: suite 12 case TC-CLM-0142 v1 by ai (scripts graph v4) / @TC-CLM-0142 @p1 @negative @endpoint:updateClaim @rule:R-12 / Scenario: Reject update of an adjudicated claim / * def create = call read('helpers/claim-create.feature') / * def claimId = create.response.claimId / Given path '/claims', claimId, 'adjudicate' / When method POST / Then status 200 / And match response.status == 'ADJUDICATED' / * def body = read('data/<env>/TC-CLM-0142.json') / * set body.amount = 500 / Given path '/claims', claimId / And request body / When method PUT / Then status 409 / And match response.errorCode == 'CLAIM_LOCKED' / * configure afterScenario = function(){ karate.call('helpers/cleanup.feature', { claimId: claimId }) }

BOTTOM: two reference boxes side by side.
 "Endpoints involved in this (all in scripts.py) — and what each one does": POST /suites/{id}/scripts:generate — starts the build for a suite (normally automatic on approval); 202 with a job id · GET /suites/{id}/scripts — one row per case: template or ai, valid / needs_attention, locked, commit id · GET /scripts/{id} — the file text, read from Git at the pinned commit · PUT /scripts/{id} — save an edited file: commit under the user's name, set locked=true (If-Match: row_version) · POST /scripts/{id}/validate — run the three checks on the current text and update validation_status · POST /scripts/{id}/unlock — let the generator overwrite the file again on the next build · POST /suites/{id}/regenerate (R2) — rebuild with a comment and a scope (one case, one endpoint, or all); locked files untouched
 "The generated project in Git — one folder per workflow (test-assets repo)": workflows/claims/karate-config.js — reads BASE_URL and AUTH_* from environment variables; nothing typed in · auth/token.feature — gets one token per login profile per run and caches it · helpers/*.feature — hand-written building blocks: mutate, claim-create, cleanup … · features/{endpoint}.feature — GENERATED: one file per endpoint, one Scenario per case · data/{env}/{case_id}.json | .csv — GENERATED: the request body / rows for that case in that environment · schemas/{Name}.json — GENERATED: response schemas copied from the spec, for match · manifest.json — GENERATED: suite id, spec version, case_id → file:line, template versions
Footer italic: "Rule of thumb for the team: the JSON is the truth, the .feature is a rendering of it. If a script looks wrong, fix the template (or, for AI output, the prompt/example) — not the individual file — unless the QE deliberately locks it."
```

---

## 7. Phase 5 · Run

```
Use the CONVENTIONS above. FOUR columns this time: who starts a run (300 px) · platform-api + platform-worker (640 px) · inside a runner pod (440 px, blue background) · stores (340 px); then the status strip and four panels.
Title: "Phase 5 · Run — how the Karate scripts are executed"
Subtitles: "What the platform does: checks the environment is ready (pre-flight), starts one Kubernetes Job that runs the .feature files against the real test environment, collects the results and the evidence, and cleans up what the tests created." / "What the user does: presses Run (or CI / a nightly schedule / a Jira webhook does), picks the environment and what to run, watches progress live, opens results and evidence. Everything here is release 1."
Top-right: "Phase 5 of 6 · Run · input: suite.ready from Phase 4 (a Git commit + data files)" / "the runner is the ONLY thing that talks to the API under test · it never talks to the database"

COLUMN A "Who starts a run — four ways in; all end up as POST /runs": ① QE presses Run [MVP]: picks environment + what to run: everything · P1 only · one endpoint · chosen cases (@TC- tags); → POST /runs · ① CI pipeline [MVP]: after a deploy, with a team API key; → POST /triggers/deploy {workflow, environment, build_version}; same run twice within 60 s = one run · ① Nightly schedule [MVP]: per workflow and environment (a scheduled call to POST /runs) · ① Jira webhook [R3, blue]: a defect moves to 'ready for QA' → rerun the linked cases (Phase 6) · ⑧ Runs list · Run detail [MVP]: live progress; per case pass / fail / flaky / blocked; error text; evidence link; cancel; rerun failed; → GET /runs · GET /runs/{id} · …/results; → GET /results/{id}/evidence (signed link); → POST /runs/{id}/cancel · …/rerun-failed

COLUMN B "platform-api + platform-worker" — subtitle "api pods take the request and serve results; the worker pod does pre-flight, starts the Job, and reads the results back":
 Router card ① "runs.py · triggers.py": POST /runs → run row (status requested), queues 'preflight run {id}', replies 202 {run_id} · GET /runs · GET /runs/{id} · …/results · GET /results/{id}/evidence · POST …/cancel · …/rerun-failed · POST /triggers/deploy (API key, not a user login) · POST /webhooks/jira (R3, signed)
 White box ② "pre-flight (worker, execution/preflight.py — reuses the Phase 1 smoke package)": 1 freeze window? too many runs already going? → wait in a queue, position shown to the user  2 a token for every login profile the run needs · one read-only call to the environment · Kafka (R3)  3 reserve the data records the cases need (R2 catalog); a case with no record runs as 'blocked'  4 ask the API under test for its version, if it has one → stored as build_version  5 (red) anything red → env_not_ready, ONE notification to the QE and the environment owner. Else → ③
 White box ③ "launcher (worker, execution/launcher.py) — writes a manifest, creates ONE Kubernetes Job": manifest = exactly what to run: git commit · data version · environment base URL · login profiles · tag expression (@p1, or @TC-CLM-0031,@TC-CLM-0142) · shards (feature files grouped by duration, max 8) / Job = image pinned by digest · one pod per shard · no Job-level retries · 1-hour deadline · runners pool / secrets are NOT in the Job spec; the pod mounts them at start. run.status → running, Job name stored
 Green box ⑦ "result ingestion (worker, on the 'run completed' message — execution/ingest.py)": 1 read karate-summary.json from Storage; each scenario's @TC- tag says which case it was  2 one result row per case: passed / failed / error / flaky / skipped / blocked + duration, error, evidence  3 fingerprint each failure = hash(endpoint, assertion, status, error minus ids/timestamps): same bug = same hash  4 update counts, status completed, release reserved data, live update; (R2) push a Zephyr test cycle  5 cleanup: delete what the tests created and left behind (the ledger); 3 failed tries → 'orphaned' on the report
 Grey strip "Where it runs (GKE): api pods (requests, results) · worker pods (pre-flight, launcher, ingestion) · runner = a Kubernetes JOB, one per run, in namespace 'runners'; network rules allow the test environment, Storage, Pub/Sub and Git only — never production, never the DB."
 A thick black arrow from the launcher box to column C labelled "creates the Job".

COLUMN C (blue background) "inside a runner pod — the Karate Job" — subtitle "image: Java 21 + karate.jar · entrypoint.sh does this, in order". A vertical list of steps joined by small blue arrows:
 ④ read the manifest — what commit, what data, what tags, which shard am I
 git clone --depth 1 at that commit — the exact scripts Phase 4 built; nothing newer
 download the data files — data/{env}/*.json and *.csv for this suite version
 secrets → environment variables — mounted from Secret Manager; exported as AUTH_* and BASE_URL; never printed, never on disk
 ⑤ run Karate — java -jar karate.jar -t '<tags>' -T 4 features/ (-T = parallel threads; one pod per shard); karate-config.js reads BASE_URL and AUTH_*; a failure that looks like network / 5xx is retried ONCE and marked flaky if it then passes; assertion failures are never retried; a per-environment requests/sec limit is applied
 mask before writing anything — Authorization, Cookie, X-Api-Key headers and every field marked sensitive in the field catalog are replaced in the request/response log inside the pod
 ⑥ upload + report — evidence → Storage: summary JSON, junit XML, HTML, one request/response file per case and step, pod logs; then publish 'run completed' to Pub/Sub and exit

COLUMN D "Stores and external systems": API under test · dev / qa / staging (blue): the real test environment. Only the runner pod calls it. Never production. · Git · repo test-assets: cloned read-only at the pinned commit · Secret Manager (red): login secrets mounted into the runner pod at start; the DB has only their addresses · Cloud Storage · bucket evidence: runs/{run_id}/ — kept 90 days, summaries 2 years; the UI hands out signed links · Pub/Sub · run-events + platform-jobs: 'preflight run X' → worker; 'run completed' (from the pod) → worker · Cloud SQL · PostgreSQL 16: run (trigger, scope, commit, data version, build_version, status, preflight, counts) / result (per case: state, duration, retried, fingerprint, evidence_uri, error) / created_resource (the cleanup ledger) / green note: written by the worker in ⑦ (never by the runner)
 Arrows from the runner column: "clone" to Git, "mount" red to Secret Manager, "HTTP" blue double to API under test, "upload" to Storage, "done" to Pub/Sub.

STATUS STRIP "orchestration/run.py — the status a run moves through (a run is never edited; everything needed to repeat it is on the row)": requested → preflight ("worker picks it up") → running blue ("all green → Job created") → collecting ("'run completed' message") → completed green ("results + cleanup done") → synced blue ("R2: Zephyr cycle pushed") → cancelled grey via dashed arrow ("cancel: from any earlier status"). Below preflight, a red branch to env_not_ready (red) "any red → stop, one notification" with the note "the run row keeps which check failed; the QE fixes the environment and starts a new run". Right: "Phase 6 starts from completed".

PANELS — step by step ①…⑧ (as on the page: run row with everything to repeat it; pre-flight; launcher; runner pod steps; Karate with retries and masking; upload + publish; ingestion; runs list, cancel, rerun failed; Result: run completed — an immutable run record + masked evidence). Build order: Release 1 · the runner image (Dockerfile + entrypoint.sh: clone, data, secrets, run, mask, upload, publish) — build and test it by hand with the reference project first · the Karate log masker · pre-flight (import the Phase 1 smoke package) · launcher · result ingestion · fingerprint · cleanup ledger + sweeper · runs.py · triggers.py · screens · cancel · rerun failed. Release 2 · Zephyr test cycle · data catalog reservation. Files: runner/ · backend/apitest/modules/execution/{preflight,launcher,ingest,cleanup}.py · api/{runs,triggers}.py · orchestration/run.py · deploy/helm/runners/ · web/features/runs/. Done when: ☐ run on QA: pre-flight passes, a Job starts at the pinned commit, results come back per case, evidence is masked (a canary secret and a sensitive field never appear), created resources are cleaned up ☐ a network blip shows as flaky, not failed; an assertion failure is failed ☐ a run against an unreachable environment ends env_not_ready with exactly one notification ☐ CI trigger with an API key starts a P1 run; a duplicate within 60 s is merged ☐ the run row alone is enough to start the identical run again. Rules: • the runner never talks to the database; it reads a manifest, writes files • secrets reach the pod as mounted files → variables; never in the Job spec or logs • only network / 5xx errors are retried, once; a retried pass is 'flaky' • the runner can reach the test environment, Storage, Pub/Sub, Git — nothing else • every run pins one commit and one data version: repeatable forever. Words: run · scope / tags · pre-flight · manifest · Kubernetes Job · shard · evidence · masking · flaky · blocked · fingerprint · cleanup ledger · env_not_ready.
```

---

## 8. Phase 6 · Close the loop

```
Use the CONVENTIONS above. Three columns (320 / 700 / 720 px), status strip, four panels. Purple = release 3.
Title: "Phase 6 · Close the loop — from a failed test to a fixed defect"
Subtitles: "What the platform does: shows a run report (release 1). In release 3 it also sorts every failure into a category, drafts a Jira defect for real bugs, and re-runs the right tests automatically when the fix is ready." / "What the user does: reads the report (release 1). In release 3 a QE confirms or corrects each triage decision before anything reaches Jira — the platform never files a defect on its own."
Top-right: "Phase 6 of 6 · Close the loop · input: run.completed from Phase 5" / "white = release 1 (run report) · purple = release 3 (triage, defects, rerun, dashboards) · release 2 adds nothing here"

COLUMN A: ① Run report [MVP]: counts · coverage matrix · failures grouped by fingerprint · blocked cases · what changed since the previous run · click into any case; → GET /runs/{id}/report · ③ Triage list [R3, purple]: every failure with a category, a confidence and a one-line reason; grouped by root cause; → GET /runs/{id}/triage · ④ Defect review (the gate) [R3, purple]: per item: confirm · change the category · edit the drafted defect · dismiss; then 'create defect' for confirmed bugs; → PATCH /triage-items/{id}; → POST /triage-items/{id}/create-defect · ⑧ Defects · Dashboards [R3, purple]: open defects per workflow with rerun results; workflow / portfolio / release-readiness views; → GET /workflows/{id}/defects · …/dashboard; → GET /portfolio · GET /runs/{id}/report.pdf

COLUMN B "platform-api + platform-worker (+ ai-worker in R3)" — subtitle "api pods serve the report and record every decision; the worker pod triages, talks to Jira and starts reruns":
 White box ① "run report (release 1 · modules/analysis/report.py · reports.py router)": every number is computed in SQL from result and coverage_link rows — never by AI, never by hand: passed / failed / flaky / blocked counts · coverage matrix for this run · failures grouped by fingerprint (one bug, once) / blocked cases and why · difference from the previous run on the same environment (new, fixed, still failing) / drill-down per case: the assertion that failed, the masked request and response (signed link to evidence)
 Purple box ② "triage (release 3 · worker, modules/analysis/triage.py — cheap rules first, AI only for what is left)": step 1 · signals (plain rules, no AI) — decide the obvious ones and stop: environment issue = every case on that host failed / connection errors · data issue = blocked case or stale data record · flaky = passed on the retry · contract drift = the response shape changed vs the spec (field appeared / vanished, new status). step 2 · AI for the rest (ai-worker, fast model) — given the masked request + response, expected vs actual, rule + spec slice, the case's history and its cluster mates; must answer: category, confidence, one-line reason, DRAFT defect (title, steps, expected, actual). step 3 · cluster — failures with the same fingerprint, or same endpoint + status + reason, become ONE item with many results. output: triage_item rows (category: product_bug · contract_drift · test_issue · data_issue · environment_issue · flaky) → awaiting_review
 Purple box ⑤ "Jira defect + rerun on fix (release 3 · worker, modules/integration/jira.py + execution)": create defect (only after a QE confirmed the item): look up Jira by fingerprint first → open issue found → comment 'seen again in run X' · closed issue found → new issue linked 'regression of' · nothing → new issue. the issue carries: component, priority from severity, labels, our fingerprint + case ids, links to the story, the report, the evidence. rerun on fix: Jira calls POST /webhooks/jira when the issue moves to 'ready for QA' (statuses set per team; call verified by a secret). the handler reads ONLY issue key + new status → finds our defect row → starts a Phase 5 run: linked cases + same endpoint + chain. the result is commented on the Jira issue with a link; the defect row records the rerun outcome
 Grey strip "Where it runs (GKE): api pods (report, triage list, decisions, the Jira webhook route behind an internal load balancer) · worker pods (signals, clustering, Jira calls, reruns) · ai-worker pods (the triage graph, scales 0–N). The AI writes a DRAFT; a person decides; the worker files it."

COLUMN C: Cloud SQL ①③④⑤: READS run, result (state, fingerprint, error), coverage_link, test_case — the report is SQL over these / triage_item (run_id, category, confidence, explanation, result_ids[], qe_decision, defect_id) R3 / defect (workflow_id, jira_key, fingerprint, status, severity, regression_of, test_case_ids[]) R3 / every QE decision (confirm / reclassify / dismiss) is kept: the feedback that tunes triage later · Cloud Storage · bucket evidence ①②: the report links to evidence with short-lived signed URLs; triage reads the masked request/response from here · Pub/Sub · platform-jobs · ai-jobs · jira-events (purple) ②⑥: 'triage run X' → worker · 'classify these failures' → ai-worker · 'defect status changed' from the webhook → worker (rerun) · ai-worker · Gemini on Vertex AI (fast model) (purple) ②: the triage graph: one pass, structured answer (category, confidence, reason, draft defect); must be ≥ 85 % right on a labelled test set before it ships; a bad answer is retried once, then the item is left for the QE · Jira Cloud (purple) ⑤⑥: write: Bug issues, comments, links (service account) · read: issue status changes via the webhook; dedup by our fingerprint in a custom field; our comments carry a hidden marker so we never post twice · Notifications · Teams webhook / email ①: one message per event with a deep link: run completed, environment not ready, suite awaiting review — never per case
 Arrows: "SQL" double to Cloud SQL, "read" to Storage, "jobs" purple double to Pub/Sub, "AI" purple dashed double to ai-worker, "REST" purple double to Jira, "notify" to Notifications.

STATUS STRIP "the loop in one line — a triage item and its defect (release 3). Release 1 stops after the report.": run completed → report ("always (R1)") → awaiting_review amber ("R3: signals + AI + clusters") → decided green ("QE: confirm / reclassify / dismiss") → defect.open purple ("filed in Jira (dedup by fingerprint)") → rerun blue ("Jira 'ready for QA' webhook") → closed green ("rerun passes → comment, close"). Red dashed loop from rerun back to defect.open "rerun still fails → comment on the issue, defect stays open, no new issue". Under awaiting_review: "dismissed items go nowhere; reclassified ones are kept as training feedback".

PANELS — step by step ①…⑦ (① run completes; report at once, one notification — the whole phase in release 1. Release 3: ② triage rules then AI, clusters, awaiting_review; ③ triage list; ④ defect review; ⑤ create defect with dedup; ⑥ rerun on fix via webhook, scoped run, result commented; ⑦ dashboards; Result: the loop is closed — a defect goes from a failed assertion to a verified fix without manual steps). Build order: Release 1 · the run report (step 9, the last MVP step): report queries, drill-down, reports.py, notifications. Release 3 in this order: 1 signal rules + fingerprint clustering (no AI yet — measure how much they catch) 2 the triage graph, gated by ≥ 85 % accuracy on a labelled set of past failures 3 the review gate screens and PATCH endpoints 4 Jira client: create with dedup, comments with the hidden marker 5 webhook route + rerun scope logic 6 dashboards · PDF · AI summary. Files: backend/apitest/modules/analysis/{report,triage,cluster}.py · modules/integration/{jira,webhooks}.py · api/{reports,triage}.py · ai/graphs/triage/ (R3) · worker/jira_events.py (R3) · web/features/reports/ · web/features/triage/ (R3). Done when: Release 1 ☐ open a run report with counts, matrix, failures grouped, blocked cases, change since the previous run, and click into any case's evidence. Release 3 ☐ a defect on the pilot API goes failed test → triage → confirmed → Jira issue → fix → 'ready for QA' → automatic rerun → passed, with no manual step other than the QE's review decision ☐ the same failure in two runs produces one Jira issue, not two. Rules: • every number on a report is computed; AI may write prose, never figures • the platform never files a Jira issue without a QE confirming the item • cheap rules before AI: no model call for a flaky retry or a dead host • the webhook handler trusts nothing in the payload except key + status • dedup by fingerprint: one bug = one issue, comments for repeats. Words: fingerprint · triage · category · contract drift · signal · cluster · draft defect · defect review · dedup · webhook · rerun scope · dashboard.
```

---

## 9. The whole system on one page (overall architecture)

```
Use the CONVENTIONS above. This page is FIVE horizontal rows, full width, no columns.
Title: "AI API Testing Platform — the whole system on one page"
Subtitle: "One code base, deployed as three kinds of pods plus a test-runner Job, around one database. People decide at five gates; AI only drafts; the runner is the only thing that touches the API under test."
Top-right: "white = release 1 (MVP) · blue = release 2 (AI) · purple = release 3 (triage, defects)" / "read this page first; each phase has its own detailed page"

ROW 1 label "WHO — people and systems that start things": five boxes in a row, each with a down-arrow into row 2:
 QE (tester) — browser, single sign-on — creates workflows, uploads specs, reviews and approves test cases, reads reports, triages
 QE lead — browser, single sign-on — everything a QE does, plus: accept a coverage gap, change thresholds, delete credentials, allow security tests
 CI pipeline — API key, no login — after a deploy: POST /triggers/deploy → a P1 run; duplicates within 60 s merged
 Schedule — nightly, per workflow — a timed POST /runs on the chosen environment
 Jira (purple, R3) — webhook, signed — issue moves to 'ready for QA' → rerun the linked tests (release 3)

ROW 2 a large light-grey container "WHERE THE CODE RUNS — Google Kubernetes Engine (GKE), one cluster" with the line "one repository · one container image for everything Python · the entrypoint decides what a pod does · all three Deployments ship together with the same image tag". Inside, left to right:
 Box "web" — Angular app · nginx · 2 pods — screens only, no business logic: workflows · readiness · discover · coverage · review queue · scripts · runs · reports · triage; talks to the API over REST; gets live updates over SSE. A double arrow "REST" to the next box.
 Dashed container "namespace app" holding two boxes: "platform-api" (tag "all phases") — FastAPI · 2–20 pods · scales on HTTP load — answers every request in < 1 s, then hands off: • login check, permission check, team isolation • every status change and every human gate • the review queue and every decision (audited) • queues slow work for the worker • the only thing that writes to the database status columns; routes: /api/v1/… · SSE · /triggers · /webhooks.   "platform-worker" (tag "all phases") — same image, entrypoint 'worker' · 1–N pods · scales on queue — runs the slow steps, one job at a time: • Phase 1 normalize, lint, smoke check • Phase 2 Discover (the API model) • Phase 3 rule engine + coverage • Phase 4 test data, templates, Git commit • Phase 5 pre-flight, start the Job, ingest results • Phase 6 report queries · (R3) triage, Jira, reruns; never serves HTTP · long shutdown grace
 Dashed blue container "namespace ai" holding "ai-worker" (blue border, tag "R2 · R3") — same image, entrypoint 'worker --ai' · 0–N pods — the ONLY pods allowed to call the model: • R2 rules from Jira stories • R2 test cases for coverage gaps • R2 CSV column mapping • R2 scripts when no template fits • R3 triage of failures; AI only drafts. Every draft is checked by code and decided by a person.
 Dashed container "namespace runners" holding "runner (Kubernetes Job)" (tag "Phase 5") — different image: Java 21 + Karate · one Job per run · N pods = N shards — 1 read the manifest 2 git clone at the pinned commit 3 download data 4 secrets → AUTH_* variables 5 run Karate by tags 6 mask request/response logs 7 upload evidence 8 publish 'run completed' 9 exit; network: the test environment, Storage, Pub/Sub, Git and nothing else. Never production. Never the DB.; the ONLY thing that calls the API under test
 Two down-arrows from the api/worker area into row 3.

ROW 3 label "WHAT IT USES — managed services (nothing self-hosted)" with the italic note "every pod reaches these with its own service account · the runner only Storage, Pub/Sub, Git, Secret Manager · only ai-worker reaches Vertex AI". Eight boxes in a row:
 Cloud SQL · PostgreSQL — the one database — team, workflow, environment, credential_profile, spec_version, target, field, dependency_edge, suite, test_case (JSON), script, run, result, triage_item, defect, audit_event, outbox · RLS on all
 Cloud Storage — 3 buckets — inputs: raw + cleaned specs, samples, data files; evidence: per run, masked, 90 days; reports: summaries, 2 years
 Pub/Sub — the queue — platform-jobs · run-events; ai-jobs · ai-results (R2); jira-events (R3) · via outbox
 Secret Manager (red) — the only place a secret lives — written once by the credentials endpoint; pods read by address
 Git · test-assets — generated Karate projects — one folder per workflow · one commit per generation · runs pin a commit
 Vertex AI · Gemini (blue, R2) — the model — called only from ai-worker, through one interface; fast + strong tiers
 Jira · Zephyr (purple, R2·R3) — read stories · write defects · test cases — Zephyr: publish cases, test cycles (R2); Jira: stories (R2), defects + webhook (R3)
 Also — DLP: personal-data scan on uploads; Teams / email: one message per event; Workload Identity: pods log in, no keys

ROW 4, three boxes: blue "APIs under test · dev / qa / staging — the customer's systems, per environment": reached ONLY by the runner Job (and one read-only smoke call from the worker during onboarding); never production: network rules make that impossible, not just forbidden; login profiles per environment (default, member_b, read_only …) for role and ownership tests · Kafka (R3).   Green "Six rules that hold the whole design together": 1 Deterministic first: code writes the tests from the spec; AI only fills gaps, and only drafts. 2 A person decides at every gate: readiness, rules, test cases, data, defects. Never auto-filed. 3 One test case JSON is the truth; scripts, Zephyr, reports and reruns all derive from it. 4 Secrets never enter the DB, logs, Git, prompts or evidence — only their Secret Manager address. 5 Everything is immutable and versioned: spec versions, suites, runs. A change is a new version. 6 Every table has team_id; Postgres row-level security is the second wall behind the code.   White "The six phases and where each one runs": 1 Onboard — api + worker — spec in → readiness report / 2 Understand — worker (+ ai R2) — spec → API model (+ rules) / 3 Design — worker (+ ai R2) — API model → approved test cases / 4 Build — worker (+ ai R2) — cases → data + Karate scripts in Git / 5 Run — worker + runner Job — scripts → results + evidence / 6 Close the loop — worker (+ ai R3) — results → report, defects, reruns

ROW 5 dashed strip "How a run of the product reads, left to right — the five green diamonds are the human gates": a chain of pills joined by arrows: spec upload → readiness ◆ (green) → API model → rules ◆ (R2) (green) → test cases → approval ◆ (green) → data ◆ (R2) (green) → scripts in Git → run on GKE (blue) → results → triage ◆ (R3) (green) → Jira + rerun (R3) (purple) → report
```

---

## 10. Cover page — Read this first

```
Use the CONVENTIONS above. A text-heavy landscape page with five boxes.
Title: "AI API Testing Platform — Architecture pack"; subtitle "Read this first: what is in the pack, how every page is laid out, and what the colours and tags mean. You do not need the technical specification to use these pages."
Box "What is in the pack (in reading order)": 0 The whole system on one page — who, where the code runs, what it uses, the six rules / — End-to-end process flow — 24 steps, 5 human gates, 5 loops, 1 stop, with release tags / 1 Onboard — spec upload, credentials, smoke check, readiness / 2 Understand — Discover: the API model · R2 rules from Jira stories / 3 Design — rule engine, coverage, review queue, approval · do we need AI? / 4 Build — test data, templates, checks, Git / 4a From test case to .feature — one worked example, with and without AI / 5 Run — pre-flight, the Kubernetes Job, inside the runner pod, results / 6 Close the loop — report · R3 triage, defect review, Jira, rerun on fix / Appendix — the Python script behind every page, so it can be edited
Box "How every phase page is laid out": a small wireframe: a title bar; three columns A "the screens", B "the code", C "stores + external systems"; below them an amber strip D "status strip"; below that four green panels E "step by step", F "build order + files", G "done when + rules", H "words you will see". Notes: A → B → C is the data path, left to right. Arrows from B to C carry the step number. Numbered circles ①…⑧ on the page match the 'step by step' panel (E). The status strip (D) is the exact list of statuses in the code; each arrow is one function. Read E first if you are new; read F and G if you are about to build it; H when a word is unclear.
Box "Colours, tags and shapes": the colour legend from the CONVENTIONS, the three release pills, and "◆ diamond = a human gate · ● dot = start / end · dashed box = optional branch".
Box "How to use these pages": If you are new — read page 0, then the process flow, then the 'step by step' panel of each phase. One hour. / If you are building a phase — read that page's 'build order' and 'done when' panels; the file paths tell you where code goes. / If a word is unclear — every page defines its own words in the last panel; page 0 explains the whole system's words. / If something is missing — a few details are not decided anywhere yet; they are marked on the page ('agree with the QE lead', 'confirm with Advik'). Do not guess silently — raise them. / If a page is wrong — each page is generated by a small Python script (appendix). Change the text in the script, run it, and the SVG and PNG are regenerated. Do not edit the SVG by hand. / What this pack is not — it is not the API contract (that is the generated OpenAPI file) and not the database schema (that is in the migrations). Where this pack and the code disagree, the code wins and the page must be fixed.
Green box "The six rules, repeated once here so nobody has to look them up": the six rules written out in full (as in page 9), and the italic closing line "One image, one core, one database; a folder per phase; a pod group per kind of work. Split into services only if a module later needs its own team, database or release cadence."
```

---

## Tips per tool

- **Lucidchart AI / Lucid "Generate diagram"**: paste the conventions + one page prompt. Lucid handles ~40 shapes well; for the phase pages ask for column B first, then "add column A to the left", then "add column C to the right", then "add the status strip and the four panels below".
- **draw.io (Generate Diagram → Mermaid or "Describe")**: for the process flow and status strips ask for **Mermaid `flowchart LR`** output and paste it; for the column pages ask for **draw.io XML** (`<mxGraphModel>`) with `swimlane` containers for the columns — mention "use mxgraph swimlane containers, fillColor per the CONVENTIONS".
- **Miro AI**: works best one row / one column at a time; ask for sticky-note clusters with the colours from the CONVENTIONS, then convert to shapes.
- **Any LLM**: ask for "draw.io XML" or "Mermaid" explicitly; for text-heavy boxes ask it to "keep every bullet exactly as written".
