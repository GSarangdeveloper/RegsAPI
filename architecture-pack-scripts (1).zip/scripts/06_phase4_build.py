import os
os.makedirs('out', exist_ok=True)
#!/usr/bin/env python3
"""Phase 4 Build — whiteboard-style, one example flowing through."""
FONT = "Inter, 'Segoe UI', Helvetica, Arial, sans-serif"
MONO = "'JetBrains Mono', SFMono-Regular, Consolas, 'Liberation Mono', monospace"
INK, MUTED, LINE = "#1f2937", "#6b7280", "#9ca3af"
BLUE, BLUE_BG = "#2563eb", "#eff6ff"
GREEN, GREEN_BG, GREEN_INK = "#059669", "#ecfdf5", "#065f46"
AMBER, AMBER_BG, AMBER_INK = "#d97706", "#fffbeb", "#92400e"
RED, RED_BG, RED_INK = "#dc2626", "#fef2f2", "#991b1b"
GRAY_BG = "#f3f4f6"
W, H = 1700, 990
out = []
def w(s): out.append(s)
def esc(s): return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
def text(x, y, s, size=12, anchor="start", weight="normal", fill=INK, style="", font=FONT):
    st = f" font-style='{style}'" if style else ""
    lead = len(s) - len(s.lstrip(' '))
    s = '\u00a0' * lead + s.lstrip(' ')
    w(f"<text x='{x}' y='{y}' font-size='{size}' text-anchor='{anchor}' font-weight='{weight}' fill='{fill}'{st} dominant-baseline='middle' font-family=\"{font}\">{esc(s)}</text>")
def rect(x, y, wd, h, fill, stroke, rx=14, sw=2, dash=""):
    d = f" stroke-dasharray='{dash}'" if dash else ""
    w(f"<rect x='{x}' y='{y}' width='{wd}' height='{h}' rx='{rx}' fill='{fill}' stroke='{stroke}' stroke-width='{sw}'{d}/>")
def arrow(pts, color=INK, width=2.4, dashed=False):
    p = " ".join(f"{x},{y}" for x, y in pts)
    m = {INK: "a", BLUE: "aB", AMBER: "aA", RED: "aR", GREEN: "aG"}[color]
    d = " stroke-dasharray='7 5'" if dashed else ""
    w(f"<polyline points='{p}' fill='none' stroke='{color}' stroke-width='{width}'{d} stroke-linejoin='round' marker-end='url(#{m})'/>")
def badge(x, y, n, color=INK, r=15):
    w(f"<circle cx='{x}' cy='{y}' r='{r}' fill='{color}'/>")
    text(x, y, str(n), size=15, anchor="middle", weight="700", fill="#ffffff")
def doc(x, y, wd, h, title, lines, stroke=INK, fill="#ffffff", size=10.5, lh=15):
    # a "document" shape with a folded corner
    f = 14
    w(f"<path d='M{x},{y+8} q0,-8 8,-8 h{wd-8-f} l{f},{f} v{h-f-8} q0,8 -8,8 h{-(wd-16)} q-8,0 -8,-8 z' fill='{fill}' stroke='{stroke}' stroke-width='2'/>")
    w(f"<path d='M{x+wd-f},{y} v{f} h{f}' fill='none' stroke='{stroke}' stroke-width='2'/>")
    text(x + 12, y + 20, title, size=11, weight="700", fill=stroke if stroke != INK else MUTED, font=MONO)
    for i, ln in enumerate(lines):
        text(x + 12, y + 42 + i * lh, ln, size=size, fill=INK, font=MONO)
def bubble(x, y, wd, h, title, lines, stroke, fill, ink, tail=None):
    rect(x, y, wd, h, fill, stroke, rx=16)
    if tail:  # small triangle pointing up to (tx, y)
        tx = tail
        w(f"<path d='M{tx-10},{y+1} L{tx},{y-14} L{tx+10},{y+1} z' fill='{fill}' stroke='{stroke}' stroke-width='2'/>")
        w(f"<line x1='{tx-9}' y1='{y+1}' x2='{tx+9}' y2='{y+1}' stroke='{fill}' stroke-width='3'/>")
    text(x + 16, y + 24, title, size=14, weight="700", fill=ink)
    for i, ln in enumerate(lines):
        text(x + 16, y + 48 + i * 18, ln, size=11.5, fill=ink)

w(f"<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 {W} {H}' role='img' aria-labelledby='t'>")
w("<title id='t'>Phase 4 Build — the whiteboard version</title>")
w("<defs>")
for mid, col in [("a", INK), ("aB", BLUE), ("aA", AMBER), ("aR", RED), ("aG", GREEN)]:
    w(f"<marker id='{mid}' viewBox='0 0 10 10' refX='9' refY='5' markerWidth='6' markerHeight='6' orient='auto-start-reverse'><path d='M0,0 L10,5 L0,10 z' fill='{col}'/></marker>")
w("</defs>")
rect(0, 0, W, H, "#ffffff", "none", rx=0, sw=0)

# ------------------------------------------------------------ title
text(40, 44, "Phase 4 · Build", size=30, weight="700")
text(40, 78, "Turn every approved test case into a Karate script, check it, and put it in Git. Nothing here touches the real API.", size=15, fill=MUTED)
text(W - 40, 44, "release 1 · no AI needed", size=13, anchor="end", fill=LINE)
text(W - 40, 64, "who: a worker pod does steps 1–4 · the api pod only serves the screens · Git holds the result", size=13, anchor="end", fill=LINE)

# ------------------------------------------------------------ main flow: big boxes
Y = 120
BH_ = 118
cols = [
    (40,   190, "Approved", ["test cases", "from Phase 3", "(one JSON each)"], GREEN, GREEN_BG, None),
    (300,  250, "Make the test data", ["the request body, per env:", "starts from the spec's example;", "negatives get ONE deliberate change"], INK, "#ffffff", 1),
    (610,  250, "Pick a template", ["a fixed rule looks at the", "case type → one of six", "hand-written templates"], INK, "#ffffff", 2),
    (920,  250, "Fill it in → .feature", ["copy the case's values into the", "template's holes · one .feature", "per endpoint, one Scenario per case"], INK, "#ffffff", 3),
    (1230, 250, "Check it", ["parse · static rules ·", "does the spec really", "document this?"], INK, "#ffffff", 4),
    (1540, 120, "Git", ["one commit", "per suite →", "suite READY"], INK, GRAY_BG, None),
]
for x, wd, t, lines, col, fill, n in cols:
    rect(x, Y, wd, BH_, fill, col, rx=16, sw=2.5)
    tx = x + 18
    if n:
        badge(x + 26, Y + 26, n); tx = x + 50
    text(tx, Y + 26, t, size=16, weight="700", fill=col if col != INK else INK)
    for i, ln in enumerate(lines):
        text(x + 18, Y + 54 + i * 17, ln, size=12.5, fill=MUTED)
for i in range(len(cols) - 1):
    x1 = cols[i][0] + cols[i][1]; x2 = cols[i + 1][0]
    arrow([(x1 + 4, Y + BH_ / 2), (x2 - 4, Y + BH_ / 2)], width=3)

text(265, Y - 14, "starts by itself when", size=10.5, anchor="middle", weight="600", fill=GREEN_INK)
text(265, Y - 1, "the suite is approved", size=10.5, anchor="middle", weight="600", fill=GREEN_INK)
bx1, bx2, by = 300, 1480, Y + BH_ + 10
w(f"<path d='M{bx1},{by} v8 h{bx2-bx1} v-8' fill='none' stroke='{MUTED}' stroke-width='1.5'/>")
text((bx1 + bx2) / 2, by + 20, "a worker pod does these four, one case at a time — then ONE Git commit for the whole suite. The api pod only serves the screens.", size=11, anchor="middle", fill=MUTED, style="italic")
text(1600, Y + BH_ + 24, "→ Phase 5 Run", size=11, anchor="middle", weight="700", fill=INK)

# ------------------------------------------------------------ story strip: the same example at every step
SY = 292
text(40, SY, "The same test case, followed through every step", size=14, weight="700", fill=MUTED)
DY = SY + 20
DH = 150
doc(40, DY, 230, DH, "TC-CLM-0031 (JSON)", [
    'title: Reject claim',
    '       without member id',
    'type: negative  P1',
    'step: POST /claims',
    '  remove  /memberId',
    'expect: 400',
    '  errorCode MISSING_FIELD'], stroke=GREEN, size=10.2, lh=14)
doc(300, DY, 250, DH, "data/qa/TC-CLM-0031.json", [
    '{',
    '  "memberId": "M-1001",',
    '  "amount": 120.50,',
    '  "serviceDate": "2026-09-01"',
    '}',
    '',
    '+ note: remove /memberId'], size=10.2, lh=14)
doc(610, DY, 250, DH, "select_template(case)", [
    'type = negative',
    'steps = 1',
    'mutations = 1  (on body)',
    '',
    '→ field_negatives_outline',
    '',
    '(same input, same answer)'], size=10.2, lh=14)
doc(920, DY, 250, DH, "features/createClaim.feature", [
    '@TC-CLM-0031 @p1 @negative',
    'Scenario Outline: Reject …',
    '  * def body = read(data)',
    '  Given path \'/claims\'',
    '  When method POST',
    '  Then status <status>',
    '  | remove | /memberId | 400 |'], size=10.2, lh=14)
doc(1230, DY, 250, DH, "checks", [
    'parse     ✓ valid Karate',
    'static    ✓ no URL, no secret,',
    '            @TC- tag present',
    'contract  ✓ 400 is documented',
    '            for POST /claims',
    '',
    'all ✓ → commit'], stroke=GREEN, size=10.2, lh=14)
doc(1540, DY, 120, DH, "commit a1b2c3", [
    'claims/',
    ' features/',
    ' data/qa/',
    ' manifest',
    '',
    'script row:',
    'valid ✓'], size=10.2, lh=14)
for x1, x2 in [(270, 300), (550, 610), (860, 920), (1170, 1230), (1480, 1540)]:
    arrow([(x1 + 4, DY + DH / 2), (x2 - 4, DY + DH / 2)], color=INK, width=1.6)

# ------------------------------------------------------------ three callouts
CY = 512
bubble(40, CY, 500, 180, "If a check fails →  needs attention", [
    "The script is saved but marked 'needs attention'.",
    "A QE opens it in the editor, fixes it, saves.",
    "Nothing is silently dropped; nothing is silently kept.",
    "",
    "Screens:  Scripts list  →  Script editor",
    "API:      GET /suites/{id}/scripts  ·  GET/PUT /scripts/{id}",
], AMBER, AMBER_BG, AMBER_INK)

bubble(580, CY, 520, 180, "A QE edited a script?  It is locked.", [
    "Saving in the editor commits under the QE's name",
    "and sets locked = true.",
    "The generator never overwrites a locked file again;",
    "if the spec changes later it only marks it 'stale'.",
    "",
    "API:  PUT /scripts/{id}  ·  POST /scripts/{id}/unlock",
], INK, "#ffffff", INK)

bubble(1140, CY, 520, 180, "Where does AI come in?  Only when no template fits.", [
    "Release 2. A multi-step business-rule case has no template,",
    "so select_template returns None → ai-worker writes the",
    "Scenario, using our helpers and two examples.",
    "It goes through the SAME checks in step 4.",
    "The platform, not the AI, stamps the case_id, tags and URL.",
    "Release 1: such a case is simply 'needs attention'.",
], BLUE, BLUE_BG, "#1e40af")

# ------------------------------------------------------------ the six templates + the static rules (two small tables)
TY = 722
rect(40, TY, 800, 200, "#ffffff", LINE, rx=14, sw=1.5)
text(56, TY + 24, "The six templates — written by hand first, against the pilot API, before any generator exists", size=13, weight="700")
tpl = [
    ("positive_schema_match", "happy path: call, expect the status, compare the body to the schema"),
    ("status_only", "401 / 403 / 404 / 405: switch login profile, expect the status"),
    ("field_negatives_outline", "one Scenario Outline, one row per bad field value"),
    ("dependency_chain", "create → get → update → delete, values passed along, cleanup"),
    ("security_identity", "call with another user's login, expect 403 or 404"),
    ("injection_outline", "one row per injection string, expect 400 or 422, never 500"),
]
for i, (a, b) in enumerate(tpl):
    text(56, TY + 50 + i * 24, a, size=11.5, weight="700", font=MONO)
    text(300, TY + 50 + i * 24, b, size=11.5, fill=MUTED)

rect(870, TY, 790, 200, "#ffffff", LINE, rx=14, sw=1.5)
text(886, TY + 24, "Step 4, the static rules — a script fails if it contains…", size=13, weight="700")
rules = [
    "a URL typed in (it must come from karate-config.js)",
    "anything that looks like a secret, or an Authorization header (the runner injects logins)",
    "no @TC- tag (the runner picks scenarios by tag, nothing else)",
    "anything that looks like personal data",
    "a variable used before any step defined it",
]
for i, ln in enumerate(rules):
    text(886, TY + 50 + i * 24, "✗  " + ln, size=11.5, fill=MUTED)
text(886, TY + 50 + 5 * 24 + 4, "and the contract rule: every status and field the script asserts must exist in the spec.", size=11.5, weight="600", fill=GREEN_INK)

# footer
text(40, H - 40, "Done when:", size=12.5, weight="700", fill=GREEN_INK)
text(130, H - 40, "approve a suite → a Karate project appears in Git with every script valid · edit one script, regenerate, and it is untouched · a run (Phase 5) can start from the commit id.", size=12, fill=GREEN_INK)
text(40, H - 18, "Remember: the test-case JSON is the truth; a .feature file is just a rendering of it. Fix the template, not the file — unless a QE deliberately locked it.", size=12, fill=MUTED, style="italic")

w("</svg>")
open("out/architecture-4-build.svg", "w").write("\n".join(out))
print("ok")
