import os
os.makedirs('out', exist_ok=True)
#!/usr/bin/env python3
"""Phase 4 Build — whiteboard-style, one example flowing through."""
FONT = "Inter, 'Segoe UI', Helvetica, Arial, sans-serif"
MONO = "'JetBrains Mono', SFMono-Regular, Consolas, 'Liberation Mono', monospace"
INK, MUTED, LINE = "#1f2937", "#6b7280", "#9ca3af"
BLUE, BLUE_BG = "#2563eb", "#eff6ff"
GREEN, GREEN_BG, GREEN_INK = "#059669", "#ecfdf5", "#065f46"
AMBER, AMBER_BG, AMBER_INK = "#d97706", "#fffbeb", "#92400e"
RED, RED_BG, RED_INK = "#dc2626", "#fef2f2", "#991b1b"
GRAY_BG = "#f3f4f6"
W, H = 1700, 950
out = []
def w(s): out.append(s)
def esc(s): return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
def text(x, y, s, size=12, anchor="start", weight="normal", fill=INK, style="", font=FONT):
    st = f" font-style='{style}'" if style else ""
    lead = len(s) - len(s.lstrip(' '))
    s = '\u00a0' * lead + s.lstrip(' ')
    w(f"<text x='{x}' y='{y}' font-size='{size}' text-anchor='{anchor}' font-weight='{weight}' fill='{fill}'{st} dominant-baseline='middle' font-family=\"{font}\">{esc(s)}</text>")
def rect(x, y, wd, h, fill, stroke, rx=14, sw=2, dash=""):
    d = f" stroke-dasharray='{dash}'" if dash else ""
    w(f"<rect x='{x}' y='{y}' width='{wd}' height='{h}' rx='{rx}' fill='{fill}' stroke='{stroke}' stroke-width='{sw}'{d}/>")
def arrow(pts, color=INK, width=2.4, dashed=False):
    p = " ".join(f"{x},{y}" for x, y in pts)
    m = {INK: "a", BLUE: "aB", AMBER: "aA", RED: "aR", GREEN: "aG"}[color]
    d = " stroke-dasharray='7 5'" if dashed else ""
    w(f"<polyline points='{p}' fill='none' stroke='{color}' stroke-width='{width}'{d} stroke-linejoin='round' marker-end='url(#{m})'/>")
def badge(x, y, n, color=INK, r=15):
    w(f"<circle cx='{x}' cy='{y}' r='{r}' fill='{color}'/>")
    text(x, y, str(n), size=15, anchor="middle", weight="700", fill="#ffffff")
def doc(x, y, wd, h, title, lines, stroke=INK, fill="#ffffff", size=10.5, lh=15):
    # a "document" shape with a folded corner
    f = 14
    w(f"<path d='M{x},{y+8} q0,-8 8,-8 h{wd-8-f} l{f},{f} v{h-f-8} q0,8 -8,8 h{-(wd-16)} q-8,0 -8,-8 z' fill='{fill}' stroke='{stroke}' stroke-width='2'/>")
    w(f"<path d='M{x+wd-f},{y} v{f} h{f}' fill='none' stroke='{stroke}' stroke-width='2'/>")
    text(x + 12, y + 20, title, size=11, weight="700", fill=stroke if stroke != INK else MUTED, font=MONO)
    for i, ln in enumerate(lines):
        text(x + 12, y + 42 + i * lh, ln, size=size, fill=INK, font=MONO)
def bubble(x, y, wd, h, title, lines, stroke, fill, ink, tail=None):
    rect(x, y, wd, h, fill, stroke, rx=16)
    if tail:  # small triangle pointing up to (tx, y)
        tx = tail
        w(f"<path d='M{tx-10},{y+1} L{tx},{y-14} L{tx+10},{y+1} z' fill='{fill}' stroke='{stroke}' stroke-width='2'/>")
        w(f"<line x1='{tx-9}' y1='{y+1}' x2='{tx+9}' y2='{y+1}' stroke='{fill}' stroke-width='3'/>")
    text(x + 16, y + 24, title, size=14, weight="700", fill=ink)
    for i, ln in enumerate(lines):
        text(x + 16, y + 48 + i * 18, ln, size=11.5, fill=ink)

w(f"<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 {W} {H}' role='img' aria-labelledby='t'>")
w("<title id='t'>How the AI generates test cases — the whiteboard version</title>")
w("<defs>")
for mid, col in [("a", INK), ("aB", BLUE), ("aA", AMBER), ("aR", RED), ("aG", GREEN), ("aP", "#7c3aed")]:
    w(f"<marker id='{mid}' viewBox='0 0 10 10' refX='9' refY='5' markerWidth='6' markerHeight='6' orient='auto-start-reverse'><path d='M0,0 L10,5 L0,10 z' fill='{col}'/></marker>")
w("</defs>")
rect(0, 0, W, H, "#ffffff", "none", rx=0, sw=0)



PURPLE, PURPLE_BG, PURPLE_INK = "#7c3aed", "#f5f3ff", "#5b21b6"
def arrow(pts, color=INK, width=2.4, dashed=False):
    p = " ".join(f"{x},{y}" for x, y in pts)
    m = {INK: "a", BLUE: "aB", AMBER: "aA", RED: "aR", GREEN: "aG", PURPLE: "aP"}[color]
    d = " stroke-dasharray='7 5'" if dashed else ""
    w(f"<polyline points='{p}' fill='none' stroke='{color}' stroke-width='{width}'{d} stroke-linejoin='round' marker-end='url(#{m})'/>")
def steps_row(Y, cols, BH_=118):
    for x, wd, t, lines, col, fill, n in cols:
        rect(x, Y, wd, BH_, fill, col, rx=16, sw=2.5)
        tx = x + 18
        if n:
            badge(x + 26, Y + 26, n, col); tx = x + 50
        text(tx, Y + 26, t, size=16, weight="700", fill=col if col != INK else INK)
        for i, ln in enumerate(lines):
            text(x + 18, Y + 54 + i * 17, ln, size=12.5, fill=MUTED)
    for i in range(len(cols) - 1):
        x1 = cols[i][0] + cols[i][1]; x2 = cols[i + 1][0]
        arrow([(x1 + 4, Y + BH_ / 2), (x2 - 4, Y + BH_ / 2)], width=3)
def bracket(x1, x2, y, label, col=MUTED):
    w(f"<path d='M{x1},{y} v8 h{x2-x1} v-8' fill='none' stroke='{col}' stroke-width='1.5'/>")
    text((x1 + x2) / 2, y + 20, label, size=11, anchor="middle", fill=col, style="italic")
def table(x, y, wd, h, title, rows, kx=270, size=11.5):
    rect(x, y, wd, h, "#ffffff", LINE, rx=14, sw=1.5)
    text(x + 16, y + 24, title, size=13, weight="700")
    for i, (a, b) in enumerate(rows):
        text(x + 16, y + 50 + i * 24, a, size=size, weight="700", font=MONO)
        text(x + kx, y + 50 + i * 24, b, size=size, fill=MUTED)
def footer(done, remember):
    text(40, H - 42, "Done when:", size=12.5, weight="700", fill=GREEN_INK)
    text(130, H - 42, done, size=11.5, fill=GREEN_INK)
    text(40, H - 18, remember, size=12, fill=MUTED, style="italic")

def code(x, y, wd, h, title, lines, stroke=INK, fill="#ffffff", size=10.5, lh=15, hi=None):
    rect(x, y, wd, h, fill, stroke, rx=12, sw=2)
    text(x + 14, y + 20, title, size=12, weight="700", fill=stroke if stroke != INK else INK)
    for i, ln in enumerate(lines):
        col = (hi or {}).get(i, INK)
        text(x + 14, y + 42 + i * lh, ln, size=size, fill=col, font=MONO)

text(40, 44, "How the AI generates test cases — it is a pipeline with one model call, not a chatbot", size=28, weight="700")
text(40, 78, "Release 2. The rule engine has already written every case the spec's facts allow. The AI is asked one narrow question per endpoint: 'here are the gaps — propose cases for them, as JSON'. Then code checks the answer.", size=15, fill=MUTED)

Y = 120
steps_row(Y, [
    (40,   190, "A gap", ["after Phase 3 step 3:", "an endpoint under its", "coverage threshold"], AMBER, AMBER_BG, None),
    (300,  250, "Build a small context", ["ONE endpoint's schema slice,", "its responses, confirmed rules,", "the gap list, 3 approved examples"], INK, "#ffffff", 1),
    (610,  250, "One model call", ["system prompt (versioned file)", "+ context → must answer as a", "list of test-case JSON"], BLUE, BLUE_BG, 2),
    (920,  250, "Check the answer", ["JSON shape? endpoint exists?", "status documented? fields real?", "no → send the error back, once"], INK, "#ffffff", 3),
    (1230, 250, "Save as drafts", ["case_id minted by the platform;", "confidence medium or low —", "never high; origin = ai"], INK, "#ffffff", 4),
    (1540, 120, "QE review", ["same queue as", "engine cases;", "one by one"], GREEN, GREEN_BG, None),
])
bracket(300, 550, Y + 128, "worker pod")
bracket(610, 1480, Y + 128, "ai-worker pod (namespace ai) — the only process that may call the model · loop: at most 3 rounds, then review regardless", BLUE)

SY = 292
text(40, SY, "One gap followed through — PUT /claims/{id}, business rule R-12 'an adjudicated claim cannot be updated' is not covered", size=14, weight="700", fill=MUTED)
DY = SY + 20; DH = 190
code(40, DY, 230, DH, "the gap", [
    'endpoint: updateClaim',
    'dimension: business_rule',
    'missing: rule:R-12',
    'round: 1 of 3',
    '',
    'ai_job #77  kind=design',
    'prompt_version: design@6',
    'budget: 8k tokens, 60 s'], stroke=AMBER, fill=AMBER_BG, size=10, lh=15)
code(300, DY, 250, DH, "context given (and nothing else)", [
    'PUT /claims/{id}: request',
    '  schema, responses 200 404',
    '  409 (CLAIM_LOCKED)',
    'rule R-12 + source sentence',
    'gap list: [rule:R-12]',
    '3 approved cases as examples',
    'the TestCaseSpec JSON schema',
    '"structural, schema, boundary',
    ' cases already exist — do',
    ' NOT repeat them"'], size=10, lh=15)
code(610, DY, 250, DH, "model answer (trimmed)", [
    '[{ "title": "Reject update',
    '     of adjudicated claim",',
    '   "type": "negative",',
    '   "steps": [create → 201,',
    '     adjudicate → 200,',
    '     update → expect 409,',
    '       errorCode CLAIM_LOCKED],',
    '   "coverage_targets":',
    '     ["rule:R-12",',
    '      "op:updateClaim:409"] }]'], stroke=BLUE, fill=BLUE_BG, size=10, lh=15)
code(920, DY, 250, DH, "checks", [
    'JSON matches schema      ✓',
    'updateClaim exists       ✓',
    '409 documented           ✓',
    '$.errorCode in 409 body  ✓',
    'refs point to earlier    ✓',
    '  steps',
    'exactly one mutation     ✓',
    'no Authorization header  ✓',
    'case_id is null          ✓',
    '→ accept'], stroke=GREEN, size=10, lh=15)
code(1230, DY, 250, DH, "saved draft", [
    'case_id: TC-CLM-0142  (minted)',
    'origin: ai',
    'confidence: medium',
    '  (every assertion traces to',
    '   a confirmed rule or a',
    '   documented response)',
    'source_rule_id: R-12',
    'status: draft',
    'ai_job #77: done,',
    '  1,920 tokens, $0.004'], size=10, lh=15)
code(1540, DY, 120, DH, "review", [
    'QE opens',
    'TC-0142',
    'reads the',
    'rule and',
    'the steps',
    '→ approve',
    '',
    'gap R-12',
    'closed'], stroke=GREEN, fill=GREEN_BG, size=10, lh=15)
for x1, x2 in [(270, 300), (550, 610), (860, 920), (1170, 1230), (1480, 1540)]:
    arrow([(x1 + 4, DY + DH / 2), (x2 - 4, DY + DH / 2)], color=INK, width=1.6)

CY = 550
bubble(40, CY, 500, 190, "What the model never sees", [
    "the whole spec (only one endpoint's slice)",
    "real data records (only field names and value shapes)",
    "credentials, tokens, hostnames in stack traces",
    "any field marked sensitive — the PHI guard runs on every",
    "prompt before it leaves the platform",
    "The context is small on purpose: cheaper, faster, and the",
    "model cannot invent cases for endpoints it was not shown.",
], RED, RED_BG, RED_INK)
bubble(580, CY, 520, 190, "Why an AI case can never be 'high' confidence", [
    "high = derived from an explicit fact in the spec by code.",
    "An AI case is a proposal: medium when every assertion traces",
    "to a confirmed rule or a documented response, low otherwise.",
    "Low-confidence cases cannot be bulk-approved — a person reads",
    "each one. This is the whole safety model: code proves, AI",
    "proposes, a QE decides. Nothing invalid is ever saved as a draft.",
], GREEN, GREEN_BG, GREEN_INK)
bubble(1140, CY, 520, 190, "What we measure before it ships, and the kill switch", [
    "A golden set: 3–5 internal APIs with approved cases. On every",
    "change to a prompt, model or graph, CI runs the set and checks:",
    "  ≥ 95 % of AI cases pass the contract check first try",
    "  ≥ 90 % business-rule coverage after 3 rounds",
    "  ≤ 10 % duplicates · cost ≤ 120 % of the previous baseline",
    "Pilot rule: if QEs reject > 30 % of AI drafts, keep AI for rules only.",
], BLUE, BLUE_BG, "#1e40af")

TY = 770
table(40, TY, 800, 150, "The graph in code — a fixed sequence, no free-form agent (ai/graphs/design/)", [
    ("nodes", "slice_context → call_model → validate → (repair once) → save_drafts — each a plain function"),
    ("LLMProvider.complete()", "the ONE way to call a model: prompt, JSON schema, tier fast|strong, token budget, timeout"),
    ("prompts/", "versioned files; prompt_version is stored on every ai_job so a result can be explained later"),
    ("in tests", "a recorded-response provider replaces Gemini, so the graph runs in CI without a model"),
], kx=230)
table(870, TY, 790, 150, "Where else the same pattern is used (same graph shape, different question)", [
    ("rules  (R2)", "'here are Jira stories — list the business rules, each with its source sentence'"),
    ("csv_mapping  (R2)", "'here are CSV headers + 5 masked rows — map columns to these fields, with confidence'"),
    ("scripts  (R2)", "'here is one case with no template — write the Scenario inside this framework'"),
    ("triage  (R3)", "'here is a failure the rules could not settle — category, reason, draft defect'"),
], kx=200)
text(40, H - 18, "Remember: the model is asked a narrow question with a JSON answer; code decides whether the answer is usable; a person decides whether it is right.", size=12, fill=MUTED, style="italic")
w("</svg>")
open("out/knowledge-B-ai-test-cases.svg", "w").write("\n".join(out))
print("ok")
