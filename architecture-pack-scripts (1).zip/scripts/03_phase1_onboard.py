import os
os.makedirs('out', exist_ok=True)
#!/usr/bin/env python3
"""Phase 4 Build — whiteboard-style, one example flowing through."""
FONT = "Inter, 'Segoe UI', Helvetica, Arial, sans-serif"
MONO = "'JetBrains Mono', SFMono-Regular, Consolas, 'Liberation Mono', monospace"
INK, MUTED, LINE = "#1f2937", "#6b7280", "#9ca3af"
BLUE, BLUE_BG = "#2563eb", "#eff6ff"
GREEN, GREEN_BG, GREEN_INK = "#059669", "#ecfdf5", "#065f46"
AMBER, AMBER_BG, AMBER_INK = "#d97706", "#fffbeb", "#92400e"
RED, RED_BG, RED_INK = "#dc2626", "#fef2f2", "#991b1b"
GRAY_BG = "#f3f4f6"
W, H = 1700, 1010
out = []
def w(s): out.append(s)
def esc(s): return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
def text(x, y, s, size=12, anchor="start", weight="normal", fill=INK, style="", font=FONT):
    st = f" font-style='{style}'" if style else ""
    lead = len(s) - len(s.lstrip(' '))
    s = '\u00a0' * lead + s.lstrip(' ')
    w(f"<text x='{x}' y='{y}' font-size='{size}' text-anchor='{anchor}' font-weight='{weight}' fill='{fill}'{st} dominant-baseline='middle' font-family=\"{font}\">{esc(s)}</text>")
def rect(x, y, wd, h, fill, stroke, rx=14, sw=2, dash=""):
    d = f" stroke-dasharray='{dash}'" if dash else ""
    w(f"<rect x='{x}' y='{y}' width='{wd}' height='{h}' rx='{rx}' fill='{fill}' stroke='{stroke}' stroke-width='{sw}'{d}/>")
def arrow(pts, color=INK, width=2.4, dashed=False):
    p = " ".join(f"{x},{y}" for x, y in pts)
    m = {INK: "a", BLUE: "aB", AMBER: "aA", RED: "aR", GREEN: "aG"}[color]
    d = " stroke-dasharray='7 5'" if dashed else ""
    w(f"<polyline points='{p}' fill='none' stroke='{color}' stroke-width='{width}'{d} stroke-linejoin='round' marker-end='url(#{m})'/>")
def badge(x, y, n, color=INK, r=15):
    w(f"<circle cx='{x}' cy='{y}' r='{r}' fill='{color}'/>")
    text(x, y, str(n), size=15, anchor="middle", weight="700", fill="#ffffff")
def doc(x, y, wd, h, title, lines, stroke=INK, fill="#ffffff", size=10.5, lh=15):
    # a "document" shape with a folded corner
    f = 14
    w(f"<path d='M{x},{y+8} q0,-8 8,-8 h{wd-8-f} l{f},{f} v{h-f-8} q0,8 -8,8 h{-(wd-16)} q-8,0 -8,-8 z' fill='{fill}' stroke='{stroke}' stroke-width='2'/>")
    w(f"<path d='M{x+wd-f},{y} v{f} h{f}' fill='none' stroke='{stroke}' stroke-width='2'/>")
    text(x + 12, y + 20, title, size=11, weight="700", fill=stroke if stroke != INK else MUTED, font=MONO)
    for i, ln in enumerate(lines):
        text(x + 12, y + 42 + i * lh, ln, size=size, fill=INK, font=MONO)
def bubble(x, y, wd, h, title, lines, stroke, fill, ink, tail=None):
    rect(x, y, wd, h, fill, stroke, rx=16)
    if tail:  # small triangle pointing up to (tx, y)
        tx = tail
        w(f"<path d='M{tx-10},{y+1} L{tx},{y-14} L{tx+10},{y+1} z' fill='{fill}' stroke='{stroke}' stroke-width='2'/>")
        w(f"<line x1='{tx-9}' y1='{y+1}' x2='{tx+9}' y2='{y+1}' stroke='{fill}' stroke-width='3'/>")
    text(x + 16, y + 24, title, size=14, weight="700", fill=ink)
    for i, ln in enumerate(lines):
        text(x + 16, y + 48 + i * 18, ln, size=11.5, fill=ink)

w(f"<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 {W} {H}' role='img' aria-labelledby='t'>")
w("<title id='t'>Phase 1 Onboard — the whiteboard version</title>")
w("<defs>")
for mid, col in [("a", INK), ("aB", BLUE), ("aA", AMBER), ("aR", RED), ("aG", GREEN), ("aP", "#7c3aed")]:
    w(f"<marker id='{mid}' viewBox='0 0 10 10' refX='9' refY='5' markerWidth='6' markerHeight='6' orient='auto-start-reverse'><path d='M0,0 L10,5 L0,10 z' fill='{col}'/></marker>")
w("</defs>")
rect(0, 0, W, H, "#ffffff", "none", rx=0, sw=0)



PURPLE, PURPLE_BG, PURPLE_INK = "#7c3aed", "#f5f3ff", "#5b21b6"
def arrow(pts, color=INK, width=2.4, dashed=False):
    p = " ".join(f"{x},{y}" for x, y in pts)
    m = {INK: "a", BLUE: "aB", AMBER: "aA", RED: "aR", GREEN: "aG", PURPLE: "aP"}[color]
    d = " stroke-dasharray='7 5'" if dashed else ""
    w(f"<polyline points='{p}' fill='none' stroke='{color}' stroke-width='{width}'{d} stroke-linejoin='round' marker-end='url(#{m})'/>")
def steps_row(Y, cols, BH_=118):
    for x, wd, t, lines, col, fill, n in cols:
        rect(x, Y, wd, BH_, fill, col, rx=16, sw=2.5)
        tx = x + 18
        if n:
            badge(x + 26, Y + 26, n, col); tx = x + 50
        text(tx, Y + 26, t, size=16, weight="700", fill=col if col != INK else INK)
        for i, ln in enumerate(lines):
            text(x + 18, Y + 54 + i * 17, ln, size=12.5, fill=MUTED)
    for i in range(len(cols) - 1):
        x1 = cols[i][0] + cols[i][1]; x2 = cols[i + 1][0]
        arrow([(x1 + 4, Y + BH_ / 2), (x2 - 4, Y + BH_ / 2)], width=3)
def bracket(x1, x2, y, label, col=MUTED):
    w(f"<path d='M{x1},{y} v8 h{x2-x1} v-8' fill='none' stroke='{col}' stroke-width='1.5'/>")
    text((x1 + x2) / 2, y + 20, label, size=11, anchor="middle", fill=col, style="italic")
def table(x, y, wd, h, title, rows, kx=270, size=11.5):
    rect(x, y, wd, h, "#ffffff", LINE, rx=14, sw=1.5)
    text(x + 16, y + 24, title, size=13, weight="700")
    for i, (a, b) in enumerate(rows):
        text(x + 16, y + 50 + i * 24, a, size=size, weight="700", font=MONO)
        text(x + kx, y + 50 + i * 24, b, size=size, fill=MUTED)
def footer(done, remember):
    text(40, H - 42, "Done when:", size=12.5, weight="700", fill=GREEN_INK)
    text(130, H - 42, done, size=11.5, fill=GREEN_INK)
    text(40, H - 18, remember, size=12, fill=MUTED, style="italic")

text(40, 44, "Phase 1 · Onboard", size=30, weight="700")
text(40, 78, "A QE registers one API: where it runs, how to log in, and its OpenAPI spec. The platform locks the secrets away, cleans the spec, and does one live check before anything else may start.", size=15, fill=MUTED)
text(W - 40, 44, "release 1 · no AI", size=13, anchor="end", fill=LINE)
text(W - 40, 64, "who: a QE does 1–3 in the browser · the api pod answers each request at once · a worker pod does 4 and 5 · a QE decides at 6 only if it is yellow", size=13, anchor="end", fill=LINE)

Y = 120
steps_row(Y, [
    (40,   190, "QE", ["has an API to test,", "a QA environment,", "and its spec file"], GREEN, GREEN_BG, None),
    (300,  250, "Workflow + environment", ["a workflow = one API. Add", "dev / qa / staging: base URL,", "rate limit, freeze windows"], INK, "#ffffff", 1),
    (610,  250, "Credentials → vault", ["a named login (default,", "member_b …); the secret is", "typed ONCE → Secret Manager"], RED, RED_BG, 2),
    (920,  250, "Upload the spec", ["OpenAPI 3 or Swagger 2, file or", "URL → saved as version n+1,", "a job is queued, 202 at once"], INK, "#ffffff", 3),
    (1230, 250, "Clean · check · smoke", ["worker: convert, lint, stable ids,", "diff vs last version, scan for", "PHI, then one live call"], INK, "#ffffff", 4),
    (1540, 120, "Readiness", ["green → go", "yellow → ack", "red → fix"], GREEN, GREEN_BG, None),
])
bracket(300, 1170, Y + 128, "api pod — each request answered in < 1 s, rows written, nothing slow")
bracket(1230, 1480, Y + 128, "worker pod — one queued job, < 60 s")
text(1600, Y + 128 + 20, "→ Phase 2", size=11, anchor="middle", weight="700", fill=INK)

SY = 292
text(40, SY, "One API followed through every step — claims-api on the QA environment", size=14, weight="700", fill=MUTED)
DY = SY + 20; DH = 160
doc(40, DY, 230, DH, "what the QE has", [
    'claims-api',
    'QA: https://qa.claims',
    '        .example.com',
    'login: OAuth2 client',
    '  id + secret',
    'spec: claims-v3.yaml',
    '  (Swagger 2)'], stroke=GREEN, size=10.2, lh=14)
doc(300, DY, 250, DH, "rows: workflow · environment", [
    'workflow',
    ' name: claims  kind: api',
    'environment',
    ' name: qa',
    ' base_url: https://qa.claims…',
    ' rate_limit_rps: 20',
    ' concurrency_limit: 3',
    ' freeze: Sun 00:00–04:00'], size=10.2, lh=14)
doc(610, DY, 250, DH, "credential_profile", [
    'POST …/credential-profiles',
    ' { name: default,',
    '   auth_type: oauth2_cc,',
    '   client_secret: ••••• }',
    '→ Secret Manager writes it',
    '→ DB row keeps ONLY',
    ' secret_ref: projects/p/',
    '  secrets/claims-qa-default/v1'], stroke=RED, size=10.2, lh=14)
doc(920, DY, 250, DH, "spec_version 3", [
    'raw_uri:  inputs/claims/v3.yaml',
    'format:   swagger2',
    'status:   uploaded',
    '',
    'outbox → platform-jobs:',
    ' "ingest spec_version 3"',
    '',
    'reply: 202 { version: 3 }'], size=10.2, lh=14)
doc(1230, DY, 250, DH, "worker job log", [
    'normalize  swagger2 → oas3 ✓',
    'lint       2 warnings',
    '  (missing operationId ×2)',
    'target ids 5 · diff vs v2: +1',
    'PHI scan   samples clean ✓',
    'smoke      token ✓',
    '           GET /members/1 ✓',
    '           schema match ✓'], size=10.2, lh=14)
doc(1540, DY, 120, DH, "readiness", [
    'YELLOW',
    '2 warnings',
    '',
    'QE ack:',
    '"ids come',
    ' in v4"',
    '→ accepted'], stroke=GREEN, size=10.2, lh=14)
for x1, x2 in [(270, 300), (550, 610), (860, 920), (1170, 1230), (1480, 1540)]:
    arrow([(x1 + 4, DY + DH / 2), (x2 - 4, DY + DH / 2)], color=INK, width=1.6)

CY = 522
bubble(40, CY, 500, 186, "Secrets: written once, never seen again", [
    "The secret arrives in exactly one request body, on its own",
    "router whose body is never logged. It goes to Secret Manager",
    "and comes back as an address (secret_ref). Only the address",
    "is stored. Nothing — not the DB, logs, Git, evidence or a",
    "prompt — ever holds the value. Pods that need it read it by",
    "address with their own service account. Rotation = new version.",
], RED, RED_BG, RED_INK)
bubble(580, CY, 520, 186, "Green · yellow · red — who decides", [
    "green: nothing found → accepted automatically, no click.",
    "yellow: warnings only (lint, a sample that does not fit) → the",
    "QE presses accept and types a reason; the reason is audited.",
    "red: a blocking failure (cannot reach the host, no token, spec",
    "does not parse, PHI in a sample) → nothing can continue. The",
    "QE fixes the input and uploads again = a NEW version, never an edit.",
], AMBER, AMBER_BG, AMBER_INK)
bubble(1140, CY, 520, 186, "api pod vs worker pod — same image, two jobs", [
    "The api pod answers every request in under a second: write",
    "the row, put a job in the queue (same DB transaction, via the",
    "outbox table), reply 202. The worker pod takes the job and",
    "does the slow part. Neither knows which it is — the entrypoint",
    "decides. This is why an upload never times out and why a",
    "deploy never kills a half-done smoke check.",
], INK, "#ffffff", INK)

TY = 738
table(40, TY, 800, 196, "The smoke check — what it does, and what it must never do (make it a package: Phase 5 reuses it)", [
    ("1  reach", "TLS to environment.base_url (client certificate if the profile needs one)"),
    ("2  log in", "a token or key check for EVERY credential profile on the environment"),
    ("3  one safe call", "ONE read-only endpoint per profile; compare the response with the spec's schema"),
    ("4  samples", "if example payloads were uploaded: do they validate against the spec?"),
    ("result", "any blocking failure = red · warnings only = yellow · clean = green, in readiness_report"),
    ("never", "call an endpoint that changes data · touch production · put a secret value in a log or the report"),
], kx=180)
table(870, TY, 790, 196, "The tables this phase writes — and the one rule on each", [
    ("workflow", "one API under test; current_spec_version_id points at the latest accepted spec"),
    ("environment", "dev | qa | staging only; base_url, rate_limit_rps, concurrency_limit, freeze_windows"),
    ("credential_profile", "name, auth_type, scopes, secret_ref — the address, never the value"),
    ("spec_version", "IMMUTABLE: version, format, raw_uri, normalized_uri, lint, diff, readiness, readiness_report, status"),
    ("audit_event · outbox", "who did what (accept reasons live here) · the queued job, written in the same transaction"),
    ("every table", "team_id + a row-level security policy; another team gets 404, in the API and in SQL"),
], kx=230)
footer("create a workflow, a QA environment and two credential profiles — the secret value appears nowhere · upload an OpenAPI 3 and a Swagger 2 spec, both convert, readiness green in < 60 s · re-upload: the diff lists added / removed / changed · another team sees 404.",
       "Remember: credentials go to the vault before anything else is stored; a spec version is never edited, a change is a new version; the smoke check reads, it never writes.")
w("</svg>")
open("out/architecture-1-onboard.svg", "w").write("\n".join(out))
print("ok")
