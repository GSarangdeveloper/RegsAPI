import os
os.makedirs('out', exist_ok=True)
#!/usr/bin/env python3
"""Phase 4 Build — whiteboard-style, one example flowing through."""
FONT = "Inter, 'Segoe UI', Helvetica, Arial, sans-serif"
MONO = "'JetBrains Mono', SFMono-Regular, Consolas, 'Liberation Mono', monospace"
INK, MUTED, LINE = "#1f2937", "#6b7280", "#9ca3af"
BLUE, BLUE_BG = "#2563eb", "#eff6ff"
GREEN, GREEN_BG, GREEN_INK = "#059669", "#ecfdf5", "#065f46"
AMBER, AMBER_BG, AMBER_INK = "#d97706", "#fffbeb", "#92400e"
RED, RED_BG, RED_INK = "#dc2626", "#fef2f2", "#991b1b"
GRAY_BG = "#f3f4f6"
W, H = 1900, 1080
out = []
def w(s): out.append(s)
def esc(s): return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
def text(x, y, s, size=12, anchor="start", weight="normal", fill=INK, style="", font=FONT):
    st = f" font-style='{style}'" if style else ""
    lead = len(s) - len(s.lstrip(' '))
    s = '\u00a0' * lead + s.lstrip(' ')
    w(f"<text x='{x}' y='{y}' font-size='{size}' text-anchor='{anchor}' font-weight='{weight}' fill='{fill}'{st} dominant-baseline='middle' font-family=\"{font}\">{esc(s)}</text>")
def rect(x, y, wd, h, fill, stroke, rx=14, sw=2, dash=""):
    d = f" stroke-dasharray='{dash}'" if dash else ""
    w(f"<rect x='{x}' y='{y}' width='{wd}' height='{h}' rx='{rx}' fill='{fill}' stroke='{stroke}' stroke-width='{sw}'{d}/>")
def arrow(pts, color=INK, width=2.4, dashed=False):
    p = " ".join(f"{x},{y}" for x, y in pts)
    m = {INK: "a", BLUE: "aB", AMBER: "aA", RED: "aR", GREEN: "aG"}[color]
    d = " stroke-dasharray='7 5'" if dashed else ""
    w(f"<polyline points='{p}' fill='none' stroke='{color}' stroke-width='{width}'{d} stroke-linejoin='round' marker-end='url(#{m})'/>")
def badge(x, y, n, color=INK, r=15):
    w(f"<circle cx='{x}' cy='{y}' r='{r}' fill='{color}'/>")
    text(x, y, str(n), size=15, anchor="middle", weight="700", fill="#ffffff")
def doc(x, y, wd, h, title, lines, stroke=INK, fill="#ffffff", size=10.5, lh=15):
    # a "document" shape with a folded corner
    f = 14
    w(f"<path d='M{x},{y+8} q0,-8 8,-8 h{wd-8-f} l{f},{f} v{h-f-8} q0,8 -8,8 h{-(wd-16)} q-8,0 -8,-8 z' fill='{fill}' stroke='{stroke}' stroke-width='2'/>")
    w(f"<path d='M{x+wd-f},{y} v{f} h{f}' fill='none' stroke='{stroke}' stroke-width='2'/>")
    text(x + 12, y + 20, title, size=11, weight="700", fill=stroke if stroke != INK else MUTED, font=MONO)
    for i, ln in enumerate(lines):
        text(x + 12, y + 42 + i * lh, ln, size=size, fill=INK, font=MONO)
def bubble(x, y, wd, h, title, lines, stroke, fill, ink, tail=None):
    rect(x, y, wd, h, fill, stroke, rx=16)
    if tail:  # small triangle pointing up to (tx, y)
        tx = tail
        w(f"<path d='M{tx-10},{y+1} L{tx},{y-14} L{tx+10},{y+1} z' fill='{fill}' stroke='{stroke}' stroke-width='2'/>")
        w(f"<line x1='{tx-9}' y1='{y+1}' x2='{tx+9}' y2='{y+1}' stroke='{fill}' stroke-width='3'/>")
    text(x + 16, y + 24, title, size=14, weight="700", fill=ink)
    for i, ln in enumerate(lines):
        text(x + 16, y + 48 + i * 18, ln, size=11.5, fill=ink)

w(f"<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 {W} {H}' role='img' aria-labelledby='t'>")
w("<title id='t'>GCP deployment architecture — the whiteboard version</title>")
w("<defs>")
for mid, col in [("a", INK), ("aB", BLUE), ("aA", AMBER), ("aR", RED), ("aG", GREEN), ("aP", "#7c3aed")]:
    w(f"<marker id='{mid}' viewBox='0 0 10 10' refX='9' refY='5' markerWidth='6' markerHeight='6' orient='auto-start-reverse'><path d='M0,0 L10,5 L0,10 z' fill='{col}'/></marker>")
w("</defs>")
rect(0, 0, W, H, "#ffffff", "none", rx=0, sw=0)



PURPLE, PURPLE_BG, PURPLE_INK = "#7c3aed", "#f5f3ff", "#5b21b6"
def arrow(pts, color=INK, width=2.4, dashed=False):
    p = " ".join(f"{x},{y}" for x, y in pts)
    m = {INK: "a", BLUE: "aB", AMBER: "aA", RED: "aR", GREEN: "aG", PURPLE: "aP"}[color]
    d = " stroke-dasharray='7 5'" if dashed else ""
    w(f"<polyline points='{p}' fill='none' stroke='{color}' stroke-width='{width}'{d} stroke-linejoin='round' marker-end='url(#{m})'/>")
def steps_row(Y, cols, BH_=118):
    for x, wd, t, lines, col, fill, n in cols:
        rect(x, Y, wd, BH_, fill, col, rx=16, sw=2.5)
        tx = x + 18
        if n:
            badge(x + 26, Y + 26, n, col); tx = x + 50
        text(tx, Y + 26, t, size=16, weight="700", fill=col if col != INK else INK)
        for i, ln in enumerate(lines):
            text(x + 18, Y + 54 + i * 17, ln, size=12.5, fill=MUTED)
    for i in range(len(cols) - 1):
        x1 = cols[i][0] + cols[i][1]; x2 = cols[i + 1][0]
        arrow([(x1 + 4, Y + BH_ / 2), (x2 - 4, Y + BH_ / 2)], width=3)
def bracket(x1, x2, y, label, col=MUTED):
    w(f"<path d='M{x1},{y} v8 h{x2-x1} v-8' fill='none' stroke='{col}' stroke-width='1.5'/>")
    text((x1 + x2) / 2, y + 20, label, size=11, anchor="middle", fill=col, style="italic")
def table(x, y, wd, h, title, rows, kx=270, size=11.5):
    rect(x, y, wd, h, "#ffffff", LINE, rx=14, sw=1.5)
    text(x + 16, y + 24, title, size=13, weight="700")
    for i, (a, b) in enumerate(rows):
        text(x + 16, y + 50 + i * 24, a, size=size, weight="700", font=MONO)
        text(x + kx, y + 50 + i * 24, b, size=size, fill=MUTED)
def footer(done, remember):
    text(40, H - 42, "Done when:", size=12.5, weight="700", fill=GREEN_INK)
    text(130, H - 42, done, size=11.5, fill=GREEN_INK)
    text(40, H - 18, remember, size=12, fill=MUTED, style="italic")

GCP_BLUE, GCP_BG = "#4285f4", "#e8f0fe"
def region(x, y, wd, h, title):
    rect(x, y, wd, h, "#f8f9fa", "#dadce0", rx=10, sw=1.5)
    w(f"<polygon points='{x+14},{y+14} {x+30},{y+6} {x+46},{y+14} {x+46},{y+30} {x+30},{y+38} {x+14},{y+30}' fill='none' stroke='{GCP_BLUE}' stroke-width='2'/>")
    text(x + 56, y + 22, title, size=14, weight="700")
def vpc(x, y, wd, h, title):
    rect(x, y, wd, h, "#fffde7", "#f9e79f", rx=8, sw=1.2)
    text(x + wd / 2, y + 16, title, size=12, weight="700", anchor="middle", fill="#5f6368")
def node(x, y, wd, h, title, sub="", col=GCP_BLUE, fill="#ffffff", hexagon=False):
    if hexagon:
        cx, cy = x + wd / 2, y + 22
        w(f"<polygon points='{cx-16},{cy-9} {cx},{cy-18} {cx+16},{cy-9} {cx+16},{cy+9} {cx},{cy+18} {cx-16},{cy+9}' fill='{col}' opacity='0.9'/>")
        text(cx, y + 52, title, size=10.5, weight="700", anchor="middle")
        if sub: text(cx, y + 66, sub, size=9, anchor="middle", fill=MUTED)
    else:
        rect(x, y, wd, h, fill, col, rx=8, sw=1.8)
        text(x + wd / 2, y + 18, title, size=11, weight="700", anchor="middle", fill=col if col not in (INK, GCP_BLUE) else INK)
        if sub:
            for i, ln in enumerate(sub.split("|")):
                text(x + wd / 2, y + 34 + i * 12.5, ln, size=9, anchor="middle", fill=MUTED)
def person(x, y, label):
    w(f"<circle cx='{x}' cy='{y}' r='11' fill='#7fb3d5'/><path d='M{x-20},{y+34} a20,20 0 0 1 40,0 z' fill='#7fb3d5'/>")
    text(x, y + 48, label, size=10, anchor="middle", fill=MUTED)

text(24, 30, "AI API Testing Platform — GCP deployment (same format as the landing-zone diagram)", size=20, weight="700")
text(24, 52, "Primary us-east4 shown in full; the DR region is identical with minimal replicas. Items in RED are new compared with the landing-zone picture; items with a strike are not used by this product.", size=11, fill=MUTED)

# ---------------- left: people and machines
person(60, 120, "QE / QE lead"); person(60, 230, "Project managers")
node(120, 105, 90, 44, "UI App", "browser", col=INK)
arrow([(82, 130), (118, 130)]); arrow([(82, 240), (118, 240)])
node(120, 218, 90, 44, "UI App", "browser", col=INK)
text(238, 118, "HTTPS/443", size=9, anchor="middle", fill=MUTED)
node(250, 105, 70, 44, "F5", "load balancer", col="#c0392b")
arrow([(210, 127), (248, 127)]); arrow([(210, 240), (230, 240), (230, 127)])
text(360, 118, "HTTPS/443", size=9, anchor="middle", fill=MUTED)
node(380, 105, 80, 44, "Equinix", "interconnect", col="#c0392b")
arrow([(320, 127), (378, 127)])
arrow([(460, 127), (500, 127), (500, 300), (560, 300)], width=2)
text(505, 290, "Active", size=9.5, fill=MUTED)
arrow([(500, 300), (500, 840), (560, 840)], dashed=True)
text(505, 830, "Passive", size=9.5, fill=MUTED)

# machine callers (NEW)
node(120, 330, 120, 50, "CI pipeline", "POST /triggers/deploy|API key, no login", col=RED, fill=RED_BG)
node(120, 400, 120, 50, "Jira Cloud", "webhook: issue → 'ready|for QA'  (R3, signed)", col=RED, fill=RED_BG)
node(120, 470, 120, 50, "Company IdP", "OIDC for the UI|(users, groups → roles)", col=RED, fill=RED_BG)
arrow([(240, 355), (300, 355), (300, 425), (240, 425)], color=RED, width=1.2, dashed=True)
node(250, 330, 120, 50, "Internal LB", "IP allowlist|/webhooks · /triggers", col=RED, fill=RED_BG)
arrow([(240, 355), (248, 355)], color=RED); arrow([(370, 355), (500, 355)], color=RED)
arrow([(240, 495), (300, 495), (300, 560), (560, 560)], color=RED, dashed=True)
text(330, 550, "token validation only", size=9, fill=RED_INK)

# sticky note
rect(60, 600, 420, 190, "#fff59d", "#f1c40f", rx=4, sw=1)
sticky = [
    "Active / Passive, manual failover — unchanged.",
    "",
    "What actually needs replicating for THIS product:",
    "• Cloud SQL: cross-region read replica → promote on failover",
    "• Cloud Storage: dual-region buckets (inputs, evidence, reports)",
    "• Pub/Sub, Secret Manager, Artifact Registry: GLOBAL — nothing to do",
    "• runner Jobs: ephemeral — in-flight runs are lost, rerun from the",
    "  run record (that is why every run pins commit + data version)",
    "• Git (test-assets), Jira, Zephyr: external — unaffected",
    "DR cluster keeps: web 1, platform-api 1, worker 1, ai-worker 0.",
    "Firewall rules to the QA/staging APIs must exist in BOTH regions.",
]
for i, ln in enumerate(sticky):
    text(72, 618 + i * 15.5, ln, size=9.6, weight="700" if i == 0 else "normal", fill="#5d4037")

# ---------------- primary region
RX, RY, RW, RH = 560, 80, 1320, 640
region(RX, RY, RW, RH, "Primary Region: US-EAST4")
vpc(RX + 20, RY + 50, 1000, 570, "Secure Hub VPC")
# firewall + ingress
node(RX + 40, RY + 270, 70, 60, "Firewall", "allow 443", col=GCP_BLUE, hexagon=True)
node(RX + 130, RY + 270, 70, 60, "Ingress", "GKE", col=GCP_BLUE, hexagon=True)
arrow([(RX + 110, RY + 300), (RX + 128, RY + 300)]); arrow([(RX + 200, RY + 300), (RX + 230, RY + 300)])

# cluster
CX, CY, CW, CH = RX + 232, RY + 70, 620, 520
rect(CX, CY, CW, CH, "#e8f5e9", "#81c784", rx=8, sw=1.5, dash="6 3")
text(CX + 12, CY + 16, "Cluster: apitest-prod-gke  ·  zones us-east4-a, b, c  ·  Workload Identity on", size=11, weight="700")
text(CX + 12, CY + 32, "the landing-zone picture shows ONE pod block here; this product needs three namespaces on two node pools", size=9.5, fill=RED_INK)
# namespace app
rect(CX + 12, CY + 44, 300, 300, "#ffffff", INK, rx=8, sw=1.5, dash="5 3")
text(CX + 24, CY + 58, "namespace app  ·  node pool default", size=10, weight="700", font=MONO)
node(CX + 24, CY + 70, 130, 60, "web", "Angular · nginx|2 pods", col=INK)
node(CX + 166, CY + 70, 134, 60, "platform-api", "FastAPI · 2–20 pods|HPA on HTTP load", col=INK)
node(CX + 24, CY + 140, 276, 60, "platform-worker", "same image, entrypoint 'worker' · 1–N pods · KEDA on queue depth|smoke, Discover, rule engine, build, pre-flight, ingest, report", col=INK)
node(CX + 24, CY + 210, 276, 54, "outbox relay (leader-elected) · SSE · audit", "part of platform-api; the only pods that write status columns", col=INK, fill=GRAY_BG)
text(CX + 24, CY + 285, "egress: Cloud SQL, GCS, Pub/Sub, Secret Manager, Git host,", size=9, fill=MUTED)
text(CX + 24, CY + 298, "Jira/Zephyr, IdP.  No Vertex AI. No route to the APIs under test", size=9, fill=MUTED)
text(CX + 24, CY + 311, "except ONE read-only smoke call during onboarding.", size=9, fill=MUTED)
# namespace ai
rect(CX + 324, CY + 44, 284, 150, BLUE_BG, BLUE, rx=8, sw=1.5, dash="5 3")
text(CX + 336, CY + 58, "namespace ai  ·  node pool default  (R2)", size=10, weight="700", font=MONO, fill=BLUE)
node(CX + 336, CY + 70, 260, 60, "ai-worker", "same image, entrypoint 'worker --ai' · 0–N pods|KEDA on ai-jobs · the ONLY caller of Vertex AI", col=BLUE)
text(CX + 336, CY + 145, "egress: Cloud SQL, Pub/Sub, Secret Manager, Vertex AI.", size=9, fill="#1e40af")
text(CX + 336, CY + 158, "Nothing else — no Git, no Jira, no APIs under test.", size=9, fill="#1e40af")
# namespace runners
rect(CX + 324, CY + 206, 284, 138, RED_BG, RED, rx=8, sw=1.5, dash="5 3")
text(CX + 336, CY + 220, "namespace runners  ·  node pool runners (spot ok)", size=10, weight="700", font=MONO, fill=RED)
node(CX + 336, CY + 232, 260, 56, "runner  (Kubernetes Job per run)", "different image: Java 21 + Karate · N pods = N shards|secrets via Secret Manager CSI · never the DB", col=RED)
text(CX + 336, CY + 300, "egress: the APIs under test (per environment), GCS, Pub/Sub, Git.", size=9, fill=RED_INK)
text(CX + 336, CY + 313, "Never production CIDRs. Never Cloud SQL. Never Vertex AI.", size=9, fill=RED_INK)
text(CX + 12, CY + 365, "Cloud Logging · Monitoring · Trace  (one trace id from browser → Pub/Sub → runner pod)", size=9.5, fill=MUTED)
text(CX + 12, CY + 380, "Artifact Registry: all images pinned by digest, scanned, SBOM published — NEW", size=9.5, fill=RED_INK)
# arrows from ingress to web/api
# managed services column inside VPC
SX = RX + 880
node(SX, RY + 60, 128, 54, "Cloud SQL", "PostgreSQL 16 · HA|RLS on every table", col=GCP_BLUE)
node(SX, RY + 124, 128, 54, "Pub/Sub", "platform-jobs · run-events|ai-jobs · ai-results · jira", col=RED, fill=RED_BG)
node(SX, RY + 188, 128, 54, "Cloud Storage", "inputs · evidence · reports|dual-region", col=RED, fill=RED_BG)
node(SX, RY + 252, 128, 54, "Secret Manager", "+ CSI driver|the only place a secret lives", col=RED, fill=RED_BG)
node(SX, RY + 316, 128, 54, "Vertex AI", "Gemini · fast + strong|reached from ns ai only", col=GCP_BLUE)
node(SX, RY + 380, 128, 54, "Sensitive Data", "Protection (DLP)|scans uploads", col=RED, fill=RED_BG)
node(SX, RY + 444, 128, 54, "Redis", "NOT used by this|product — remove or ADR", col=MUTED, fill=GRAY_BG)
w(f"<line x1='{SX+8}' y1='{RY+462}' x2='{SX+120}' y2='{RY+462}' stroke='{MUTED}' stroke-width='2'/>")
node(SX, RY + 508, 128, 54, "MongoDB Atlas", "NOT used by this|product (other teams)", col=MUTED, fill=GRAY_BG)
w(f"<line x1='{SX+8}' y1='{RY+526}' x2='{SX+120}' y2='{RY+526}' stroke='{MUTED}' stroke-width='2'/>")
# arrows cluster → services: one bus line on the right of the cluster, taps into each service
BUSX = CX + CW + 10
w(f"<line x1='{BUSX}' y1='{CY+60}' x2='{BUSX}' y2='{RY+420}' stroke='{LINE}' stroke-width='3'/>")
for yy, col in [(CY + 100, INK), (CY + 170, INK), (CY + 250, RED), (CY + 100 + 0, BLUE)]:
    pass
arrow([(CX + 312, CY + 110), (BUSX, CY + 110)], width=1.6)           # app ns
text(CX + 318, CY + 100, "app", size=8, fill=MUTED)
arrow([(CX + 608, CY + 120), (BUSX, CY + 120)], width=1.6, color=BLUE) # ai ns
arrow([(CX + 608, CY + 280), (BUSX, CY + 280)], width=1.6, color=RED)  # runners ns
for yy in [RY + 87, RY + 151, RY + 215, RY + 279, RY + 343, RY + 407]:
    arrow([(BUSX, yy), (SX - 4, yy)], width=1.4)

# outside the VPC, right column: external
EX = RX + 1040
rect(EX, RY + 50, 262, 548, "#f3e5f5", "#ce93d8", rx=8, sw=1.2)
text(EX + 130, RY + 66, "Outside GCP (egress)", size=12, weight="700", anchor="middle", fill="#6a1b9a")
node(EX + 16, RY + 84, 228, 70, "APIs under test", "dev · qa · staging — the customer's systems|reached ONLY from namespace runners|(+ one smoke call from the worker) · never prod", col=RED, fill=RED_BG)
node(EX + 16, RY + 170, 228, 54, "Git host  (test-assets repo)", "generated Karate projects|service account, branch protection", col=RED, fill=RED_BG)
node(EX + 16, RY + 240, 228, 54, "Jira Cloud · Zephyr", "stories (R2), defects + webhook (R3)|Zephyr cases + cycles (R2)", col=RED, fill=RED_BG)
node(EX + 16, RY + 310, 228, 54, "Teams / email", "one message per event|(run done, env not ready, review)", col=RED, fill=RED_BG)
node(EX + 16, RY + 380, 228, 54, "Company IdP", "OIDC · groups → team_member.role", col=RED, fill=RED_BG)
arrow([(CX + 608, CY + 330), (BUSX + 30, CY + 330), (BUSX + 30, RY + 606), (EX + 276, RY + 606), (EX + 276, RY + 119), (EX + 246, RY + 119)], color=RED, width=2.2)
text(EX + 100, RY + 618, "runners → APIs under test: the arrow the landing-zone diagram is missing", size=9, anchor="middle", fill=RED_INK, weight="700")
arrow([(BUSX, RY + 420), (BUSX, RY + 580), (EX - 10, RY + 580), (EX - 10, RY + 197), (EX + 12, RY + 197)], width=1.2)
arrow([(EX - 10, RY + 267), (EX + 12, RY + 267)], width=1.2)
arrow([(EX - 10, RY + 337), (EX + 12, RY + 337)], width=1.2)
arrow([(EX - 10, RY + 407), (EX + 12, RY + 407)], width=1.2)


# ---------------- DR region (compact)
DX, DY_, DW, DH_ = 560, 740, 1310, 300
region(DX, DY_, DW, DH_, "Secondary (DR) Region: US-WEST2  —  same shape, minimal replicas, manual failover")
vpc(DX + 20, DY_ + 50, 990, 230, "Secure Hub VPC")
node(DX + 40, DY_ + 130, 70, 60, "Firewall", "", col=GCP_BLUE, hexagon=True)
node(DX + 130, DY_ + 130, 70, 60, "Ingress", "", col=GCP_BLUE, hexagon=True)
rect(DX + 232, DY_ + 70, 620, 190, "#e8f5e9", "#81c784", rx=8, sw=1.5, dash="6 3")
text(DX + 244, DY_ + 86, "Cluster: apitest-dr-gke  ·  us-west2-a, b, c", size=11, weight="700")
node(DX + 244, DY_ + 100, 190, 50, "namespace app", "web 1 · platform-api 1 · worker 1|scale up on failover", col=INK)
node(DX + 446, DY_ + 100, 190, 50, "namespace ai", "ai-worker 0 (scales from 0)", col=BLUE)
node(DX + 648, DY_ + 100, 190, 50, "namespace runners", "node pool exists, no Jobs|until a run is requested", col=RED)
text(DX + 244, DY_ + 175, "Same Helm chart, same image digests, values: replicas minimal.  Firewall rules to QA/staging APIs must be pre-provisioned here too.", size=9.5, fill=MUTED)
text(DX + 244, DY_ + 190, "Failover runbook: promote Cloud SQL replica → repoint DNS at F5 → scale app to 2 → re-run any run that was in flight (from its run record).", size=9.5, fill=MUTED)
node(DX + 870, DY_ + 60, 128, 54, "Cloud SQL replica", "cross-region read replica|promote on failover", col=GCP_BLUE)
node(DX + 870, DY_ + 124, 128, 54, "Cloud Storage", "dual-region: already|here, nothing to copy", col=RED, fill=RED_BG)
node(DX + 870, DY_ + 188, 128, 54, "Pub/Sub · Secrets", "global services —|same endpoints", col=RED, fill=RED_BG)
arrow([(RX + 934, RY + 114), (RX + 934, RY + 130), (RX + 1010, RY + 130), (RX + 1010, DY_ + 87), (DX + 998, DY_ + 87)], width=1.2, dashed=True)
text(RX + 1030, DY_ + 40, "replication", size=9, fill=MUTED)

# legend
text(24, H - 16, "Legend:  blue = already on the landing-zone diagram · RED = add for this product · grey with strike = on the diagram but not used by this product · dashed boxes = namespaces · dashed red arrow = secrets read · purple dashed = DLP scan", size=10, fill=MUTED)
w("</svg>")
open("out/gcp-deployment-architecture.svg", "w").write("\n".join(out))
print("ok")
