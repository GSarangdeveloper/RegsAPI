#!/usr/bin/env python3
"""Regenerate every SVG, render PNGs (2x) and build the single PDF pack.
Usage:  python render.py            (needs: playwright + chromium, pypdf, Pillow)
        pip install playwright pypdf pillow && playwright install chromium
"""
import glob, os, re, subprocess, sys
from playwright.sync_api import sync_playwright
from pypdf import PdfWriter

os.makedirs("out", exist_ok=True)
scripts = sorted(glob.glob("[0-9][0-9]_*.py"))
for s in scripts:
    subprocess.run([sys.executable, s], check=True)
    print("generated", s)

order = ["architecture-00-read-this-first", "architecture-0-overview", "process-flow-v4",
         "architecture-1-onboard", "architecture-2-understand", "architecture-3-design",
         "architecture-4-build", "architecture-4a-case-to-feature", "architecture-5-run",
         "architecture-6-close-the-loop",
         "knowledge-A-karate-on-gke", "knowledge-B-ai-test-cases", "knowledge-C-test-data",
         "gcp-deployment-architecture", "snippet-1-inside-the-cluster", "snippet-2-managed-services", "snippet-3-in-and-out", "snippet-4-dr-note"]
def size(svg):
    m = re.search(r"viewBox='0 0 (\d+) (\d+)'", open(svg).read())
    return int(m.group(1)), int(m.group(2))

pdfs = []
with sync_playwright() as p:
    b = p.chromium.launch()
    for name in order:
        svg = f"out/{name}.svg"
        w, h = size(svg)
        pg = b.new_page(viewport={"width": w, "height": h}, device_scale_factor=2)
        pg.goto("file://" + os.path.abspath(svg))
        pg.screenshot(path=f"out/{name}.png")
        pg.pdf(path=f"out/{name}.pdf", width=f"{w}px", height=f"{h}px", print_background=True)
        pdfs.append(f"out/{name}.pdf"); pg.close()
        print("rendered", name)
    b.close()
wr = PdfWriter()
for f in pdfs: wr.append(f)
wr.write("out/AI-API-Testing-Platform-Architecture-Pack.pdf")
print("pack written")
