import os
os.makedirs('out', exist_ok=True)
#!/usr/bin/env python3
"""Phase 4 Build — whiteboard-style, one example flowing through."""
FONT = "Inter, 'Segoe UI', Helvetica, Arial, sans-serif"
MONO = "'JetBrains Mono', SFMono-Regular, Consolas, 'Liberation Mono', monospace"
INK, MUTED, LINE = "#1f2937", "#6b7280", "#9ca3af"
BLUE, BLUE_BG = "#2563eb", "#eff6ff"
GREEN, GREEN_BG, GREEN_INK = "#059669", "#ecfdf5", "#065f46"
AMBER, AMBER_BG, AMBER_INK = "#d97706", "#fffbeb", "#92400e"
RED, RED_BG, RED_INK = "#dc2626", "#fef2f2", "#991b1b"
GRAY_BG = "#f3f4f6"
W, H = 1700, 1010
out = []
def w(s): out.append(s)
def esc(s): return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
def text(x, y, s, size=12, anchor="start", weight="normal", fill=INK, style="", font=FONT):
    st = f" font-style='{style}'" if style else ""
    lead = len(s) - len(s.lstrip(' '))
    s = '\u00a0' * lead + s.lstrip(' ')
    w(f"<text x='{x}' y='{y}' font-size='{size}' text-anchor='{anchor}' font-weight='{weight}' fill='{fill}'{st} dominant-baseline='middle' font-family=\"{font}\">{esc(s)}</text>")
def rect(x, y, wd, h, fill, stroke, rx=14, sw=2, dash=""):
    d = f" stroke-dasharray='{dash}'" if dash else ""
    w(f"<rect x='{x}' y='{y}' width='{wd}' height='{h}' rx='{rx}' fill='{fill}' stroke='{stroke}' stroke-width='{sw}'{d}/>")
def arrow(pts, color=INK, width=2.4, dashed=False):
    p = " ".join(f"{x},{y}" for x, y in pts)
    m = {INK: "a", BLUE: "aB", AMBER: "aA", RED: "aR", GREEN: "aG"}[color]
    d = " stroke-dasharray='7 5'" if dashed else ""
    w(f"<polyline points='{p}' fill='none' stroke='{color}' stroke-width='{width}'{d} stroke-linejoin='round' marker-end='url(#{m})'/>")
def badge(x, y, n, color=INK, r=15):
    w(f"<circle cx='{x}' cy='{y}' r='{r}' fill='{color}'/>")
    text(x, y, str(n), size=15, anchor="middle", weight="700", fill="#ffffff")
def doc(x, y, wd, h, title, lines, stroke=INK, fill="#ffffff", size=10.5, lh=15):
    # a "document" shape with a folded corner
    f = 14
    w(f"<path d='M{x},{y+8} q0,-8 8,-8 h{wd-8-f} l{f},{f} v{h-f-8} q0,8 -8,8 h{-(wd-16)} q-8,0 -8,-8 z' fill='{fill}' stroke='{stroke}' stroke-width='2'/>")
    w(f"<path d='M{x+wd-f},{y} v{f} h{f}' fill='none' stroke='{stroke}' stroke-width='2'/>")
    text(x + 12, y + 20, title, size=11, weight="700", fill=stroke if stroke != INK else MUTED, font=MONO)
    for i, ln in enumerate(lines):
        text(x + 12, y + 42 + i * lh, ln, size=size, fill=INK, font=MONO)
def bubble(x, y, wd, h, title, lines, stroke, fill, ink, tail=None):
    rect(x, y, wd, h, fill, stroke, rx=16)
    if tail:  # small triangle pointing up to (tx, y)
        tx = tail
        w(f"<path d='M{tx-10},{y+1} L{tx},{y-14} L{tx+10},{y+1} z' fill='{fill}' stroke='{stroke}' stroke-width='2'/>")
        w(f"<line x1='{tx-9}' y1='{y+1}' x2='{tx+9}' y2='{y+1}' stroke='{fill}' stroke-width='3'/>")
    text(x + 16, y + 24, title, size=14, weight="700", fill=ink)
    for i, ln in enumerate(lines):
        text(x + 16, y + 48 + i * 18, ln, size=11.5, fill=ink)

w(f"<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 {W} {H}' role='img' aria-labelledby='t'>")
w("<title id='t'>Phase 6 Close the loop — the whiteboard version</title>")
w("<defs>")
for mid, col in [("a", INK), ("aB", BLUE), ("aA", AMBER), ("aR", RED), ("aG", GREEN), ("aP", "#7c3aed")]:
    w(f"<marker id='{mid}' viewBox='0 0 10 10' refX='9' refY='5' markerWidth='6' markerHeight='6' orient='auto-start-reverse'><path d='M0,0 L10,5 L0,10 z' fill='{col}'/></marker>")
w("</defs>")
rect(0, 0, W, H, "#ffffff", "none", rx=0, sw=0)



PURPLE, PURPLE_BG, PURPLE_INK = "#7c3aed", "#f5f3ff", "#5b21b6"
def arrow(pts, color=INK, width=2.4, dashed=False):
    p = " ".join(f"{x},{y}" for x, y in pts)
    m = {INK: "a", BLUE: "aB", AMBER: "aA", RED: "aR", GREEN: "aG", PURPLE: "aP"}[color]
    d = " stroke-dasharray='7 5'" if dashed else ""
    w(f"<polyline points='{p}' fill='none' stroke='{color}' stroke-width='{width}'{d} stroke-linejoin='round' marker-end='url(#{m})'/>")
def steps_row(Y, cols, BH_=118):
    for x, wd, t, lines, col, fill, n in cols:
        rect(x, Y, wd, BH_, fill, col, rx=16, sw=2.5)
        tx = x + 18
        if n:
            badge(x + 26, Y + 26, n, col); tx = x + 50
        text(tx, Y + 26, t, size=16, weight="700", fill=col if col != INK else INK)
        for i, ln in enumerate(lines):
            text(x + 18, Y + 54 + i * 17, ln, size=12.5, fill=MUTED)
    for i in range(len(cols) - 1):
        x1 = cols[i][0] + cols[i][1]; x2 = cols[i + 1][0]
        arrow([(x1 + 4, Y + BH_ / 2), (x2 - 4, Y + BH_ / 2)], width=3)
def bracket(x1, x2, y, label, col=MUTED):
    w(f"<path d='M{x1},{y} v8 h{x2-x1} v-8' fill='none' stroke='{col}' stroke-width='1.5'/>")
    text((x1 + x2) / 2, y + 20, label, size=11, anchor="middle", fill=col, style="italic")
def table(x, y, wd, h, title, rows, kx=270, size=11.5):
    rect(x, y, wd, h, "#ffffff", LINE, rx=14, sw=1.5)
    text(x + 16, y + 24, title, size=13, weight="700")
    for i, (a, b) in enumerate(rows):
        text(x + 16, y + 50 + i * 24, a, size=size, weight="700", font=MONO)
        text(x + kx, y + 50 + i * 24, b, size=size, fill=MUTED)
def footer(done, remember):
    text(40, H - 42, "Done when:", size=12.5, weight="700", fill=GREEN_INK)
    text(130, H - 42, done, size=11.5, fill=GREEN_INK)
    text(40, H - 18, remember, size=12, fill=MUTED, style="italic")

text(40, 44, "Phase 6 · Close the loop", size=30, weight="700")
text(40, 78, "Turn a failed test into a fixed defect: report it, sort it, let a person decide, file it in Jira once, and re-run the right tests when the fix arrives.", size=15, fill=MUTED)
text(W - 40, 44, "release 1 = the report only · release 3 = everything after it", size=13, anchor="end", fill=LINE)
text(W - 40, 64, "who: a worker pod does 1, 2, 4, 5 · an ai-worker pod helps in 2 · a QE decides at 3 · Jira is the other end of 4 and 5", size=13, anchor="end", fill=LINE)

Y = 120
steps_row(Y, [
    (40,   190, "Run completed", ["results + evidence", "from Phase 5", "(some failures)"], GREEN, GREEN_BG, None),
    (300,  250, "Report", ["every number computed in SQL:", "counts, matrix, failures grouped", "by fingerprint, change vs last run"], INK, "#ffffff", 1),
    (610,  250, "Triage", ["cheap rules first (env? data?", "flaky? drift?), AI only for the", "rest → category + draft defect"], PURPLE, PURPLE_BG, 2),
    (920,  250, "QE decides", ["confirm · change category ·", "edit the draft · dismiss", "nothing reaches Jira before this"], GREEN, GREEN_BG, 3),
    (1230, 250, "Jira defect", ["search by fingerprint first:", "found → comment; closed → new,", "linked 'regression of'; else new"], PURPLE, PURPLE_BG, 4),
    (1540, 120, "Rerun", ["Jira says 'ready", "for QA' → a run,", "result back"], PURPLE, PURPLE_BG, 5),
])
bracket(300, 550, Y + 118 + 10, "release 1 stops here")
bracket(610, 1660, Y + 118 + 10, "release 3 — worker pod + ai-worker + Jira; the QE gate in the middle", PURPLE)

SY = 292
text(40, SY, "The same failure, followed through every step — run #482, case TC-CLM-0032 (update of an adjudicated claim was accepted)", size=14, weight="700", fill=MUTED)
DY = SY + 20; DH = 160
doc(40, DY, 230, DH, "result row", [
    'TC-CLM-0032  failed',
    'PUT /claims/{id}',
    'expected 409',
    'actual   200',
    'fingerprint 7f3a…',
    'evidence:',
    ' calls/TC-CLM-0032/'], stroke=GREEN, size=10.2, lh=14)
doc(300, DY, 250, DH, "report, failures group", [
    '7f3a…  PUT /claims/{id}',
    '  expected 409, got 200',
    '  1 case · NEW since #470',
    '  rule R-12 (adjudicated',
    '  claims are locked)',
    '',
    'notify: run completed'], size=10.2, lh=14)
doc(610, DY, 250, DH, "triage item", [
    'signals: env ✗ data ✗',
    '         flaky ✗ drift ✗',
    'AI: product_bug  0.86',
    ' "update accepted on an',
    '  adjudicated claim"',
    'draft: title, steps,',
    '  expected, actual'], stroke=PURPLE, size=10.2, lh=14)
doc(920, DY, 250, DH, "QE decision", [
    'category: product_bug ✓',
    'draft: edited title',
    'decision: confirm',
    '',
    'stored as feedback',
    '→ create defect'], stroke=GREEN, size=10.2, lh=14)
doc(1230, DY, 250, DH, "Jira CLM-1187", [
    'search fp 7f3a… → none',
    'create Bug',
    ' component: claims-api',
    ' priority: Highest',
    ' apitest_fingerprint 7f3a…',
    ' apitest_case_ids [0032]',
    ' links: run #482, story'], stroke=PURPLE, size=10.2, lh=14)
doc(1540, DY, 120, DH, "webhook", [
    'CLM-1187 →',
    'ready for QA',
    '',
    'run #501',
    'scope:',
    'defect:',
    'CLM-1187',
    '→ passed ✓'], stroke=PURPLE, size=10.2, lh=14)
for x1, x2 in [(270, 300), (550, 610), (860, 920), (1170, 1230), (1480, 1540)]:
    arrow([(x1 + 4, DY + DH / 2), (x2 - 4, DY + DH / 2)], color=INK, width=1.6)

CY = 522
bubble(40, CY, 500, 186, "Cheap rules before AI", [
    "Four signals settle most failures with no model call:",
    "  every case on that host failed → environment issue",
    "  the case was blocked / its record stale → data issue",
    "  passed on the retry → flaky",
    "  response shape changed vs the spec → contract drift",
    "Only what is left goes to the AI, with the masked",
    "request/response, the rule and the case's history.",
], INK, "#ffffff", INK)
bubble(580, CY, 520, 186, "The platform never files a defect on its own", [
    "The AI writes a DRAFT; a QE confirms, corrects or dismisses;",
    "the worker files it. Every decision is stored — reclassified",
    "items become the examples that tune triage later.",
    "One bug = one issue: the fingerprint lives in a Jira custom",
    "field, so a repeat is a comment, not a duplicate. Our comments",
    "carry a hidden marker so the same event is never posted twice.",
], GREEN, GREEN_BG, GREEN_INK)
bubble(1140, CY, 520, 186, "Rerun on fix — how the webhook works", [
    "Jira calls POST /webhooks/jira when an issue changes status.",
    "The call is verified with a shared secret; the handler reads",
    "ONLY the issue key and the new status, nothing else in the body.",
    "Key → our defect row → a Phase 5 run scoped to: the linked",
    "cases + every case on that endpoint + its dependency chain.",
    "Passed → comment and close. Failed → comment, stays open.",
], PURPLE, PURPLE_BG, PURPLE_INK)

TY = 738
table(40, TY, 800, 196, "Triage categories — what each one means and who it goes to", [
    ("product_bug", "the API did the wrong thing → Jira defect (after the QE confirms)"),
    ("contract_drift", "the API changed and the spec did not → tell the API owner, update the spec"),
    ("test_issue", "our case or script is wrong → back to Phase 3 / 4, no Jira"),
    ("data_issue", "the record we used was missing or stale → fix data, rerun"),
    ("environment_issue", "host down, auth broken → environment owner, rerun"),
    ("flaky", "passed on retry → watch it; three in a row → test_issue"),
])
table(870, TY, 790, 196, "What the Jira issue carries, so it can be found and traced later", [
    ("issue type · component", "Bug · the API (workflow) it belongs to"),
    ("priority", "from a severity matrix: P1 product bug → Highest"),
    ("labels", "apitest · {workflow_slug}"),
    ("apitest_fingerprint", "custom field — the dedup key; searched before every create"),
    ("apitest_case_ids", "custom field — the TC- ids, so the rerun knows what to run"),
    ("links", "relates to the story · remote links to the run report and the evidence"),
], kx=250)
footer("a defect on the pilot API goes failed test → triage → confirmed → Jira → fix → 'ready for QA' → automatic rerun → passed, with no manual step except the QE's decision · the same failure in two runs makes ONE issue.",
       "Remember: numbers are computed, never written by AI; AI drafts, a person decides, the worker files. If triage is wrong more than 15 % of the time on the labelled set, it does not ship.")
w("</svg>")
open("out/architecture-6-close-the-loop.svg", "w").write("\n".join(out))
print("ok")
