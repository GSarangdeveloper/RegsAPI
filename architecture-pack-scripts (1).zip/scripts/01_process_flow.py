import os
os.makedirs('out', exist_ok=True)
#!/usr/bin/env python3
"""Generate process-flow-v4.svg on a strict grid: 6 lanes x 5 rows + state strip."""

FONT = "Inter, 'Segoe UI', Helvetica, Arial, sans-serif"
MONO = "'JetBrains Mono', SFMono-Regular, Consolas, 'Liberation Mono', monospace"

INK, MUTED, LINE = "#1f2937", "#6b7280", "#9ca3af"
BLUE, BLUE_BG = "#2563eb", "#eff6ff"
GREEN, GREEN_BG, GREEN_INK = "#059669", "#ecfdf5", "#065f46"
AMBER, AMBER_BG, AMBER_INK = "#d97706", "#fffbeb", "#92400e"
RED, RED_BG, RED_INK = "#dc2626", "#fef2f2", "#991b1b"
SYNC, SYNC_BG = "#6b7280", "#f3f4f6"
LANE_BG = "#f9fafb"

W, H = 2150, 900
LANE_X0, LANE_W, LANE_STRIDE = 100, 290, 330
HDR_Y, HDR_H = 142, 66
ROW_Y0, ROW_H, ROW_STRIDE = 236, 82, 98
STATE_Y, STATE_H = 734, 38
LOOP_Y = 802
LEGEND_Y = 852

out = []
def w(s): out.append(s)

def esc(s):
    return (s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))

def text(x, y, s, size=10, anchor="start", weight="normal", fill=INK, style="", font=FONT, ls=""):
    extra = f" font-style='{style}'" if style else ""
    extra += f" letter-spacing='{ls}'" if ls else ""
    w(f"<text x='{x}' y='{y}' font-size='{size}' text-anchor='{anchor}' font-weight='{weight}' fill='{fill}'{extra} dominant-baseline='middle' font-family=\"{font}\">{esc(s)}</text>")

def tw(s, size):  # rough text width
    return len(s) * size * 0.56

def pill(x_right, y, label, stroke, fill="#ffffff", ink=None, size=9.5):
    pw = tw(label, size) + 14
    w(f"<rect x='{x_right-pw:.1f}' y='{y-10}' width='{pw:.1f}' height='20' rx='10' fill='{fill}' stroke='{stroke}' stroke-width='1'/>")
    text(x_right - pw/2, y, label, size=size, anchor="middle", weight="600", fill=ink or stroke)
    return pw

def lane_x(i): return LANE_X0 + i * LANE_STRIDE
def row_y(r): return ROW_Y0 + r * ROW_STRIDE
def row_mid(r): return row_y(r) + ROW_H / 2

def arrow(points, color=INK, dashed=False, width=1.5):
    pts = " ".join(f"{x:.1f},{y:.1f}" for x, y in points)
    m = {INK: "arrow", AMBER: "arrowAmber", RED: "arrowRed", SYNC: "arrowGray"}[color]
    dash = " stroke-dasharray='5 4'" if dashed else ""
    w(f"<polyline points='{pts}' fill='none' stroke='{color}' stroke-width='{width}'{dash} marker-end='url(#{m})'/>")

def step(lane, row, num, title, actor, release, lines, kind="det", note=None):
    """kind: det | ai | gate | sync"""
    x, y = lane_x(lane), row_y(row)
    style = {
        "det":  dict(fill="#ffffff", stroke=INK,   badge=INK,   tink=INK,       actor_col=MUTED),
        "ai":   dict(fill=BLUE_BG,   stroke=BLUE,  badge=BLUE,  tink=INK,       actor_col=BLUE),
        "gate": dict(fill=GREEN_BG,  stroke=GREEN, badge=GREEN, tink=GREEN_INK, actor_col=GREEN_INK),
        "sync": dict(fill=SYNC_BG,   stroke=SYNC,  badge=SYNC,  tink=INK,       actor_col=SYNC),
    }[kind]
    dashed = " stroke-dasharray='5 3'" if kind == "sync" else ""
    w(f"<g id='step-{num}'>")
    w(f"<rect x='{x}' y='{y}' width='{LANE_W}' height='{ROW_H}' rx='8' fill='{style['fill']}' stroke='{style['stroke']}' stroke-width='1.6'{dashed}/>")
    cx, cy = x + 21, y + 22
    if kind == "gate":
        w(f"<polygon points='{cx},{cy-11} {cx+11},{cy} {cx},{cy+11} {cx-11},{cy}' fill='#ffffff' stroke='{GREEN}' stroke-width='1.6'/>")
        text(cx, cy, num, size=8 if len(num) > 1 else 9.5, anchor="middle", weight="700", fill=GREEN_INK)
    else:
        w(f"<circle cx='{cx}' cy='{cy}' r='11' fill='{style['badge']}'/>")
        text(cx, cy, num, size=9 if len(num) > 1 else 10.5, anchor="middle", weight="700", fill="#ffffff")
    text(x + 40, cy, title, size=12.5, weight="700", fill=style["tink"])
    pill(x + LANE_W - 10, cy, actor, style["actor_col"])
    for i, ln in enumerate(lines):
        text(x + 12, y + 44 + i * 13.5, ln, size=10, fill=MUTED)
    # release tag bottom-right
    rel_col = {"MVP": MUTED, "R2": BLUE, "R3": "#7c3aed"}
    tag_x = x + LANE_W - 10
    for tok in reversed(release.split(" · ")):
        base = tok.split()[0]
        col = rel_col.get(base, MUTED)
        pw = tw(tok, 8) + 10
        w(f"<rect x='{tag_x-pw:.1f}' y='{y+ROW_H-19}' width='{pw:.1f}' height='14' rx='4' fill='#ffffff' stroke='{col}' stroke-width='0.9'/>")
        text(tag_x - pw/2, y + ROW_H - 12, tok, size=8, anchor="middle", weight="700", fill=col, font=MONO)
        tag_x -= pw + 5
    if note:
        text(x + 12, y + ROW_H - 12, note, size=8.5, fill=MUTED, style="italic")
    w("</g>")

def vconn(lane, r_from, r_to, x_off=0, color=INK, dashed=False, label=None, label_side="right"):
    x = lane_x(lane) + LANE_W / 2 + x_off
    y1, y2 = row_y(r_from) + ROW_H, row_y(r_to)
    arrow([(x, y1), (x, y2)], color=color, dashed=dashed)
    if label:
        lx = x + 6 if label_side == "right" else x - 6
        text(lx, (y1 + y2) / 2, label, size=8.5, anchor="start" if label_side == "right" else "end", weight="600", fill=color)

def lane_conn(lane, r_from, r_to=0):
    """Right edge of (lane,r_from) → left edge of (lane+1,r_to) via the gutter."""
    x1 = lane_x(lane) + LANE_W
    gx = x1 + 16
    y1 = row_mid(r_from)
    y2 = row_y(r_to) + 26
    arrow([(x1, y1), (gx, y1), (gx, y2), (lane_x(lane + 1), y2)])

def header(lane, num, name, inp):
    x = lane_x(lane)
    w(f"<rect x='{x}' y='{HDR_Y}' width='{LANE_W}' height='{HDR_H}' rx='8' fill='#e5e7eb'/>")
    text(x + 12, HDR_Y + 20, f"{num}  {name}", size=14, weight="700")
    for i, ln in enumerate(inp):
        text(x + 12, HDR_Y + 40 + i * 12.5, ln, size=9.5, fill=MUTED)

def state_strip(lane, state, artifact):
    x = lane_x(lane)
    w(f"<rect x='{x}' y='{STATE_Y}' width='{LANE_W}' height='{STATE_H}' rx='8' fill='#ffffff' stroke='{LINE}' stroke-dasharray='4 3'/>")
    text(x + 12, STATE_Y + 13, "exit state", size=8, fill=LINE, weight="600", ls="0.08em")
    text(x + 70, STATE_Y + 13, state, size=9.5, weight="700", fill=INK, font=MONO)
    text(x + 12, STATE_Y + 28, artifact, size=9.5, fill=MUTED, style="italic")

def amber_pill(x, y, wdt, hgt, lines, stroke=AMBER, fill=AMBER_BG, ink=AMBER_INK, dashed=False):
    dash = " stroke-dasharray='5 3'" if dashed else ""
    w(f"<rect x='{x}' y='{y}' width='{wdt}' height='{hgt}' rx='{min(16, hgt/2)}' fill='{fill}' stroke='{stroke}' stroke-width='1.5'{dash}/>")
    n = len(lines)
    for i, ln in enumerate(lines):
        text(x + wdt / 2, y + hgt / 2 + (i - (n - 1) / 2) * 13, ln, size=9, anchor="middle", weight="600" if i == 0 else "normal", fill=ink)

# ------------------------------------------------------------------ canvas
w(f"<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 {W} {H}' role='img' aria-labelledby='t d'>")
w("<title id='t'>AI API Testing Platform — end-to-end process flow (v4)</title>")
w("<desc id='d'>Six phase lanes read left to right: Onboard, Understand, Design, Build, Run, Close the loop. 24 steps, 5 human gates, 5 loops, 1 stop. Each step names its actor and the release it ships in (MVP, R2, R3). Each lane ends in the workflow state that lets the next lane start.</desc>")
w("<defs>")
for mid, col in [("arrow", INK), ("arrowAmber", AMBER), ("arrowRed", RED), ("arrowGray", SYNC)]:
    w(f"<marker id='{mid}' viewBox='0 0 10 10' refX='9' refY='5' markerWidth='8' markerHeight='8' orient='auto-start-reverse'><path d='M0,0 L10,5 L0,10 z' fill='{col}'/></marker>")
w("</defs>")
w(f"<rect width='{W}' height='{H}' fill='#ffffff'/>")

# title block
text(24, 34, "AI API Testing Platform — End-to-end process flow", size=22, weight="700")
text(24, 58, "Six phases · 24 steps · 5 human gates · 5 loops · 1 stop.  Read left to right; each lane ends in the workflow state that lets the next lane start.  AI proposes (blue), the QE decides (green), execution is deterministic.", size=12, fill=MUTED)
text(W - 24, 34, "v4 · aligned to Technical Specification §3 and §8 (24 Sep 2026)", size=10.5, anchor="end", fill=LINE)
text(W - 24, 52, "release tags: MVP = no LLM on the critical path · R2 = AI graphs, Jira stories, Zephyr, CSV · R3 = triage, defects, rerun loop", size=10.5, anchor="end", fill=LINE)

# lane backgrounds
for i in range(6):
    w(f"<rect x='{lane_x(i)-10}' y='{HDR_Y-8}' width='{LANE_W+20}' height='{STATE_Y+STATE_H+10-(HDR_Y-8)}' rx='12' fill='{LANE_BG}'/>")

# ------------------------------------------------------------------ headers
header(0, 1, "Onboard",        ["in: OpenAPI 3 / Swagger 2, env config, credential profiles",
                                "optional: samples, Jira stories, CSV, existing suite, Kafka"])
header(1, 2, "Understand",     ["in: accepted spec version"])
header(2, 3, "Design",         ["in: confirmed API model"])
header(3, 4, "Build",          ["in: approved suite · CSV, samples, data catalog"])
header(4, 5, "Run",            ["in: Karate project @ pinned commit, environment, trigger"])
header(5, 6, "Close the loop", ["in: run results + failure fingerprints"])

# ------------------------------------------------------------------ lane 1  Onboard
step(0, 0, "1",  "Ingest",         "Platform", "MVP", ["credentials → own endpoint → Secret Manager, first;",
                                                       "normalize + lint spec; stable target key; DLP guard"])
step(0, 1, "2a", "Smoke check",    "Platform", "MVP", ["safe endpoints only: connectivity, auth per profile,",
                                                       "contract conformance; samples, CSV, Kafka checks"])
step(0, 2, "2b", "Readiness gate", "QE gate",  "MVP", ["red blocks until inputs are fixed · yellow passes",
                                                       "with an ack_reason · green auto-accepts"], kind="gate")
vconn(0, 0, 1); vconn(0, 1, 2)
lane_conn(0, 2)
# start node
sx = lane_x(0) - 38
w(f"<circle cx='{sx}' cy='{row_y(0)+26}' r='11' fill='{INK}'/>")
arrow([(sx + 11, row_y(0) + 26), (lane_x(0), row_y(0) + 26)])
text(sx - 2, row_y(0) - 14, "QE creates", size=9, anchor="middle", fill=MUTED)
text(sx - 2, row_y(0) - 3, "a workflow", size=9, anchor="middle", fill=MUTED)
# red loop 2b → 1
gx = lane_x(0) - 16
arrow([(lane_x(0), row_mid(2)), (gx, row_mid(2)), (gx, row_y(0) + 58), (lane_x(0), row_y(0) + 58)], color=AMBER)
for i, s in enumerate(["red:", "fix inputs,", "re-upload"]):
    text(gx - 6, row_mid(1) - 11 + i * 11, s, size=9, anchor="end", weight="600", fill=AMBER)

# ------------------------------------------------------------------ lane 2  Understand
step(1, 0, "3a", "Discover",      "Platform", "MVP", ["endpoint inventory, field catalog, dependency edges",
                                                      "(explicit + heuristic), auth model, coverage universe"])
step(1, 1, "3b", "Extract rules", "AI",       "R2",  ["business rules from Jira stories, each with its",
                                                      "source sentence + confidence; PHI guard on text"], kind="ai")
step(1, 2, "4",  "Rules review",  "QE gate",  "R2",  ["confirm / reject rules and low-confidence edges;",
                                                      "add unwritten rules; decisions → few-shot feedback"],
     kind="gate", note="skipped when no stories")
vconn(1, 0, 1); vconn(1, 1, 2)
lane_conn(1, 2)
# spec-change re-entry (above header)
px, pw_ = lane_x(1) - 10, LANE_W + 20
amber_pill(px, 82, pw_, 44, ["New spec version re-enters here · impacted targets only", "unchanged cases keep approval; locked cases flagged stale"])
arrow([(lane_x(1) + LANE_W / 2, 126), (lane_x(1) + LANE_W / 2, HDR_Y)], color=AMBER)

# ------------------------------------------------------------------ lane 3  Design
step(2, 0, "5a", "Test design",         "Platform", "MVP", ["rule engine: structural, status codes, schema,",
                                                            "boundary, dependency, security → assertion DSL"])
step(2, 1, "5b", "Cases for gaps",      "AI",       "R2",  ["business-rule and semantic cases aimed only at",
                                                            "the coverage gaps measured in 6"], kind="ai")
step(2, 2, "6",  "Coverage + contract", "Platform", "MVP", ["measure 7 dimensions; reject cases that break the",
                                                            "contract; dedup; priority; confidence score"])
step(2, 3, "7",  "QE approval",         "QE gate",  "MVP", ["all P1 decided; bulk-approve high confidence only;",
                                                            "low confidence one by one; QE lead accepts gaps"], kind="gate")
step(2, 4, "8",  "Publish to Zephyr",   "Zephyr",   "R2",  ["optional per team; async + batched; upsert by",
                                                            "case_id; approved P1 / P2 by default"], kind="sync")
vconn(2, 0, 1); vconn(2, 1, 2); vconn(2, 2, 3)
vconn(2, 3, 4, color=SYNC, dashed=True, label="optional")
lane_conn(2, 3)          # main path leaves from the gate, not from Zephyr
# coverage loop 6 → 5b
gx = lane_x(2) - 16
arrow([(lane_x(2), row_mid(2)), (gx, row_mid(2)), (gx, row_mid(1) + 14), (lane_x(2), row_mid(1) + 14)], color=AMBER)
text(lane_x(2) + 8, row_y(2) - 8, "gaps → next round (≤ 3)", size=8.5, weight="600", fill=AMBER)
text(lane_x(2) + 158, row_y(2) - 8, "then review regardless", size=8.5, weight="600", fill=AMBER)

# ------------------------------------------------------------------ lane 4  Build
step(3, 0, "9a", "Test data",   "Platform",      "MVP",          ["base payload per target; one mutation per case;",
                                                                   "catalog bindings; runtime placeholders"])
step(3, 1, "9b", "CSV mapping", "AI",            "R2",           ["column → field mapping; semantic values kept",
                                                                   "consistent across a scenario"], kind="ai")
step(3, 2, "10", "Data review", "QE gate",       "R2",           ["blocked bindings list exactly what QA must add;",
                                                                   "unmatched cases run as blocked"],
     kind="gate", note="only when a CSV was uploaded")
step(3, 3, "11", "Scripts",     "Platform + AI", "MVP · R2 AI",  ["templates first; AI only for business flows,",
                                                                   "state transitions, Kafka; auto-repair ≤ 2"], kind="ai")
step(3, 4, "12", "Dry run",     "Platform",      "MVP · R2 mock",["parse + static + contract checks; mock run",
                                                                   "against Prism; commit to Git; locks respected"])
vconn(3, 0, 1); vconn(3, 1, 2); vconn(3, 2, 3); vconn(3, 3, 4)
lane_conn(3, 4)
# needs_attention loop 12 → 11
gx = lane_x(3) - 16
arrow([(lane_x(3), row_mid(4)), (gx, row_mid(4)), (gx, row_mid(3) + 14), (lane_x(3), row_mid(3) + 14)], color=AMBER)
text(lane_x(3) + 8, row_y(4) - 8, "invalid → needs_attention", size=8.5, weight="600", fill=AMBER)
text(lane_x(3) + 158, row_y(4) - 8, "QE fixes or regenerates", size=8.5, weight="600", fill=AMBER)

# ------------------------------------------------------------------ lane 5  Run
step(4, 0, "13", "Pre-flight", "Platform", "MVP", ["freeze window + concurrency → queue with position;",
                                                   "tokens per profile; one safe call; allocate records"])
# fork row: green continues, red stops
lx = lane_x(4)
y_top, y_bot = row_y(0) + ROW_H, row_y(2)
arrow([(lx + 60, y_top), (lx + 60, y_bot)])
text(lx + 66, y_top + 12, "green", size=8.5, weight="600", fill=GREEN)
stop_x, stop_w, stop_h = lx + 104, LANE_W - 104, 50
stop_y = row_y(1) + (ROW_H - stop_h) / 2
w(f"<rect x='{stop_x}' y='{stop_y}' width='{stop_w}' height='{stop_h}' rx='10' fill='{RED_BG}' stroke='{RED}' stroke-width='1.5'/>")
text(stop_x + stop_w / 2, stop_y + 16, "Stop: run.env_not_ready", size=10.5, anchor="middle", weight="700", fill=RED_INK)
text(stop_x + stop_w / 2, stop_y + 33, "notify QE + env owner once, not per case", size=8.5, anchor="middle", fill=RED_INK)
arrow([(lx + 230, y_top), (lx + 230, stop_y)], color=RED, dashed=True)
text(lx + 236, y_top + 8, "any red", size=8.5, weight="600", fill=RED)
step(4, 2, "14", "Execute",      "Runner",   "MVP", ["Kubernetes Job at pinned commit; parallel shards;",
                                                     "rate-limited; retry network / 5xx once → flaky"])
step(4, 3, "15", "Results",      "Platform", "MVP", ["ingest summary; mask evidence in-pod; fingerprint",
                                                     "failures; clean up created resources (ledger + sweeper)"])
step(4, 4, "15b","Zephyr cycle", "Zephyr",   "R2",  ["test cycle + executions per run, linked to",
                                                     "evidence and the run report"], kind="sync")
vconn(4, 2, 3)
vconn(4, 3, 4, color=SYNC, dashed=True, label="optional")
lane_conn(4, 3)
# triggers (above header)
px, pw_ = lane_x(4) - 10, LANE_W + 20
w(f"<rect x='{px}' y='82' width='{pw_}' height='44' rx='12' fill='#ffffff' stroke='{INK}' stroke-width='1.3'/>")
text(px + pw_ / 2, 97, "Run triggers: manual · nightly · CI deploy · rerun · Jira webhook", size=9, anchor="middle", weight="600")
text(px + pw_ / 2, 111, "scope p1 · full · defect:{key} · duplicates within 60 s coalesced", size=8.5, anchor="middle", fill=MUTED)
arrow([(lane_x(4) + LANE_W / 2, 126), (lane_x(4) + LANE_W / 2, HDR_Y)])

# ------------------------------------------------------------------ lane 6  Close the loop
step(5, 0, "16", "Triage",        "Platform + AI", "R3",          ["signals first (env, data, drift, flaky); AI classifies",
                                                                    "the rest; cluster by root cause"], kind="ai")
step(5, 1, "17", "Defect review", "QE gate",       "R3",          ["confirm, reclassify or dismiss category + defect",
                                                                    "draft; every decision feeds triage back"], kind="gate")
step(5, 2, "18", "Jira defect",   "Jira",          "R3",          ["dedup by fingerprint: open → comment occurrence;",
                                                                    "closed → new issue with regression_of link"], kind="sync")
step(5, 3, "19", "Report",        "Platform + AI", "MVP · R3 AI", ["every number computed; AI writes the summary only;",
                                                                    "run, workflow, portfolio, readiness views"], kind="ai")
vconn(5, 0, 1); vconn(5, 1, 2); vconn(5, 2, 3)
# bypass 16 → 19 (report does not wait for defects)
bx = lane_x(5) + LANE_W + 16
arrow([(lane_x(5) + LANE_W, row_mid(0)), (bx, row_mid(0)), (bx, row_y(3) + 22), (lane_x(5) + LANE_W, row_y(3) + 22)])
text(bx + 5, row_mid(1) + 20, "always,", size=8.5, fill=MUTED, weight="600")
text(bx + 5, row_mid(1) + 31, "from", size=8.5, fill=MUTED, weight="600")
text(bx + 5, row_mid(1) + 42, "run.completed", size=8, fill=MUTED, weight="600", font=MONO)
# rerun-on-fix pill (row 4) and loop back to 13
rp_x, rp_y, rp_w, rp_h = lane_x(5), row_y(4) + 8, LANE_W, ROW_H - 16
amber_pill(rp_x, rp_y, rp_w, rp_h, ["Loop: rerun on fix (R3)",
                                    "Jira → ready-for-QA webhook → run scope defect:{key}",
                                    "linked cases + same endpoint + dependency chain"])
arrow([(rp_x + rp_w / 2, rp_y + rp_h), (rp_x + rp_w / 2, LOOP_Y), (lane_x(4) - 4, LOOP_Y), (lane_x(4) - 4, row_y(0) + 58), (lane_x(4), row_y(0) + 58)], color=AMBER)
text((rp_x + rp_w / 2 + lane_x(4) - 4) / 2, LOOP_Y - 9, "result is commented on the Jira issue; the run record links the defect", size=9, anchor="middle", weight="600", fill=AMBER)
# end node
ex = lane_x(5) + LANE_W
arrow([(ex, row_y(3) + 60), (ex + 26, row_y(3) + 60)])
w(f"<circle cx='{ex+40}' cy='{row_y(3)+60}' r='11' fill='none' stroke='{INK}' stroke-width='2'/><circle cx='{ex+40}' cy='{row_y(3)+60}' r='6' fill='{INK}'/>")
text(ex + 40, row_y(3) + 80, "release", size=9, anchor="middle", fill=MUTED)
text(ex + 40, row_y(3) + 91, "decision", size=9, anchor="middle", fill=MUTED)

# ------------------------------------------------------------------ state strip
state_strip(0, "spec_version.accepted", "readiness report (green, or yellow with ack_reason)")
state_strip(1, "api_model.confirmed",   "API model, versioned with the spec")
state_strip(2, "suite.approved",        "canonical test cases + assertion DSL (source of truth)")
state_strip(3, "suite.ready",           "data sets + valid Karate project, committed to Git")
state_strip(4, "run.completed",         "immutable run record + masked evidence  (→ synced)")
state_strip(5, "triage.decided",        "defects in Jira, rerun evidence, report + dashboards")

# ------------------------------------------------------------------ legend
def leg_box(x, fill, stroke, dashed=False):
    d = " stroke-dasharray='4 2'" if dashed else ""
    w(f"<rect x='{x}' y='{LEGEND_Y-9}' width='20' height='18' rx='4' fill='{fill}' stroke='{stroke}' stroke-width='1.5'{d}/>")
lx = 60
leg_box(lx, "#ffffff", INK); text(lx + 28, LEGEND_Y, "Deterministic (Platform / Runner)", size=11)
lx = 300
leg_box(lx, BLUE_BG, BLUE); text(lx + 28, LEGEND_Y, "AI-assisted — drafts only, validated into a model or rejected", size=11)
lx = 700
w(f"<polygon points='{lx+10},{LEGEND_Y-10} {lx+20},{LEGEND_Y} {lx+10},{LEGEND_Y+10} {lx},{LEGEND_Y}' fill='{GREEN_BG}' stroke='{GREEN}' stroke-width='1.5'/>")
text(lx + 28, LEGEND_Y, "Human gate: approve · edit · reject(reason) · regenerate(comment)", size=11)
lx = 1120
leg_box(lx, SYNC_BG, SYNC, dashed=True); text(lx + 28, LEGEND_Y, "Sync to an external system (optional branch)", size=11)
lx = 1420
w(f"<line x1='{lx}' y1='{LEGEND_Y}' x2='{lx+30}' y2='{LEGEND_Y}' stroke='{AMBER}' stroke-width='1.6' marker-end='url(#arrowAmber)'/>")
text(lx + 38, LEGEND_Y, "Loop", size=11)
w(f"<line x1='{lx+80}' y1='{LEGEND_Y}' x2='{lx+110}' y2='{LEGEND_Y}' stroke='{RED}' stroke-width='1.6' stroke-dasharray='5 4' marker-end='url(#arrowRed)'/>")
text(lx + 118, LEGEND_Y, "Stop", size=11)
lx = 1620
for i, (tok, col) in enumerate([("MVP", MUTED), ("R2", BLUE), ("R3", "#7c3aed")]):
    pw = tw(tok, 8) + 10
    w(f"<rect x='{lx}' y='{LEGEND_Y-7}' width='{pw:.1f}' height='14' rx='4' fill='#ffffff' stroke='{col}' stroke-width='0.9'/>")
    text(lx + pw / 2, LEGEND_Y, tok, size=8, anchor="middle", weight="700", fill=col, font=MONO)
    lx += pw + 5
text(lx + 6, LEGEND_Y, "Release the step ships in", size=11)
text(60, LEGEND_Y + 24, "a / b = the same stage: deterministic first, AI only for what rules cannot do.   A gate's reject / regenerate returns to the step above it.   Dashed grey boxes are optional and never on the main path.", size=10.5, fill=MUTED, style="italic")

w("</svg>")
open("out/process-flow-v4.svg", "w").write("\n".join(out))
print("written")
