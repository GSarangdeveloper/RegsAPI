import os
os.makedirs('out', exist_ok=True)
#!/usr/bin/env python3
"""Phase 4 Build — whiteboard-style, one example flowing through."""
FONT = "Inter, 'Segoe UI', Helvetica, Arial, sans-serif"
MONO = "'JetBrains Mono', SFMono-Regular, Consolas, 'Liberation Mono', monospace"
INK, MUTED, LINE = "#1f2937", "#6b7280", "#9ca3af"
BLUE, BLUE_BG = "#2563eb", "#eff6ff"
GREEN, GREEN_BG, GREEN_INK = "#059669", "#ecfdf5", "#065f46"
AMBER, AMBER_BG, AMBER_INK = "#d97706", "#fffbeb", "#92400e"
RED, RED_BG, RED_INK = "#dc2626", "#fef2f2", "#991b1b"
GRAY_BG = "#f3f4f6"
W, H = 1700, 900
out = []
def w(s): out.append(s)
def esc(s): return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
def text(x, y, s, size=12, anchor="start", weight="normal", fill=INK, style="", font=FONT):
    st = f" font-style='{style}'" if style else ""
    lead = len(s) - len(s.lstrip(' '))
    s = '\u00a0' * lead + s.lstrip(' ')
    w(f"<text x='{x}' y='{y}' font-size='{size}' text-anchor='{anchor}' font-weight='{weight}' fill='{fill}'{st} dominant-baseline='middle' font-family=\"{font}\">{esc(s)}</text>")
def rect(x, y, wd, h, fill, stroke, rx=14, sw=2, dash=""):
    d = f" stroke-dasharray='{dash}'" if dash else ""
    w(f"<rect x='{x}' y='{y}' width='{wd}' height='{h}' rx='{rx}' fill='{fill}' stroke='{stroke}' stroke-width='{sw}'{d}/>")
def arrow(pts, color=INK, width=2.4, dashed=False):
    p = " ".join(f"{x},{y}" for x, y in pts)
    m = {INK: "a", BLUE: "aB", AMBER: "aA", RED: "aR", GREEN: "aG"}[color]
    d = " stroke-dasharray='7 5'" if dashed else ""
    w(f"<polyline points='{p}' fill='none' stroke='{color}' stroke-width='{width}'{d} stroke-linejoin='round' marker-end='url(#{m})'/>")
def badge(x, y, n, color=INK, r=15):
    w(f"<circle cx='{x}' cy='{y}' r='{r}' fill='{color}'/>")
    text(x, y, str(n), size=15, anchor="middle", weight="700", fill="#ffffff")
def doc(x, y, wd, h, title, lines, stroke=INK, fill="#ffffff", size=10.5, lh=15):
    # a "document" shape with a folded corner
    f = 14
    w(f"<path d='M{x},{y+8} q0,-8 8,-8 h{wd-8-f} l{f},{f} v{h-f-8} q0,8 -8,8 h{-(wd-16)} q-8,0 -8,-8 z' fill='{fill}' stroke='{stroke}' stroke-width='2'/>")
    w(f"<path d='M{x+wd-f},{y} v{f} h{f}' fill='none' stroke='{stroke}' stroke-width='2'/>")
    text(x + 12, y + 20, title, size=11, weight="700", fill=stroke if stroke != INK else MUTED, font=MONO)
    for i, ln in enumerate(lines):
        text(x + 12, y + 42 + i * lh, ln, size=size, fill=INK, font=MONO)
def bubble(x, y, wd, h, title, lines, stroke, fill, ink, tail=None):
    rect(x, y, wd, h, fill, stroke, rx=16)
    if tail:  # small triangle pointing up to (tx, y)
        tx = tail
        w(f"<path d='M{tx-10},{y+1} L{tx},{y-14} L{tx+10},{y+1} z' fill='{fill}' stroke='{stroke}' stroke-width='2'/>")
        w(f"<line x1='{tx-9}' y1='{y+1}' x2='{tx+9}' y2='{y+1}' stroke='{fill}' stroke-width='3'/>")
    text(x + 16, y + 24, title, size=14, weight="700", fill=ink)
    for i, ln in enumerate(lines):
        text(x + 16, y + 48 + i * 18, ln, size=11.5, fill=ink)

w(f"<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 {W} {H}' role='img' aria-labelledby='t'>")
w("<title id='t'>How test data is made — the whiteboard version</title>")
w("<defs>")
for mid, col in [("a", INK), ("aB", BLUE), ("aA", AMBER), ("aR", RED), ("aG", GREEN), ("aP", "#7c3aed")]:
    w(f"<marker id='{mid}' viewBox='0 0 10 10' refX='9' refY='5' markerWidth='6' markerHeight='6' orient='auto-start-reverse'><path d='M0,0 L10,5 L0,10 z' fill='{col}'/></marker>")
w("</defs>")
rect(0, 0, W, H, "#ffffff", "none", rx=0, sw=0)



PURPLE, PURPLE_BG, PURPLE_INK = "#7c3aed", "#f5f3ff", "#5b21b6"
def arrow(pts, color=INK, width=2.4, dashed=False):
    p = " ".join(f"{x},{y}" for x, y in pts)
    m = {INK: "a", BLUE: "aB", AMBER: "aA", RED: "aR", GREEN: "aG", PURPLE: "aP"}[color]
    d = " stroke-dasharray='7 5'" if dashed else ""
    w(f"<polyline points='{p}' fill='none' stroke='{color}' stroke-width='{width}'{d} stroke-linejoin='round' marker-end='url(#{m})'/>")
def steps_row(Y, cols, BH_=118):
    for x, wd, t, lines, col, fill, n in cols:
        rect(x, Y, wd, BH_, fill, col, rx=16, sw=2.5)
        tx = x + 18
        if n:
            badge(x + 26, Y + 26, n, col); tx = x + 50
        text(tx, Y + 26, t, size=16, weight="700", fill=col if col != INK else INK)
        for i, ln in enumerate(lines):
            text(x + 18, Y + 54 + i * 17, ln, size=12.5, fill=MUTED)
    for i in range(len(cols) - 1):
        x1 = cols[i][0] + cols[i][1]; x2 = cols[i + 1][0]
        arrow([(x1 + 4, Y + BH_ / 2), (x2 - 4, Y + BH_ / 2)], width=3)
def bracket(x1, x2, y, label, col=MUTED):
    w(f"<path d='M{x1},{y} v8 h{x2-x1} v-8' fill='none' stroke='{col}' stroke-width='1.5'/>")
    text((x1 + x2) / 2, y + 20, label, size=11, anchor="middle", fill=col, style="italic")
def table(x, y, wd, h, title, rows, kx=270, size=11.5):
    rect(x, y, wd, h, "#ffffff", LINE, rx=14, sw=1.5)
    text(x + 16, y + 24, title, size=13, weight="700")
    for i, (a, b) in enumerate(rows):
        text(x + 16, y + 50 + i * 24, a, size=size, weight="700", font=MONO)
        text(x + kx, y + 50 + i * 24, b, size=size, fill=MUTED)
def footer(done, remember):
    text(40, H - 42, "Done when:", size=12.5, weight="700", fill=GREEN_INK)
    text(130, H - 42, done, size=11.5, fill=GREEN_INK)
    text(40, H - 18, remember, size=12, fill=MUTED, style="italic")

def code(x, y, wd, h, title, lines, stroke=INK, fill="#ffffff", size=10.5, lh=15, hi=None):
    rect(x, y, wd, h, fill, stroke, rx=12, sw=2)
    text(x + 14, y + 20, title, size=12, weight="700", fill=stroke if stroke != INK else INK)
    for i, ln in enumerate(lines):
        col = (hi or {}).get(i, INK)
        text(x + 14, y + 42 + i * lh, ln, size=size, fill=col, font=MONO)

text(40, 44, "How test data is made — three sources, and AI is only in one of them", size=28, weight="700")
text(40, 78, "Every test case needs a request body and, for chains, real ids. Most of it is built by code from the spec. AI helps in one place: understanding a CSV a QE uploads. Real records come from a catalog, matched by code.", size=15, fill=MUTED)

# ---------------- three lanes
Y = 116
LW, LH_ = 520, 330
lanes = [
    (40, "1 · From the spec  (release 1, code only)", INK, "#ffffff", "every case, always", [
        "The rule engine knows each field's type, format, limits and example.",
        "It builds the smallest valid body, then applies the case's ONE change.",
        "Values it must invent follow the spec: a date is a date, an enum is one",
        "of the listed values, an id is 'gen: uuid' filled in at run time.",
        "",
        "Chains pass ids along: ${create.response.body.claimId} becomes a",
        "Karate variable — no id is ever typed into a file.",
    ], [
        'data/qa/TC-CLM-0031.json',
        '{ "memberId": "M-1001",       ← from the spec example',
        '  "amount": 120.50,           ← example',
        '  "serviceDate": "{{today-30d}}", ← gen at run time',
        '  "planCode": "GOLD" }        ← first enum value',
        'mutation: remove /memberId    ← the ONE change',
    ]),
    (600, "2 · From a CSV a QE uploads  (R2, AI helps once)", BLUE, BLUE_BG, "optional, per endpoint", [
        "QEs often have real-looking rows in a spreadsheet: member numbers,",
        "plans, dates. The AI's job is small: read the column names and 5",
        "MASKED rows and say which field each column feeds, with a confidence.",
        "The QE confirms the mapping (a gate that exists only when a CSV was",
        "uploaded). After that, code turns rows into data files — no AI.",
        "",
        "Low-confidence columns are shown first; unmapped columns are ignored.",
    ], [
        'members.csv:  member_no, birth_dt, plan, zip',
        'AI mapping:',
        '  member_no → memberId     0.95 ✓',
        '  birth_dt  → member.dob   0.98 ✓',
        '  plan      → planCode     0.70  ? (QE confirms)',
        '  zip       → (none)       —',
        '→ data/qa/TC-CLM-0040.csv  (one row = one scenario run)',
    ]),
    (1140, "3 · From the QA data catalog  (R2, code only)", GREEN, GREEN_BG, "when a case needs a REAL record", [
        "Some cases need a record that already exists in the environment:",
        "'an active member over 65'. The case states that as a filter, not a",
        "value. The catalog (uploaded by QA, per environment) holds such",
        "records; pre-flight matches by filter and RESERVES one for the run.",
        "",
        "No match → the case runs as 'blocked' and the report says exactly",
        "what QA must add. Consumable records are released after the run.",
    ], [
        'case data_requirement:',
        '  { "status": {"eq": "ACTIVE"},',
        '    "age":    {"gte": 65} }   mode: consumable',
        'catalog qa: 41 members match → reserve 1',
        '  → memberId M-2207 injected at run time',
        'no match → result: blocked',
        '  "need: ACTIVE member, age ≥ 65"',
    ]),
]
for x, title, col, fill, tag, prose, snippet in lanes:
    rect(x, Y, LW, LH_, fill if col != INK else "#ffffff", col, rx=16, sw=2.5)
    text(x + 16, Y + 24, title, size=14, weight="700", fill=col if col != INK else INK)
    tw_ = len(tag) * 6.2 + 14
    rect(x + 16, Y + 36, tw_, 18, "#ffffff", col, rx=9, sw=1)
    text(x + 16 + tw_ / 2, Y + 45, tag, size=9.5, anchor="middle", weight="600", fill=col if col != INK else MUTED)
    for i, ln in enumerate(prose):
        text(x + 16, Y + 70 + i * 14.5, ln, size=11, fill=INK if col == INK else {BLUE: "#1e40af", GREEN: GREEN_INK}[col])
    code(x + 16, Y + 176, LW - 32, 142, "example", snippet, stroke=col, size=10, lh=14.5)

# ---------------- callouts
CY = Y + LH_ + 30
bubble(40, CY, 500, 176, "What the AI never sees, even here", [
    "Only the column names and 5 rows, and those rows are masked",
    "first (the PHI guard runs on the sample). It never sees the whole",
    "CSV, never a real catalog record, never a full data set.",
    "It answers one question — which column is which field — and",
    "that answer is checked against the schema (types must fit) and",
    "confirmed by a QE before a single data file is written from it.",
], RED, RED_BG, RED_INK)
bubble(580, CY, 520, 176, "Why 'realistic' values are NOT an AI job in release 1", [
    "The spec already says what a value must look like: format,",
    "min/max, pattern, enum, example. Code that follows those rules",
    "produces valid data every time and never leaks anything. A model",
    "asked for 'a realistic member' might produce a real one.",
    "If a team wants prettier names later, that is a small, separate",
    "R2 feature with the same guard — not part of the core path.",
], AMBER, AMBER_BG, AMBER_INK)
bubble(1140, CY, 520, 176, "Where the data lives and how it is versioned", [
    "data/{env}/{case_id}.json  — the body, per environment",
    "data/{env}/{case_id}.csv   — rows for data-driven cases",
    "Both are built by the Phase 4 worker, stored in the inputs bucket",
    "and committed with the scripts. A run pins a data_version, so a",
    "re-run a month later uses the same rows. Catalog records are the",
    "exception: matched fresh at pre-flight, then released.",
], INK, "#ffffff", INK)

# ---------------- table
TY = CY + 196
table(40, TY, 1620, 176, "Who does what — the honest split", [
    ("code, from the spec", "builds every body, applies every mutation, generates ids/dates/enums, passes ids along chains  — release 1, always"),
    ("AI, once per CSV", "proposes column → field mapping from headers + 5 masked rows; a QE confirms  — release 2, only if a CSV exists"),
    ("code, from the catalog", "matches a case's filter to real records, reserves one per run, blocks the case if none  — release 2"),
    ("a QE", "uploads the CSV, confirms the mapping, keeps the catalog current, reads the blocked list"),
    ("never", "AI inventing 'real-looking' personal data · AI seeing a full CSV or a catalog record · a real id typed into a file"),
], kx=250)
text(40, H - 18, "Remember: the spec is the source of every value the platform invents; a QE is the source of every real one; AI only translates a spreadsheet's column names.", size=12, fill=MUTED, style="italic")
w("</svg>")
open("out/knowledge-C-test-data.svg", "w").write("\n".join(out))
print("ok")
