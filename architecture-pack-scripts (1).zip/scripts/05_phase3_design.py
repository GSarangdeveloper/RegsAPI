import os
os.makedirs('out', exist_ok=True)
#!/usr/bin/env python3
"""Phase 4 Build — whiteboard-style, one example flowing through."""
FONT = "Inter, 'Segoe UI', Helvetica, Arial, sans-serif"
MONO = "'JetBrains Mono', SFMono-Regular, Consolas, 'Liberation Mono', monospace"
INK, MUTED, LINE = "#1f2937", "#6b7280", "#9ca3af"
BLUE, BLUE_BG = "#2563eb", "#eff6ff"
GREEN, GREEN_BG, GREEN_INK = "#059669", "#ecfdf5", "#065f46"
AMBER, AMBER_BG, AMBER_INK = "#d97706", "#fffbeb", "#92400e"
RED, RED_BG, RED_INK = "#dc2626", "#fef2f2", "#991b1b"
GRAY_BG = "#f3f4f6"
W, H = 1700, 1010
out = []
def w(s): out.append(s)
def esc(s): return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
def text(x, y, s, size=12, anchor="start", weight="normal", fill=INK, style="", font=FONT):
    st = f" font-style='{style}'" if style else ""
    lead = len(s) - len(s.lstrip(' '))
    s = '\u00a0' * lead + s.lstrip(' ')
    w(f"<text x='{x}' y='{y}' font-size='{size}' text-anchor='{anchor}' font-weight='{weight}' fill='{fill}'{st} dominant-baseline='middle' font-family=\"{font}\">{esc(s)}</text>")
def rect(x, y, wd, h, fill, stroke, rx=14, sw=2, dash=""):
    d = f" stroke-dasharray='{dash}'" if dash else ""
    w(f"<rect x='{x}' y='{y}' width='{wd}' height='{h}' rx='{rx}' fill='{fill}' stroke='{stroke}' stroke-width='{sw}'{d}/>")
def arrow(pts, color=INK, width=2.4, dashed=False):
    p = " ".join(f"{x},{y}" for x, y in pts)
    m = {INK: "a", BLUE: "aB", AMBER: "aA", RED: "aR", GREEN: "aG"}[color]
    d = " stroke-dasharray='7 5'" if dashed else ""
    w(f"<polyline points='{p}' fill='none' stroke='{color}' stroke-width='{width}'{d} stroke-linejoin='round' marker-end='url(#{m})'/>")
def badge(x, y, n, color=INK, r=15):
    w(f"<circle cx='{x}' cy='{y}' r='{r}' fill='{color}'/>")
    text(x, y, str(n), size=15, anchor="middle", weight="700", fill="#ffffff")
def doc(x, y, wd, h, title, lines, stroke=INK, fill="#ffffff", size=10.5, lh=15):
    # a "document" shape with a folded corner
    f = 14
    w(f"<path d='M{x},{y+8} q0,-8 8,-8 h{wd-8-f} l{f},{f} v{h-f-8} q0,8 -8,8 h{-(wd-16)} q-8,0 -8,-8 z' fill='{fill}' stroke='{stroke}' stroke-width='2'/>")
    w(f"<path d='M{x+wd-f},{y} v{f} h{f}' fill='none' stroke='{stroke}' stroke-width='2'/>")
    text(x + 12, y + 20, title, size=11, weight="700", fill=stroke if stroke != INK else MUTED, font=MONO)
    for i, ln in enumerate(lines):
        text(x + 12, y + 42 + i * lh, ln, size=size, fill=INK, font=MONO)
def bubble(x, y, wd, h, title, lines, stroke, fill, ink, tail=None):
    rect(x, y, wd, h, fill, stroke, rx=16)
    if tail:  # small triangle pointing up to (tx, y)
        tx = tail
        w(f"<path d='M{tx-10},{y+1} L{tx},{y-14} L{tx+10},{y+1} z' fill='{fill}' stroke='{stroke}' stroke-width='2'/>")
        w(f"<line x1='{tx-9}' y1='{y+1}' x2='{tx+9}' y2='{y+1}' stroke='{fill}' stroke-width='3'/>")
    text(x + 16, y + 24, title, size=14, weight="700", fill=ink)
    for i, ln in enumerate(lines):
        text(x + 16, y + 48 + i * 18, ln, size=11.5, fill=ink)

w(f"<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 {W} {H}' role='img' aria-labelledby='t'>")
w("<title id='t'>Phase 3 Design — the whiteboard version</title>")
w("<defs>")
for mid, col in [("a", INK), ("aB", BLUE), ("aA", AMBER), ("aR", RED), ("aG", GREEN), ("aP", "#7c3aed")]:
    w(f"<marker id='{mid}' viewBox='0 0 10 10' refX='9' refY='5' markerWidth='6' markerHeight='6' orient='auto-start-reverse'><path d='M0,0 L10,5 L0,10 z' fill='{col}'/></marker>")
w("</defs>")
rect(0, 0, W, H, "#ffffff", "none", rx=0, sw=0)



PURPLE, PURPLE_BG, PURPLE_INK = "#7c3aed", "#f5f3ff", "#5b21b6"
def arrow(pts, color=INK, width=2.4, dashed=False):
    p = " ".join(f"{x},{y}" for x, y in pts)
    m = {INK: "a", BLUE: "aB", AMBER: "aA", RED: "aR", GREEN: "aG", PURPLE: "aP"}[color]
    d = " stroke-dasharray='7 5'" if dashed else ""
    w(f"<polyline points='{p}' fill='none' stroke='{color}' stroke-width='{width}'{d} stroke-linejoin='round' marker-end='url(#{m})'/>")
def steps_row(Y, cols, BH_=118):
    for x, wd, t, lines, col, fill, n in cols:
        rect(x, Y, wd, BH_, fill, col, rx=16, sw=2.5)
        tx = x + 18
        if n:
            badge(x + 26, Y + 26, n, col); tx = x + 50
        text(tx, Y + 26, t, size=16, weight="700", fill=col if col != INK else INK)
        for i, ln in enumerate(lines):
            text(x + 18, Y + 54 + i * 17, ln, size=12.5, fill=MUTED)
    for i in range(len(cols) - 1):
        x1 = cols[i][0] + cols[i][1]; x2 = cols[i + 1][0]
        arrow([(x1 + 4, Y + BH_ / 2), (x2 - 4, Y + BH_ / 2)], width=3)
def bracket(x1, x2, y, label, col=MUTED):
    w(f"<path d='M{x1},{y} v8 h{x2-x1} v-8' fill='none' stroke='{col}' stroke-width='1.5'/>")
    text((x1 + x2) / 2, y + 20, label, size=11, anchor="middle", fill=col, style="italic")
def table(x, y, wd, h, title, rows, kx=270, size=11.5):
    rect(x, y, wd, h, "#ffffff", LINE, rx=14, sw=1.5)
    text(x + 16, y + 24, title, size=13, weight="700")
    for i, (a, b) in enumerate(rows):
        text(x + 16, y + 50 + i * 24, a, size=size, weight="700", font=MONO)
        text(x + kx, y + 50 + i * 24, b, size=size, fill=MUTED)
def footer(done, remember):
    text(40, H - 42, "Done when:", size=12.5, weight="700", fill=GREEN_INK)
    text(130, H - 42, done, size=11.5, fill=GREEN_INK)
    text(40, H - 18, remember, size=12, fill=MUTED, style="italic")

text(40, 44, "Phase 3 · Design", size=30, weight="700")
text(40, 78, "Write the test cases from the facts in the spec, prove each one against the spec, measure coverage, and let the QE approve. No AI in release 1; in release 2 AI fills only the gaps.", size=15, fill=MUTED)
text(W - 40, 44, "release 1 · rule engine only", size=13, anchor="end", fill=LINE)
text(W - 40, 64, "who: a worker pod does 1, 2, 3 · a QE decides at 4 · the api pod serves the review queue and records every decision", size=13, anchor="end", fill=LINE)

Y = 120
steps_row(Y, [
    (40,   190, "API model", ["confirmed, from", "Phase 2: endpoints,", "fields, edges, rules"], GREEN, GREEN_BG, None),
    (300,  250, "Rule engine writes cases", ["six generators, one per kind of", "coverage; input = the model;", "output = test-case JSON drafts"], INK, "#ffffff", 1),
    (610,  250, "Check against the spec", ["endpoint exists? status", "documented? asserted field real?", "no → the draft is dropped"], INK, "#ffffff", 2),
    (920,  250, "Dedup · priority · cover", ["merge duplicates, set P1/P2/P3,", "cap per endpoint, measure covered", "/ universe per dimension"], INK, "#ffffff", 3),
    (1230, 250, "QE reviews, approves", ["review queue: approve · edit ·", "reject; bulk-approve high", "confidence; lead accepts gaps"], GREEN, GREEN_BG, 4),
    (1540, 120, "Approved", ["suite frozen →", "Phase 4 builds", "scripts"], INK, GRAY_BG, None),
])
text(265, Y - 14, "starts when the QE", size=10.5, anchor="middle", weight="600", fill=GREEN_INK)
text(265, Y - 1, "presses Generate", size=10.5, anchor="middle", weight="600", fill=GREEN_INK)
bracket(300, 1170, Y + 128, "worker pod, pure functions, no network — a 50-endpoint spec in under 60 s")
bracket(1230, 1480, Y + 128, "api pod + browser")

SY = 292
text(40, SY, "One endpoint followed through every step — POST /claims (create a claim)", size=14, weight="700", fill=MUTED)
DY = SY + 20; DH = 160
doc(40, DY, 230, DH, "from the API model", [
    'POST /claims  (createClaim)',
    'responses: 201 400 401 404',
    'body fields:',
    ' memberId  string  req',
    ' amount    number  min 0',
    ' dob       date    sensitive',
    'edge → GET /claims/{id}',
    'rule R-12 (from a story)'], stroke=GREEN, size=10.2, lh=14)
doc(300, DY, 250, DH, "drafts written", [
    'structural     1  (happy path)',
    'response_code  3  (400 401 404)',
    'schema         6 rows',
    'boundary       4 rows',
    'dependency     1  (chain)',
    'security       3',
    'business_rule  0  ← gap R-12',
    '= 18 drafts'], size=10.2, lh=14)
doc(610, DY, 250, DH, "contract check", [
    '17 ✓',
    ' 1 ✗ dropped:',
    '   asserted 422, but',
    '   POST /claims documents',
    '   only 201 400 401 404',
    '',
    '(an engine draft failing',
    ' here = a bug: fail loudly)'], size=10.2, lh=14)
doc(920, DY, 250, DH, "after step 3", [
    '17 cases  (0 duplicates)',
    'P1 5 · P2 6 · P3 6',
    'confidence: 15 high, 2 med',
    'coverage, POST /claims:',
    ' structural   1/1  100%',
    ' response     3/3  100%',
    ' boundary     4/5   80%',
    ' business     0/1  GAP'], size=10.2, lh=14)
doc(1230, DY, 250, DH, "review queue", [
    'bulk approve  15 high ✓',
    'one by one     2 medium',
    '  TC-0044 edit: fix title',
    '  TC-0045 reject: dup of 0040',
    'gap R-12: lead accepts',
    '  "no stories yet"',
    'all P1 decided ✓',
    '→ approve suite'], stroke=GREEN, size=10.2, lh=14)
doc(1540, DY, 120, DH, "suite v3", [
    'approved',
    '16 cases',
    'TC-CLM-',
    ' 0031…0046',
    'frozen',
    '',
    'matrix',
    'snapshot'], size=10.2, lh=14)
for x1, x2 in [(270, 300), (550, 610), (860, 920), (1170, 1230), (1480, 1540)]:
    arrow([(x1 + 4, DY + DH / 2), (x2 - 4, DY + DH / 2)], color=INK, width=1.6)

CY = 522
bubble(40, CY, 500, 186, "Do we need AI to write tests?  Not in release 1.", [
    "Six of the seven kinds of coverage are FACTS in the spec:",
    "which endpoints, which status codes, which fields and limits,",
    "which calls depend on which, who may call what. Code writes",
    "those exactly, every time, and can be unit-tested.",
    "The seventh — business rules — lives in prose in Jira stories.",
    "Only that needs AI, and that is release 2.",
], AMBER, AMBER_BG, AMBER_INK)
bubble(580, CY, 520, 186, "Approve is guarded, not a button", [
    "The API refuses to approve unless: every P1 case has a",
    "decision, AND every dimension is at its threshold or a QE",
    "lead has accepted the gap with a reason.",
    "Low-confidence cases can never be bulk-approved.",
    "Every edit quotes the row_version it saw; a stale edit gets",
    "409, never a silent overwrite. On approval the suite freezes.",
], GREEN, GREEN_BG, GREEN_INK)
bubble(1140, CY, 520, 186, "Where AI fits in release 2: the gaps only", [
    "After step 3, each endpoint with a gap becomes one AI job.",
    "The model sees that endpoint's slice, its documented responses,",
    "the confirmed rules, the gap list and 3 approved examples.",
    "It returns test-case JSON that goes through the SAME step 2.",
    "At most 3 rounds, then review regardless. AI cases are never",
    "'high' confidence, so a person always looks at them.",
], BLUE, BLUE_BG, "#1e40af")

TY = 738
table(40, TY, 800, 196, "The six generators — what each one writes from the model alone", [
    ("structural", "one happy path per endpoint: smallest valid body, documented success status"),
    ("response_code", "one case per documented error: 400 drop a field · 401 no login · 403 wrong role · 404 bad id"),
    ("schema", "rows: each required field removed / null / wrong type; extra field if not allowed"),
    ("boundary", "rows: min-1, min, max, max+1, empty, too long, bad enum, bad format"),
    ("dependency", "per confirmed edge: create → get → update → delete → get again (404)"),
    ("security", "no token · expired · wrong scope · another user's record · injection strings (never 500)"),
], kx=200)
table(870, TY, 790, 196, "One test case = one JSON document (the truth everything else is derived from)", [
    ("case_id · title · type · priority", "TC-CLM-0031 · Reject claim without member id · negative · p1"),
    ("steps[]", "alias, endpoint, login profile, request (body base + ONE mutation), expect (status, assertions)"),
    ("coverage_targets[]", "what this case proves: op:createClaim:400 · field:createClaim:req:/memberId"),
    ("confidence · origin", "high = from an explicit spec fact · medium = from a guess or AI · rule_engine | ai | manual"),
    ("cleanup[]", "which created things to delete after the run"),
    ("row_version · locked", "for safe concurrent edits · a QE-edited case the generator must not touch"),
], kx=290)
footer("generate → cases for all six kinds; every case passes the spec check; matrix meets every threshold except business rules · 50 endpoints in < 60 s · bulk-approve high, 409 on a stale edit, approve blocked until P1 reviewed, lead accepts a gap, suite freezes.",
       "Remember: the engine never guesses — no case for a status or a field the spec does not document. A case has ONE deliberate mutation, so a failure has one cause.")
w("</svg>")
open("out/architecture-3-design.svg", "w").write("\n".join(out))
print("ok")
