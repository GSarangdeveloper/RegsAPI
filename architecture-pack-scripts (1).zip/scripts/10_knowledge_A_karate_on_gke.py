import os
os.makedirs('out', exist_ok=True)
#!/usr/bin/env python3
"""Phase 4 Build — whiteboard-style, one example flowing through."""
FONT = "Inter, 'Segoe UI', Helvetica, Arial, sans-serif"
MONO = "'JetBrains Mono', SFMono-Regular, Consolas, 'Liberation Mono', monospace"
INK, MUTED, LINE = "#1f2937", "#6b7280", "#9ca3af"
BLUE, BLUE_BG = "#2563eb", "#eff6ff"
GREEN, GREEN_BG, GREEN_INK = "#059669", "#ecfdf5", "#065f46"
AMBER, AMBER_BG, AMBER_INK = "#d97706", "#fffbeb", "#92400e"
RED, RED_BG, RED_INK = "#dc2626", "#fef2f2", "#991b1b"
GRAY_BG = "#f3f4f6"
W, H = 1700, 950
out = []
def w(s): out.append(s)
def esc(s): return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
def text(x, y, s, size=12, anchor="start", weight="normal", fill=INK, style="", font=FONT):
    st = f" font-style='{style}'" if style else ""
    lead = len(s) - len(s.lstrip(' '))
    s = '\u00a0' * lead + s.lstrip(' ')
    w(f"<text x='{x}' y='{y}' font-size='{size}' text-anchor='{anchor}' font-weight='{weight}' fill='{fill}'{st} dominant-baseline='middle' font-family=\"{font}\">{esc(s)}</text>")
def rect(x, y, wd, h, fill, stroke, rx=14, sw=2, dash=""):
    d = f" stroke-dasharray='{dash}'" if dash else ""
    w(f"<rect x='{x}' y='{y}' width='{wd}' height='{h}' rx='{rx}' fill='{fill}' stroke='{stroke}' stroke-width='{sw}'{d}/>")
def arrow(pts, color=INK, width=2.4, dashed=False):
    p = " ".join(f"{x},{y}" for x, y in pts)
    m = {INK: "a", BLUE: "aB", AMBER: "aA", RED: "aR", GREEN: "aG"}[color]
    d = " stroke-dasharray='7 5'" if dashed else ""
    w(f"<polyline points='{p}' fill='none' stroke='{color}' stroke-width='{width}'{d} stroke-linejoin='round' marker-end='url(#{m})'/>")
def badge(x, y, n, color=INK, r=15):
    w(f"<circle cx='{x}' cy='{y}' r='{r}' fill='{color}'/>")
    text(x, y, str(n), size=15, anchor="middle", weight="700", fill="#ffffff")
def doc(x, y, wd, h, title, lines, stroke=INK, fill="#ffffff", size=10.5, lh=15):
    # a "document" shape with a folded corner
    f = 14
    w(f"<path d='M{x},{y+8} q0,-8 8,-8 h{wd-8-f} l{f},{f} v{h-f-8} q0,8 -8,8 h{-(wd-16)} q-8,0 -8,-8 z' fill='{fill}' stroke='{stroke}' stroke-width='2'/>")
    w(f"<path d='M{x+wd-f},{y} v{f} h{f}' fill='none' stroke='{stroke}' stroke-width='2'/>")
    text(x + 12, y + 20, title, size=11, weight="700", fill=stroke if stroke != INK else MUTED, font=MONO)
    for i, ln in enumerate(lines):
        text(x + 12, y + 42 + i * lh, ln, size=size, fill=INK, font=MONO)
def bubble(x, y, wd, h, title, lines, stroke, fill, ink, tail=None):
    rect(x, y, wd, h, fill, stroke, rx=16)
    if tail:  # small triangle pointing up to (tx, y)
        tx = tail
        w(f"<path d='M{tx-10},{y+1} L{tx},{y-14} L{tx+10},{y+1} z' fill='{fill}' stroke='{stroke}' stroke-width='2'/>")
        w(f"<line x1='{tx-9}' y1='{y+1}' x2='{tx+9}' y2='{y+1}' stroke='{fill}' stroke-width='3'/>")
    text(x + 16, y + 24, title, size=14, weight="700", fill=ink)
    for i, ln in enumerate(lines):
        text(x + 16, y + 48 + i * 18, ln, size=11.5, fill=ink)

w(f"<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 {W} {H}' role='img' aria-labelledby='t'>")
w("<title id='t'>How Karate runs on GKE — the whiteboard version</title>")
w("<defs>")
for mid, col in [("a", INK), ("aB", BLUE), ("aA", AMBER), ("aR", RED), ("aG", GREEN), ("aP", "#7c3aed")]:
    w(f"<marker id='{mid}' viewBox='0 0 10 10' refX='9' refY='5' markerWidth='6' markerHeight='6' orient='auto-start-reverse'><path d='M0,0 L10,5 L0,10 z' fill='{col}'/></marker>")
w("</defs>")
rect(0, 0, W, H, "#ffffff", "none", rx=0, sw=0)



PURPLE, PURPLE_BG, PURPLE_INK = "#7c3aed", "#f5f3ff", "#5b21b6"
def arrow(pts, color=INK, width=2.4, dashed=False):
    p = " ".join(f"{x},{y}" for x, y in pts)
    m = {INK: "a", BLUE: "aB", AMBER: "aA", RED: "aR", GREEN: "aG", PURPLE: "aP"}[color]
    d = " stroke-dasharray='7 5'" if dashed else ""
    w(f"<polyline points='{p}' fill='none' stroke='{color}' stroke-width='{width}'{d} stroke-linejoin='round' marker-end='url(#{m})'/>")
def steps_row(Y, cols, BH_=118):
    for x, wd, t, lines, col, fill, n in cols:
        rect(x, Y, wd, BH_, fill, col, rx=16, sw=2.5)
        tx = x + 18
        if n:
            badge(x + 26, Y + 26, n, col); tx = x + 50
        text(tx, Y + 26, t, size=16, weight="700", fill=col if col != INK else INK)
        for i, ln in enumerate(lines):
            text(x + 18, Y + 54 + i * 17, ln, size=12.5, fill=MUTED)
    for i in range(len(cols) - 1):
        x1 = cols[i][0] + cols[i][1]; x2 = cols[i + 1][0]
        arrow([(x1 + 4, Y + BH_ / 2), (x2 - 4, Y + BH_ / 2)], width=3)
def bracket(x1, x2, y, label, col=MUTED):
    w(f"<path d='M{x1},{y} v8 h{x2-x1} v-8' fill='none' stroke='{col}' stroke-width='1.5'/>")
    text((x1 + x2) / 2, y + 20, label, size=11, anchor="middle", fill=col, style="italic")
def table(x, y, wd, h, title, rows, kx=270, size=11.5):
    rect(x, y, wd, h, "#ffffff", LINE, rx=14, sw=1.5)
    text(x + 16, y + 24, title, size=13, weight="700")
    for i, (a, b) in enumerate(rows):
        text(x + 16, y + 50 + i * 24, a, size=size, weight="700", font=MONO)
        text(x + kx, y + 50 + i * 24, b, size=size, fill=MUTED)
def footer(done, remember):
    text(40, H - 42, "Done when:", size=12.5, weight="700", fill=GREEN_INK)
    text(130, H - 42, done, size=11.5, fill=GREEN_INK)
    text(40, H - 18, remember, size=12, fill=MUTED, style="italic")

def code(x, y, wd, h, title, lines, stroke=INK, fill="#ffffff", size=10.5, lh=15, hi=None):
    rect(x, y, wd, h, fill, stroke, rx=12, sw=2)
    text(x + 14, y + 20, title, size=12, weight="700", fill=stroke if stroke != INK else INK)
    for i, ln in enumerate(lines):
        col = (hi or {}).get(i, INK)
        text(x + 14, y + 42 + i * lh, ln, size=size, fill=col, font=MONO)

text(40, 44, "How Karate runs on GKE — for a developer who has only run it on a laptop", size=28, weight="700")
text(40, 78, "Short version: it is the same command you run locally, inside a pod, started by a Kubernetes Job. Everything else on this page is about how the pod gets its inputs and where its outputs go.", size=15, fill=MUTED)

# ---------------- left: laptop vs pod
Y = 110
code(40, Y, 500, 150, "On your laptop today", [
    '$ cd workflows/claims',
    '$ export BASE_URL=https://qa.claims.example.com',
    '$ export AUTH_DEFAULT_BEARER=eyJ…',
    '$ java -jar karate.jar -t @p1 -T 4 features/',
    '',
    '→ target/karate-reports/karate-summary.json'], size=10.5, lh=17)
arrow([(290, Y + 150 + 6), (290, Y + 150 + 34)], width=3)
text(310, Y + 170, "exactly the same, but…", size=12, weight="700", fill=MUTED)
code(40, Y + 190, 500, 150, "Inside the runner pod (entrypoint.sh)", [
    'manifest=$(curl $MANIFEST_URL)        # what to run',
    'git clone --depth 1 $REPO -b $COMMIT   # the scripts',
    'gsutil cp gs://inputs/…/data-v7 data/  # the data',
    'source /var/run/secrets/apitest/env    # AUTH_* mounted',
    'java -jar karate.jar -t "$TAGS" -T 4 features/  # ← same',
    'mask + gsutil cp reports gs://evidence/runs/$RUN_ID/'], size=10.5, lh=17, stroke=BLUE, fill=BLUE_BG,
    hi={4: "#1e40af"})

# ---------------- middle: the picture
MX = 580
rect(MX, Y, 620, 340, "#fafafa", LINE, rx=16, sw=1.5)
text(MX + 16, Y + 22, "What Kubernetes sees for one run", size=13, weight="700")
# worker
rect(MX + 16, Y + 44, 170, 62, "#ffffff", INK, rx=10, sw=2)
text(MX + 101, Y + 64, "platform-worker", size=12, anchor="middle", weight="700")
text(MX + 101, Y + 82, "launcher.py", size=10.5, anchor="middle", fill=MUTED, font=MONO)
arrow([(MX + 186, Y + 75), (MX + 236, Y + 75)], width=2.4)
text(MX + 211, Y + 62, "creates", size=9.5, anchor="middle", fill=MUTED)
# job
rect(MX + 240, Y + 44, 360, 62, "#ffffff", INK, rx=10, sw=2)
text(MX + 254, Y + 64, "Job  run-482", size=12, weight="700")
text(MX + 254, Y + 82, "namespace runners · parallelism 4 · backoffLimit 0 · deadline 1h", size=9.5, fill=MUTED)
# pods
for i in range(4):
    px = MX + 240 + i * 92
    rect(px, Y + 130, 84, 84, BLUE_BG, BLUE, rx=10, sw=2)
    text(px + 42, Y + 150, f"pod {i}", size=11.5, anchor="middle", weight="700", fill="#1e40af")
    text(px + 42, Y + 168, f"shard {i}", size=10, anchor="middle", fill="#1e40af", font=MONO)
    text(px + 42, Y + 184, "Java 21", size=9.5, anchor="middle", fill=MUTED)
    text(px + 42, Y + 198, "karate.jar", size=9.5, anchor="middle", fill=MUTED, font=MONO)
    arrow([(px + 42, Y + 106), (px + 42, Y + 126)], width=1.8)
text(MX + 16, Y + 150, "4 shards =", size=11, weight="700", fill=MUTED)
text(MX + 16, Y + 166, "4 pods, each", size=11, fill=MUTED)
text(MX + 16, Y + 182, "runs a slice of", size=11, fill=MUTED)
text(MX + 16, Y + 198, "the feature files", size=11, fill=MUTED)
# targets below pods
tgt = [("API under test", "https://qa.claims…", BLUE), ("Git", "clone @commit", INK), ("Secret Manager", "mounted as files", RED), ("Cloud Storage", "data in, evidence out", INK)]
for i, (a, b, c) in enumerate(tgt):
    tx = MX + 16 + i * 148
    fill = {BLUE: BLUE_BG, RED: RED_BG, INK: "#ffffff"}[c]
    rect(tx, Y + 258, 138, 56, fill, c, rx=10, sw=1.8)
    text(tx + 69, Y + 276, a, size=11, anchor="middle", weight="700", fill=c if c != INK else INK)
    text(tx + 69, Y + 294, b, size=9.5, anchor="middle", fill=MUTED)
w(f"<line x1='{MX+240}' y1='{Y+236}' x2='{MX+600}' y2='{Y+236}' stroke='{LINE}' stroke-width='1.2' stroke-dasharray='4 3'/>")
text(MX + 420, Y + 228, "the only things a runner pod may talk to (NetworkPolicy)", size=9.5, anchor="middle", fill=MUTED, style="italic")
text(MX + 420, Y + 248, "never the database · never production", size=9.5, anchor="middle", weight="700", fill=RED_INK)

# ---------------- right: how inputs reach the pod
RX = 1240
rect(RX, Y, 420, 340, "#ffffff", LINE, rx=16, sw=1.5)
text(RX + 16, Y + 22, "How each input reaches the pod", size=13, weight="700")
rows = [
    ("scripts", "git clone at the commit pinned on the run row — never 'latest'"),
    ("data", "downloaded from Storage at the data version pinned on the run"),
    ("secrets", "Secret Manager CSI mounts the profiles listed in the manifest as files; entrypoint exports AUTH_* — never in the Job YAML, never echoed"),
    ("what to run", "the manifest: tags (@p1, @TC-…), shard list, base URL, profiles"),
    ("results out", "karate-summary.json + junit + html + one file per call → Storage; then a 'done' message on Pub/Sub"),
    ("results in DB", "written by the WORKER after 'done', never by the pod"),
]
yy = Y + 46
for a, b in rows:
    text(RX + 16, yy, a, size=11, weight="700", font=MONO)
    # wrap b at ~52 chars
    words, line, lines = b.split(), "", []
    for wd_ in words:
        if len(line) + len(wd_) > 46: lines.append(line); line = wd_
        else: line = (line + " " + wd_).strip()
    lines.append(line)
    for j, ln in enumerate(lines):
        text(RX + 120, yy + j * 14, ln, size=10.5, fill=MUTED)
    yy += 14 * len(lines) + 10

# ---------------- bottom: karate-config, image, kubectl
BY_ = 480
code(40, BY_, 500, 200, "karate-config.js — reads its world from variables, nothing typed in", [
    'function fn() {',
    '  var env = karate.env;                 // qa | staging',
    '  var cfg = {',
    '    baseUrl: java.lang.System.getenv("BASE_URL"),',
    '    tokens:  { default:  getenv("AUTH_DEFAULT_BEARER"),',
    '               member_b: getenv("AUTH_MEMBER_B_BEARER") },',
    '    rps: Number(getenv("RATE_LIMIT_RPS") || 10)',
    '  };',
    '  karate.configure("logModifier", maskSecrets); // mask before log',
    '  return cfg; }'], size=10, lh=15.5)

code(580, BY_, 520, 200, "runner/Dockerfile — one image, pinned, scanned", [
    'FROM eclipse-temurin:21-jre@sha256:…',
    'COPY karate-1.5.x.jar /app/karate.jar   # checksum verified',
    'COPY entrypoint.sh /app/',
    'COPY log-masker/  /app/masker/',
    'USER 10001                              # non-root',
    'ENTRYPOINT ["/app/entrypoint.sh"]',
    '',
    '# the same image, with --mode validate, runs the',
    '# Phase 4 mock run against a Prism sidecar (R2)'], size=10, lh=15.5)

code(1140, BY_, 520, 200, "Watching and debugging a run", [
    '$ kubectl -n runners get jobs -l run_id=482',
    '$ kubectl -n runners logs job/run-482 -f',
    '$ kubectl -n runners describe pod run-482-2   # why did shard 2 die?',
    '',
    '# repeat run 482 exactly (same commit, data, env, tags):',
    '$ curl -X POST /api/v1/runs/482/rerun-failed',
    '',
    '# run it on your laptop against the mock instead:',
    '$ docker run --rm -e BASE_URL=http://prism:4010 \\',
    '    -v $PWD/workflows/claims:/work apitest-runner -t @p1'], size=10, lh=15.5)

# ---------------- rules strip
RY = 700
rect(40, RY, 1620, 60, GREEN_BG, GREEN, rx=12, sw=1.5)
text(56, RY + 20, "Five things to remember", size=12.5, weight="700", fill=GREEN_INK)
text(56, RY + 42, "1 same command as your laptop   2 the pod never talks to the database   3 secrets are mounted files, never env in YAML   4 only network / 5xx failures are retried, once, and marked flaky   5 a run = commit + data version + env + tags: repeatable forever", size=11.5, fill=GREEN_INK)

# ---------------- FAQ
FY = 780
rect(40, FY, 1620, H - FY - 30, "#ffffff", LINE, rx=12, sw=1.5)
text(56, FY + 20, "Questions developers ask", size=12.5, weight="700")
faq = [
    ("Why a Job and not a long-running pod?", "A run has a start and an end. A Job gives us parallelism, a deadline, a clean exit code and automatic cleanup for free."),
    ("Who decides the shards?", "the launcher: feature files grouped by expected duration (from the last run), max 8 groups. Open item — confirm the owner."),
    ("What if a spot node is taken away mid-shard?", "podFailurePolicy retries that pod only for node disruption; a test exit code is never retried."),
    ("Can I ssh into the pod?", "No. Read-only filesystem, non-root, no shell for the service account. Use the logs, the evidence, or run the image locally."),
    ("How do I add a new Karate version?", "bump the JAR in runner/, checksum, rebuild; the image digest changes; nothing else does."),
]
for i, (q, a) in enumerate(faq):
    text(56, FY + 44 + i * 20, q, size=11, weight="700")
    text(420, FY + 44 + i * 20, a, size=11, fill=MUTED)
w("</svg>")
open("out/knowledge-A-karate-on-gke.svg", "w").write("\n".join(out))
print("ok")
