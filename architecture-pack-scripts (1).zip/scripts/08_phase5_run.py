import os
os.makedirs('out', exist_ok=True)
#!/usr/bin/env python3
"""Phase 4 Build — whiteboard-style, one example flowing through."""
FONT = "Inter, 'Segoe UI', Helvetica, Arial, sans-serif"
MONO = "'JetBrains Mono', SFMono-Regular, Consolas, 'Liberation Mono', monospace"
INK, MUTED, LINE = "#1f2937", "#6b7280", "#9ca3af"
BLUE, BLUE_BG = "#2563eb", "#eff6ff"
GREEN, GREEN_BG, GREEN_INK = "#059669", "#ecfdf5", "#065f46"
AMBER, AMBER_BG, AMBER_INK = "#d97706", "#fffbeb", "#92400e"
RED, RED_BG, RED_INK = "#dc2626", "#fef2f2", "#991b1b"
GRAY_BG = "#f3f4f6"
W, H = 1700, 1010
out = []
def w(s): out.append(s)
def esc(s): return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
def text(x, y, s, size=12, anchor="start", weight="normal", fill=INK, style="", font=FONT):
    st = f" font-style='{style}'" if style else ""
    lead = len(s) - len(s.lstrip(' '))
    s = '\u00a0' * lead + s.lstrip(' ')
    w(f"<text x='{x}' y='{y}' font-size='{size}' text-anchor='{anchor}' font-weight='{weight}' fill='{fill}'{st} dominant-baseline='middle' font-family=\"{font}\">{esc(s)}</text>")
def rect(x, y, wd, h, fill, stroke, rx=14, sw=2, dash=""):
    d = f" stroke-dasharray='{dash}'" if dash else ""
    w(f"<rect x='{x}' y='{y}' width='{wd}' height='{h}' rx='{rx}' fill='{fill}' stroke='{stroke}' stroke-width='{sw}'{d}/>")
def arrow(pts, color=INK, width=2.4, dashed=False):
    p = " ".join(f"{x},{y}" for x, y in pts)
    m = {INK: "a", BLUE: "aB", AMBER: "aA", RED: "aR", GREEN: "aG"}[color]
    d = " stroke-dasharray='7 5'" if dashed else ""
    w(f"<polyline points='{p}' fill='none' stroke='{color}' stroke-width='{width}'{d} stroke-linejoin='round' marker-end='url(#{m})'/>")
def badge(x, y, n, color=INK, r=15):
    w(f"<circle cx='{x}' cy='{y}' r='{r}' fill='{color}'/>")
    text(x, y, str(n), size=15, anchor="middle", weight="700", fill="#ffffff")
def doc(x, y, wd, h, title, lines, stroke=INK, fill="#ffffff", size=10.5, lh=15):
    # a "document" shape with a folded corner
    f = 14
    w(f"<path d='M{x},{y+8} q0,-8 8,-8 h{wd-8-f} l{f},{f} v{h-f-8} q0,8 -8,8 h{-(wd-16)} q-8,0 -8,-8 z' fill='{fill}' stroke='{stroke}' stroke-width='2'/>")
    w(f"<path d='M{x+wd-f},{y} v{f} h{f}' fill='none' stroke='{stroke}' stroke-width='2'/>")
    text(x + 12, y + 20, title, size=11, weight="700", fill=stroke if stroke != INK else MUTED, font=MONO)
    for i, ln in enumerate(lines):
        text(x + 12, y + 42 + i * lh, ln, size=size, fill=INK, font=MONO)
def bubble(x, y, wd, h, title, lines, stroke, fill, ink, tail=None):
    rect(x, y, wd, h, fill, stroke, rx=16)
    if tail:  # small triangle pointing up to (tx, y)
        tx = tail
        w(f"<path d='M{tx-10},{y+1} L{tx},{y-14} L{tx+10},{y+1} z' fill='{fill}' stroke='{stroke}' stroke-width='2'/>")
        w(f"<line x1='{tx-9}' y1='{y+1}' x2='{tx+9}' y2='{y+1}' stroke='{fill}' stroke-width='3'/>")
    text(x + 16, y + 24, title, size=14, weight="700", fill=ink)
    for i, ln in enumerate(lines):
        text(x + 16, y + 48 + i * 18, ln, size=11.5, fill=ink)

w(f"<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 {W} {H}' role='img' aria-labelledby='t'>")
w("<title id='t'>Phase 5 Run — the whiteboard version</title>")
w("<defs>")
for mid, col in [("a", INK), ("aB", BLUE), ("aA", AMBER), ("aR", RED), ("aG", GREEN)]:
    w(f"<marker id='{mid}' viewBox='0 0 10 10' refX='9' refY='5' markerWidth='6' markerHeight='6' orient='auto-start-reverse'><path d='M0,0 L10,5 L0,10 z' fill='{col}'/></marker>")
w("</defs>")
rect(0, 0, W, H, "#ffffff", "none", rx=0, sw=0)


# ------------------------------------------------------------ title
text(40, 44, "Phase 5 · Run", size=30, weight="700")
text(40, 78, "Check the environment, start one Kubernetes Job that runs the Karate scripts against it, bring the results back. The runner is the only thing that ever calls the API under test.", size=15, fill=MUTED)
text(W - 40, 44, "release 1 · no AI", size=13, anchor="end", fill=LINE)
text(W - 40, 64, "who: a worker pod does steps 1, 2 and 4 · a runner Job does step 3 · the api pod only takes the request and serves results", size=13, anchor="end", fill=LINE)

# ------------------------------------------------------------ main flow
Y = 120
BH_ = 118
cols = [
    (40,   190, "Run requested", ["QE · CI after a deploy ·", "nightly · (R3) Jira webhook", "all → POST /runs → 202"], GREEN, GREEN_BG, None),
    (300,  250, "Pre-flight", ["is the environment ready?", "tokens, one safe call, freeze", "window, data, build version"], INK, "#ffffff", 1),
    (610,  250, "Launch one Job", ["write a manifest (what to run,", "at which commit) · create a", "Kubernetes Job, N pods = N shards"], INK, "#ffffff", 2),
    (920,  250, "The pod runs Karate", ["clone at the commit · secrets →", "variables · run by tags · mask ·", "upload evidence · say 'done'"], BLUE, BLUE_BG, 3),
    (1230, 250, "Collect results", ["one result row per case ·", "fingerprint failures · clean up", "what the tests created"], INK, "#ffffff", 4),
    (1540, 120, "Report", ["run record +", "evidence →", "Phase 6"], INK, GRAY_BG, None),
]
for x, wd, t, lines, col, fill, n in cols:
    rect(x, Y, wd, BH_, fill, col, rx=16, sw=2.5)
    tx = x + 18
    if n:
        badge(x + 26, Y + 26, n, col); tx = x + 50
    text(tx, Y + 26, t, size=16, weight="700", fill=col if col != INK else INK)
    for i, ln in enumerate(lines):
        text(x + 18, Y + 54 + i * 17, ln, size=12.5, fill=MUTED)
for i in range(len(cols) - 1):
    x1 = cols[i][0] + cols[i][1]; x2 = cols[i + 1][0]
    arrow([(x1 + 4, Y + BH_ / 2), (x2 - 4, Y + BH_ / 2)], width=3)
by = Y + BH_ + 10
w(f"<path d='M300,{by} v8 h560 v-8' fill='none' stroke='{MUTED}' stroke-width='1.5'/>")
text(580, by + 20, "worker pod (namespace app)", size=11, anchor="middle", fill=MUTED, style="italic")
w(f"<path d='M920,{by} v8 h250 v-8' fill='none' stroke='{BLUE}' stroke-width='1.5'/>")
text(1045, by + 20, "runner Job (namespace runners) — separate image: Java 21 + Karate", size=11, anchor="middle", fill=BLUE, style="italic")
w(f"<path d='M1230,{by} v8 h250 v-8' fill='none' stroke='{MUTED}' stroke-width='1.5'/>")
text(1355, by + 20, "worker pod, on the 'done' message", size=11, anchor="middle", fill=MUTED, style="italic")
text(1600, by + 24, "→ Phase 6", size=11, anchor="middle", weight="700", fill=INK)

# ------------------------------------------------------------ story strip
SY = 292
text(40, SY, "The same run, followed through every step — run #482, suite v3, QA environment, scope @p1", size=14, weight="700", fill=MUTED)
DY = SY + 20
DH = 160
doc(40, DY, 230, DH, "run row #482", [
    'workflow: claims',
    'environment: qa',
    'suite: v3',
    'script_commit: a1b2c3',
    'data_version: 7',
    'scope: @p1',
    'trigger: ci  (deploy 2.14.0)',
    'status: requested'], stroke=GREEN, size=10.2, lh=14)
doc(300, DY, 250, DH, "pre-flight checklist", [
    'freeze window     ✓ none now',
    'runs on qa        ✓ 1 of 3',
    'token: default    ✓',
    'token: member_b   ✓',
    'GET /members/1    ✓ 200',
    'data records      ✓ 41 reserved',
    'build_version     ✓ 2.14.0',
    '→ status: running'], size=10.2, lh=14)
doc(610, DY, 250, DH, "manifest.json  (→ the Job)", [
    '{ "run_id": 482,',
    '  "commit": "a1b2c3",',
    '  "data_version": 7,',
    '  "base_url": "https://qa…",',
    '  "profiles": ["default",',
    '               "member_b"],',
    '  "tags": "@p1",',
    '  "shards": 4 }'], size=10.2, lh=14)
doc(920, DY, 250, DH, "entrypoint.sh, pod 2 of 4", [
    'git clone --depth 1 @a1b2c3',
    'download data v7',
    'export AUTH_DEFAULT_… (mounted)',
    'java -jar karate.jar -t @p1',
    '   -T 4 features/  (shard 2)',
    'mask logs → upload evidence',
    'publish run.shard_done',
    'exit 0'], stroke=BLUE, size=10.2, lh=14)
doc(1230, DY, 250, DH, "result rows (one per case)", [
    'TC-CLM-0031  passed   212 ms',
    'TC-CLM-0032  failed   180 ms',
    '  fp: 7f3a…  (409 ≠ 200)',
    'TC-CLM-0040  flaky    1 retry',
    'TC-CLM-0055  blocked  no data',
    '…',
    'cleanup: 12 created, 12 deleted',
    '→ status: completed'], stroke=GREEN, size=10.2, lh=14)
doc(1540, DY, 120, DH, "report", [
    '38 passed',
    ' 2 failed',
    ' 1 flaky',
    ' 1 blocked',
    '',
    'evidence:',
    'runs/482/',
    '(masked)'], size=10.2, lh=14)
for x1, x2 in [(270, 300), (550, 610), (860, 920), (1170, 1230), (1480, 1540)]:
    arrow([(x1 + 4, DY + DH / 2), (x2 - 4, DY + DH / 2)], color=INK, width=1.6)

# ------------------------------------------------------------ three callouts
CY = 522
bubble(40, CY, 500, 186, "Pre-flight red?  Stop before spending a Job.", [
    "Any red check → status env_not_ready. The run row keeps",
    "which check failed. ONE message to the QE and the",
    "environment owner — never one per case.",
    "The QE fixes the environment and starts a new run.",
    "Too many runs already? → wait in a queue, position shown.",
    "Cancel at any time: the Job is deleted, reserved data is",
    "released, the run is marked cancelled — never half-done.",
], RED, RED_BG, RED_INK)

bubble(580, CY, 520, 186, "Flaky vs failed — what gets retried", [
    "A scenario whose failure looks like the NETWORK (timeout,",
    "connection reset, 5xx) is retried once, inside the pod.",
    "Passes on the retry → recorded as 'flaky', not 'passed'.",
    "An ASSERTION failure (wrong status, wrong field) is never",
    "retried: it is the answer. The Job itself never retries.",
    "",
    "Same failure text, ids stripped → same fingerprint → Phase 6.",
], INK, "#ffffff", INK)

bubble(1140, CY, 520, 186, "Why the runner is walled off", [
    "It never talks to the database: a manifest in, files out.",
    "Secrets are mounted from Secret Manager at pod start and",
    "become AUTH_* variables — never in the Job spec, never logged.",
    "Its network reaches the test environment, Storage, Pub/Sub",
    "and Git. Nothing else. Production is unreachable by rule.",
    "Masking happens inside the pod, before anything is written.",
], BLUE, BLUE_BG, "#1e40af")

# ------------------------------------------------------------ two tables
TY = 738
rect(40, TY, 800, 196, "#ffffff", LINE, rx=14, sw=1.5)
text(56, TY + 24, "The Job spec — the lines that matter (deploy/helm/runners/job.yaml, filled in by the launcher)", size=13, weight="700")
job = [
    ("image", "apitest-runner@sha256:…  — pinned by digest, scanned in CI"),
    ("parallelism / completions", "= number of shards (max 8); each pod takes JOB_COMPLETION_INDEX"),
    ("backoffLimit: 0 + podFailurePolicy", "never retry on a test exit code; retry ONLY if the node was preempted (spot)"),
    ("activeDeadlineSeconds", "3600 by default (team setting); over it → run.failed"),
    ("serviceAccount · nodeSelector", "runner-sa (may read target secrets, nothing else) · pool=runners, spot allowed"),
    ("volumes", "Secret Manager CSI mount for the profiles in the manifest — no env: secrets"),
]
for i, (a, b) in enumerate(job):
    text(56, TY + 50 + i * 24, a, size=11.5, weight="700", font=MONO)
    text(345, TY + 50 + i * 24, b, size=11.2, fill=MUTED)

rect(870, TY, 790, 196, "#ffffff", LINE, rx=14, sw=1.5)
text(886, TY + 24, "Evidence — what the pod writes to gs://evidence/{team}/{run_id}/, and what is masked first", size=13, weight="700")
ev = [
    ("karate-summary.json", "the results the worker reads back; @TC- tag → test case"),
    ("junit/*.xml · html/", "standard reports, for CI and for people"),
    ("calls/{case_id}/{step}.json", "every request and response — this is what a QE opens"),
    ("logs/pod-{n}.log", "the pod's own log"),
    ("masked before writing", "Authorization · Cookie · X-Api-Key · every field marked sensitive in the field catalog"),
    ("kept", "full evidence 90 days · summaries 2 years · served via short-lived signed links"),
]
for i, (a, b) in enumerate(ev):
    text(886, TY + 50 + i * 24, a, size=11.5, weight="700", font=MONO)
    text(1160, TY + 50 + i * 24, b, size=11.5, fill=MUTED)

# footer
text(40, H - 42, "Done when:", size=12.5, weight="700", fill=GREEN_INK)
text(130, H - 42, "run on QA → Job starts at the pinned commit, results per case, a canary secret and a sensitive field never appear in evidence, created data is cleaned up · a dead environment → env_not_ready, one message · the run row alone can start the identical run again.", size=11.5, fill=GREEN_INK)
text(40, H - 18, "Remember: a run is a Git commit + a data version + an environment + a tag expression. Pin all four and any run can be repeated exactly, next week or next year.", size=12, fill=MUTED, style="italic")

w("</svg>")
open("out/architecture-5-run.svg", "w").write("\n".join(out))
print("ok")
