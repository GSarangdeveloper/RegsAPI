import os
os.makedirs('out', exist_ok=True)
#!/usr/bin/env python3
"""Phase 4 Build — whiteboard-style, one example flowing through."""
FONT = "Inter, 'Segoe UI', Helvetica, Arial, sans-serif"
MONO = "'JetBrains Mono', SFMono-Regular, Consolas, 'Liberation Mono', monospace"
INK, MUTED, LINE = "#1f2937", "#6b7280", "#9ca3af"
BLUE, BLUE_BG = "#2563eb", "#eff6ff"
GREEN, GREEN_BG, GREEN_INK = "#059669", "#ecfdf5", "#065f46"
AMBER, AMBER_BG, AMBER_INK = "#d97706", "#fffbeb", "#92400e"
RED, RED_BG, RED_INK = "#dc2626", "#fef2f2", "#991b1b"
GRAY_BG = "#f3f4f6"
W, H = 1700, 1010
out = []
def w(s): out.append(s)
def esc(s): return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
def text(x, y, s, size=12, anchor="start", weight="normal", fill=INK, style="", font=FONT):
    st = f" font-style='{style}'" if style else ""
    lead = len(s) - len(s.lstrip(' '))
    s = '\u00a0' * lead + s.lstrip(' ')
    w(f"<text x='{x}' y='{y}' font-size='{size}' text-anchor='{anchor}' font-weight='{weight}' fill='{fill}'{st} dominant-baseline='middle' font-family=\"{font}\">{esc(s)}</text>")
def rect(x, y, wd, h, fill, stroke, rx=14, sw=2, dash=""):
    d = f" stroke-dasharray='{dash}'" if dash else ""
    w(f"<rect x='{x}' y='{y}' width='{wd}' height='{h}' rx='{rx}' fill='{fill}' stroke='{stroke}' stroke-width='{sw}'{d}/>")
def arrow(pts, color=INK, width=2.4, dashed=False):
    p = " ".join(f"{x},{y}" for x, y in pts)
    m = {INK: "a", BLUE: "aB", AMBER: "aA", RED: "aR", GREEN: "aG"}[color]
    d = " stroke-dasharray='7 5'" if dashed else ""
    w(f"<polyline points='{p}' fill='none' stroke='{color}' stroke-width='{width}'{d} stroke-linejoin='round' marker-end='url(#{m})'/>")
def badge(x, y, n, color=INK, r=15):
    w(f"<circle cx='{x}' cy='{y}' r='{r}' fill='{color}'/>")
    text(x, y, str(n), size=15, anchor="middle", weight="700", fill="#ffffff")
def doc(x, y, wd, h, title, lines, stroke=INK, fill="#ffffff", size=10.5, lh=15):
    # a "document" shape with a folded corner
    f = 14
    w(f"<path d='M{x},{y+8} q0,-8 8,-8 h{wd-8-f} l{f},{f} v{h-f-8} q0,8 -8,8 h{-(wd-16)} q-8,0 -8,-8 z' fill='{fill}' stroke='{stroke}' stroke-width='2'/>")
    w(f"<path d='M{x+wd-f},{y} v{f} h{f}' fill='none' stroke='{stroke}' stroke-width='2'/>")
    text(x + 12, y + 20, title, size=11, weight="700", fill=stroke if stroke != INK else MUTED, font=MONO)
    for i, ln in enumerate(lines):
        text(x + 12, y + 42 + i * lh, ln, size=size, fill=INK, font=MONO)
def bubble(x, y, wd, h, title, lines, stroke, fill, ink, tail=None):
    rect(x, y, wd, h, fill, stroke, rx=16)
    if tail:  # small triangle pointing up to (tx, y)
        tx = tail
        w(f"<path d='M{tx-10},{y+1} L{tx},{y-14} L{tx+10},{y+1} z' fill='{fill}' stroke='{stroke}' stroke-width='2'/>")
        w(f"<line x1='{tx-9}' y1='{y+1}' x2='{tx+9}' y2='{y+1}' stroke='{fill}' stroke-width='3'/>")
    text(x + 16, y + 24, title, size=14, weight="700", fill=ink)
    for i, ln in enumerate(lines):
        text(x + 16, y + 48 + i * 18, ln, size=11.5, fill=ink)

w(f"<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 {W} {H}' role='img' aria-labelledby='t'>")
w("<title id='t'>Phase 2 Understand — the whiteboard version</title>")
w("<defs>")
for mid, col in [("a", INK), ("aB", BLUE), ("aA", AMBER), ("aR", RED), ("aG", GREEN), ("aP", "#7c3aed")]:
    w(f"<marker id='{mid}' viewBox='0 0 10 10' refX='9' refY='5' markerWidth='6' markerHeight='6' orient='auto-start-reverse'><path d='M0,0 L10,5 L0,10 z' fill='{col}'/></marker>")
w("</defs>")
rect(0, 0, W, H, "#ffffff", "none", rx=0, sw=0)



PURPLE, PURPLE_BG, PURPLE_INK = "#7c3aed", "#f5f3ff", "#5b21b6"
def arrow(pts, color=INK, width=2.4, dashed=False):
    p = " ".join(f"{x},{y}" for x, y in pts)
    m = {INK: "a", BLUE: "aB", AMBER: "aA", RED: "aR", GREEN: "aG", PURPLE: "aP"}[color]
    d = " stroke-dasharray='7 5'" if dashed else ""
    w(f"<polyline points='{p}' fill='none' stroke='{color}' stroke-width='{width}'{d} stroke-linejoin='round' marker-end='url(#{m})'/>")
def steps_row(Y, cols, BH_=118):
    for x, wd, t, lines, col, fill, n in cols:
        rect(x, Y, wd, BH_, fill, col, rx=16, sw=2.5)
        tx = x + 18
        if n:
            badge(x + 26, Y + 26, n, col); tx = x + 50
        text(tx, Y + 26, t, size=16, weight="700", fill=col if col != INK else INK)
        for i, ln in enumerate(lines):
            text(x + 18, Y + 54 + i * 17, ln, size=12.5, fill=MUTED)
    for i in range(len(cols) - 1):
        x1 = cols[i][0] + cols[i][1]; x2 = cols[i + 1][0]
        arrow([(x1 + 4, Y + BH_ / 2), (x2 - 4, Y + BH_ / 2)], width=3)
def bracket(x1, x2, y, label, col=MUTED):
    w(f"<path d='M{x1},{y} v8 h{x2-x1} v-8' fill='none' stroke='{col}' stroke-width='1.5'/>")
    text((x1 + x2) / 2, y + 20, label, size=11, anchor="middle", fill=col, style="italic")
def table(x, y, wd, h, title, rows, kx=270, size=11.5):
    rect(x, y, wd, h, "#ffffff", LINE, rx=14, sw=1.5)
    text(x + 16, y + 24, title, size=13, weight="700")
    for i, (a, b) in enumerate(rows):
        text(x + 16, y + 50 + i * 24, a, size=size, weight="700", font=MONO)
        text(x + kx, y + 50 + i * 24, b, size=size, fill=MUTED)
def footer(done, remember):
    text(40, H - 42, "Done when:", size=12.5, weight="700", fill=GREEN_INK)
    text(130, H - 42, done, size=11.5, fill=GREEN_INK)
    text(40, H - 18, remember, size=12, fill=MUTED, style="italic")

text(40, 44, "Phase 2 · Understand", size=30, weight="700")
text(40, 78, "Read the accepted spec and build the API model: every endpoint, every field, every dependency, and the full checklist of what tests must cover. Automatic, deterministic, no AI in release 1.", size=15, fill=MUTED)
text(W - 40, 44, "release 1 · no user action, no AI", size=13, anchor="end", fill=LINE)
text(W - 40, 64, "who: a worker pod does 1–4 the moment a spec is accepted · the api pod shows the result · (R2) ai-worker proposes rules from Jira stories", size=13, anchor="end", fill=LINE)

Y = 120
steps_row(Y, [
    (40,   190, "Spec accepted", ["the cleaned-up", "OpenAPI JSON from", "Phase 1"], GREEN, GREEN_BG, None),
    (300,  250, "List the endpoints", ["one row per operation: method,", "path, stable id, documented", "responses, safe or mutating"], INK, "#ffffff", 1),
    (610,  250, "Catalog the fields", ["flatten every request and", "response schema: type, required,", "limits, and SENSITIVE yes/no"], INK, "#ffffff", 2),
    (920,  250, "Find dependencies", ["explicit links in the spec, plus", "guesses: POST returns an id that", "GET /x/{id} needs → an edge"], INK, "#ffffff", 3),
    (1230, 250, "Build the checklist", ["the coverage universe: every", "endpoint, code, field, limit,", "edge and security check"], INK, "#ffffff", 4),
    (1540, 120, "API model", ["confirmed →", "Phase 3 writes", "the tests"], INK, GRAY_BG, None),
])
text(265, Y - 14, "starts by itself when", size=10.5, anchor="middle", weight="600", fill=GREEN_INK)
text(265, Y - 1, "Phase 1 says 'accepted'", size=10.5, anchor="middle", weight="600", fill=GREEN_INK)
bracket(300, 1480, Y + 128, "worker pod · four pure functions over the spec JSON, rows out · re-runs on every new spec version; the model is versioned with the spec")

SY = 292
text(40, SY, "One spec followed through every step — claims-api v3 (5 operations)", size=14, weight="700", fill=MUTED)
DY = SY + 20; DH = 160
doc(40, DY, 230, DH, "normalized spec (JSON)", [
    'paths:',
    ' /claims        POST',
    ' /claims/{id}   GET PUT',
    '                DELETE',
    ' /claims/{id}/',
    '   adjudicate   POST',
    'schemas: Claim, Member',
    '(2 lint warnings)'], stroke=GREEN, size=10.2, lh=14)
doc(300, DY, 250, DH, "target rows (5)", [
    'createClaim     POST mutating',
    'getClaim        GET  safe',
    'updateClaim     PUT  mutating',
    'deleteClaim     DEL  mutating',
    'adjudicateClaim POST mutating',
    '',
    'responses per op, e.g.',
    'createClaim: 201 400 401 404'], size=10.2, lh=14)
doc(610, DY, 250, DH, "field rows (18), e.g. createClaim", [
    'req  memberId  string  required',
    '                       SENSITIVE',
    'req  amount    number  min 0',
    'req  member.dob date  SENSITIVE',
    'req  planCode  enum   3 values',
    'resp claimId   string',
    'resp status    enum   4 values',
    '…'], size=10.2, lh=14)
doc(920, DY, 250, DH, "dependency edges (3)", [
    'createClaim → getClaim',
    '  claimId  explicit  1.0',
    'createClaim → updateClaim',
    '  claimId  guessed   0.9',
    'createClaim → adjudicateClaim',
    '  claimId  guessed   0.8',
    '',
    '(QE can confirm / reject)'], size=10.2, lh=14)
doc(1230, DY, 250, DH, "coverage universe", [
    'structural    5 ops',
    'response_code 14 codes',
    'schema        18 fields',
    'boundary       6 constrained',
    'dependency     3 edges',
    'security       4 protected ops',
    'business_rule  0  (R2: rules)',
    '= what Phase 3 must cover'], stroke=GREEN, size=10.2, lh=14)
doc(1540, DY, 120, DH, "api_model", [
    'spec v3',
    'status:',
    'confirmed',
    '',
    '(R1: no',
    ' review',
    ' needed)'], size=10.2, lh=14)
for x1, x2 in [(270, 300), (550, 610), (860, 920), (1170, 1230), (1480, 1540)]:
    arrow([(x1 + 4, DY + DH / 2), (x2 - 4, DY + DH / 2)], color=INK, width=1.6)

CY = 522
bubble(40, CY, 500, 186, "Sensitive fields are decided HERE — once", [
    "Step 2 marks a field sensitive from its name and format",
    "(dob, ssn, email, memberId, address …). A QE can add or",
    "remove the flag. From then on, everywhere: the runner masks",
    "it in evidence, the log scrubber drops it, and no AI prompt",
    "may ever contain its value. Get this list right early — it is",
    "the one thing in this phase that a mistake makes expensive.",
], RED, RED_BG, RED_INK)
bubble(580, CY, 520, 186, "Guessing dependencies — the rules, and the QE's veto", [
    "explicit (confidence 1.0): the spec links them (x-depends, examples)",
    "guessed 0.9: POST /x returns id; GET|PUT|DELETE /x/{id} takes id",
    "guessed 0.8: same field name in a response and another path/body",
    "guessed 0.6: same resource name in the path, no shared field",
    "Only edges ≥ 0.8 or confirmed by a QE count for coverage.",
    "The list of rules is a starting point — agree it with the QE lead.",
], INK, "#ffffff", INK)
bubble(1140, CY, 520, 186, "Release 2: business rules from Jira stories", [
    "A QE attaches stories. ai-worker sees ONLY the masked story",
    "text, the endpoint names and the field names it mentions.",
    "It must return rules with the exact source sentence and a",
    "confidence; anything else is rejected before it is saved.",
    "The QE confirms, edits or rejects each rule (a gate); only",
    "confirmed rules reach Phase 3. Without stories, no gate.",
], BLUE, BLUE_BG, "#1e40af")

TY = 738
table(40, TY, 800, 196, "The four tables this phase writes (all keyed by spec_version_id — a new spec version = new rows)", [
    ("target", "one operation: target_key, method, path, safety, auth_scopes, responses, request_schema"),
    ("field", "one field: target, direction req|resp, path a.b[].c, type, required, min/max, enum, sensitive"),
    ("dependency_edge", "from_target → to_target, field_mapping, source explicit|heuristic|ai, confidence, status"),
    ("business_rule  (R2)", "rule_text, applies_to, source_story, source_sentence, confidence, status proposed|confirmed"),
    ("read by", "Phase 3 (rule engine, coverage universe) · Phase 5 (masking uses field.sensitive)"),
    ("shown by", "GET /spec-versions/{v}/targets · …/fields · …/dependency-edges · …/coverage-universe"),
], kx=230)
table(870, TY, 790, 196, "The stable endpoint id (target_key) — why it matters and how it is made", [
    ("rule", "operationId if present and unique; otherwise METHOD + path with every parameter as {}"),
    ("example", "createClaim  ·  or  'PUT /claims/{}' when the spec has no operationId"),
    ("used by", "every test case (coverage_targets), every script (@endpoint tag), every result, every fingerprint"),
    ("on re-upload", "same key = same endpoint: approved cases carry over; a changed schema puts them back to draft"),
    ("rename detection", "different key, identical request + response schema → proposed as a rename, QE confirms"),
    ("never", "changes once a suite is approved — that is what makes history and diffs possible"),
], kx=180)
footer("open a spec version and see every endpoint with id, safety and responses · every field with type, limits and the sensitive flag · edges with confidence, confirm or reject one · the universe per dimension.",
       "Remember: same spec in, same model out — Discover is a function, not a judgement. The only human decisions here are the sensitive flags and the guessed edges.")
w("</svg>")
open("out/architecture-2-understand.svg", "w").write("\n".join(out))
print("ok")
