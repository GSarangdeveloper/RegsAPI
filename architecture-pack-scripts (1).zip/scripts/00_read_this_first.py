import os
os.makedirs('out', exist_ok=True)
#!/usr/bin/env python3
"""Phase 1 Onboard — developer architecture diagram (SVG)."""
FONT = "Inter, 'Segoe UI', Helvetica, Arial, sans-serif"
MONO = "'JetBrains Mono', SFMono-Regular, Consolas, 'Liberation Mono', monospace"
INK, MUTED, LINE = "#1f2937", "#6b7280", "#9ca3af"
BLUE, BLUE_BG, BLUE_INK = "#2563eb", "#eff6ff", "#1e40af"
GREEN, GREEN_BG, GREEN_INK = "#059669", "#ecfdf5", "#065f46"
AMBER, AMBER_BG, AMBER_INK = "#d97706", "#fffbeb", "#92400e"
RED, RED_BG, RED_INK = "#dc2626", "#fef2f2", "#991b1b"
PURPLE, PURPLE_BG, PURPLE_INK = "#7c3aed", "#f5f3ff", "#5b21b6"
GRAY_BG = "#f3f4f6"
W, H = 1900, 820
out = []
def w(s): out.append(s)
def esc(s): return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
def text(x, y, s, size=10, anchor="start", weight="normal", fill=INK, style="", font=FONT):
    st = f" font-style='{style}'" if style else ""
    w(f"<text x='{x}' y='{y}' font-size='{size}' text-anchor='{anchor}' font-weight='{weight}' fill='{fill}'{st} dominant-baseline='middle' font-family=\"{font}\">{esc(s)}</text>")
def rect(x, y, wd, h, fill, stroke, rx=8, sw=1.5, dash=""):
    d = f" stroke-dasharray='{dash}'" if dash else ""
    w(f"<rect x='{x}' y='{y}' width='{wd}' height='{h}' rx='{rx}' fill='{fill}' stroke='{stroke}' stroke-width='{sw}'{d}/>")
def arrow(pts, color=INK, dashed=False, width=1.6, both=False):
    p = " ".join(f"{x},{y}" for x, y in pts)
    m = {INK: "a", BLUE: "aBlue", AMBER: "aAmber", RED: "aRed", GREEN: "aGreen", PURPLE: "aPurple"}[color]
    d = " stroke-dasharray='5 4'" if dashed else ""
    ms = f" marker-start='url(#{m})'" if both else ""
    w(f"<polyline points='{p}' fill='none' stroke='{color}' stroke-width='{width}'{d} marker-end='url(#{m})'{ms}/>")
def badge(x, y, n, color=INK, r=10):
    w(f"<circle cx='{x}' cy='{y}' r='{r}' fill='{color}'/>")
    text(x, y, str(n), size=10, anchor="middle", weight="700", fill="#ffffff")
def card(x, y, wd, h, title, lines, fill="#ffffff", stroke=INK, tink=INK, mono_title=False, size=9.5, lh=13, num=None, numcol=INK, tag=None, tagcol=MUTED):
    rect(x, y, wd, h, fill, stroke)
    tx = x + 12
    if num is not None:
        badge(x + 16, y + 16, num, numcol); tx = x + 32
    text(tx, y + 16, title, size=11.5, weight="700", fill=tink, font=MONO if mono_title else FONT)
    if tag:
        tw_ = len(tag) * 5.2 + 12
        rect(x + wd - 10 - tw_, y + 7, tw_, 18, "#ffffff", tagcol, rx=9, sw=1)
        text(x + wd - 10 - tw_ / 2, y + 16, tag, size=9, anchor="middle", weight="600", fill=tagcol)
    for i, ln in enumerate(lines):
        mono = ln.startswith("`")
        text(x + 12, y + 36 + i * lh, ln.strip("`"), size=size, fill=MUTED if not mono else INK, font=MONO if mono else FONT)

w(f"<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 {W} {H}' role='img' aria-labelledby='t'>")
w("<title id='t'>Read this first — architecture for developers</title>")
w("<defs>")
for mid, col in [("a", INK), ("aBlue", BLUE), ("aAmber", AMBER), ("aRed", RED), ("aGreen", GREEN), ("aPurple", PURPLE)]:
    w(f"<marker id='{mid}' viewBox='0 0 10 10' refX='9' refY='5' markerWidth='7' markerHeight='7' orient='auto-start-reverse'><path d='M0,0 L10,5 L0,10 z' fill='{col}'/></marker>")
w("</defs>")
rect(0, 0, W, H, "#ffffff", "none", rx=0)







R3, R3_BG, R3_INK = PURPLE, PURPLE_BG, PURPLE_INK
def box(x, y, wd, h, title, sub, lines=(), stroke=INK, fill="#ffffff", tink=None, tag=None, tagcol=None, size=9, lh=12.5, tsize=12):
    rect(x, y, wd, h, fill, stroke, rx=10)
    text(x + 14, y + 18, title, size=tsize, weight="700", fill=tink or (stroke if stroke != INK else INK))
    if tag:
        tw_ = len(tag) * 5.4 + 12
        rect(x + wd - 12 - tw_, y + 9, tw_, 18, "#ffffff", tagcol or stroke, rx=9, sw=1)
        text(x + wd - 12 - tw_ / 2, y + 18, tag, size=9, anchor="middle", weight="700", fill=tagcol or stroke)
    if sub: text(x + 14, y + 34, sub, size=9, fill=MUTED, style="italic")
    for i, ln in enumerate(lines):
        text(x + 14, y + (50 if sub else 36) + i * lh, ln, size=size, fill=MUTED)


R3, R3_BG, R3_INK = PURPLE, PURPLE_BG, PURPLE_INK
text(24, 40, "AI API Testing Platform — Architecture pack", size=26, weight="700")
text(24, 68, "Read this first: what is in the pack, how every page is laid out, and what the colours and tags mean. You do not need the technical specification to use these pages.", size=12, fill=MUTED)
text(W - 24, 40, "September 2026 · v1", size=10.5, anchor="end", fill=LINE)

# contents
rect(40, 96, 560, 420, "#ffffff", LINE, rx=10)
text(54, 116, "What is in the pack (in reading order)", size=13, weight="700")
toc = [
    ("0", "The whole system on one page", "who, where the code runs, what it uses, the six rules"),
    ("—", "End-to-end process flow", "24 steps, 5 human gates, 5 loops, 1 stop, with release tags"),
    ("1", "Onboard", "spec upload, credentials, smoke check, readiness"),
    ("2", "Understand", "Discover: the API model · R2 rules from Jira stories"),
    ("3", "Design", "rule engine, coverage, review queue, approval · do we need AI?"),
    ("4", "Build", "test data, templates, checks, Git"),
    ("4a", "From test case to .feature", "one worked example, with and without AI"),
    ("5", "Run", "pre-flight, the Kubernetes Job, inside the runner pod, results"),
    ("6", "Close the loop", "report · R3 triage, defect review, Jira, rerun on fix"),
    ("A", "How Karate runs on GKE", "same command as your laptop, inside a Job"),
    ("B", "How the AI generates test cases", "one narrow question, JSON answer, code checks it"),
    ("C", "How test data is made", "three sources; AI only reads a CSV's headers"),
    ("", "Appendix", "the Python script behind every page, so it can be edited"),
]
for i, (n, t, d) in enumerate(toc):
    y = 140 + i * 25
    text(54, y, n, size=10.5, weight="700", fill=MUTED, font=MONO)
    text(84, y, t, size=10.5, weight="700")
    text(300, y, d, size=9.5, fill=MUTED)

# layout of a phase page (mini map)
rect(620, 96, 700, 420, "#ffffff", LINE, rx=10)
text(634, 116, "How every phase page is laid out", size=13, weight="700")
mx, my = 640, 134
sc = 0.22
def mini(x, y, wd, h, label, fill="#f9fafb", stroke=LINE):
    rect(mx + x * sc, my + y * sc, wd * sc, h * sc, fill, stroke, rx=4, sw=1)
    text(mx + x * sc + wd * sc / 2, my + y * sc + h * sc / 2, label, size=7.2, anchor="middle", weight="700", fill=INK)
mini(0, 0, 1900, 40, "title · what the user does · what the platform does · release tags", "#ffffff", "none")
mini(0, 60, 1740, 130, "A  the story: 4–5 big steps, left to right, who does each", "#ffffff", INK)
mini(0, 220, 1740, 180, "B  the same example followed through every step (small documents)", "#ffffff", INK)
mini(0, 430, 560, 200, "C  callout", AMBER_BG, AMBER)
mini(590, 430, 560, 200, "C  callout", GREEN_BG, GREEN)
mini(1180, 430, 560, 200, "C  callout", BLUE_BG, BLUE)
mini(0, 660, 860, 200, "D  a table you will build from", GRAY_BG, LINE)
mini(880, 660, 860, 200, "D  a table you will build from", GRAY_BG, LINE)
mini(0, 890, 1740, 60, "E  done when · remember", GREEN_BG, GREEN)
notes = [
    "A is the whole phase in one sentence; brackets under the steps say which pod does what.",
    "B is the same real example at every step — read it once and you understand the phase.",
    "C answers the three questions people ask. D is what you will actually write. E is the exit test.",
    "The process flow and overview pages use lanes and rows instead; their legends are on the page.",
]
for i, ln in enumerate(notes):
    text(634, 378 + i * 14.5, ln, size=9.2, fill=MUTED)

# colours & tags
rect(1340, 96, 520, 420, "#ffffff", LINE, rx=10)
text(1354, 116, "Colours, tags and shapes", size=13, weight="700")
leg = [
    ("#ffffff", INK, "white box", "code that runs without AI — release 1 unless tagged"),
    (BLUE_BG, BLUE, "blue box", "AI is involved — always release 2 or later; AI only drafts"),
    (GREEN_BG, GREEN, "green box", "a human gate: a person approves, edits, rejects or dismisses"),
    (R3_BG, R3, "purple box", "release 3: triage, defects, reruns, dashboards"),
    (RED_BG, RED, "red box", "secrets, or a stop"),
    (AMBER_BG, AMBER, "amber", "a loop, or a status waiting for a person"),
    (GRAY_BG, LINE, "grey box", "cross-cutting: runs on every request, or deployment notes"),
]
for i, (f, st, a, b) in enumerate(leg):
    y = 138 + i * 22
    rect(1354, y - 8, 22, 16, f, st, rx=4, sw=1.2)
    text(1384, y, a, size=9.5, weight="700")
    text(1470, y, b, size=9, fill=MUTED)
y = 138 + 7 * 22 + 4
for i, (tok, col, d) in enumerate([("MVP", MUTED, "release 1"), ("R2", BLUE, "release 2"), ("R3", R3, "release 3")]):
    x = 1354 + i * 120
    rect(x, y - 8, 30, 16, "#ffffff", col, rx=4, sw=1)
    text(x + 15, y, tok, size=8.5, anchor="middle", weight="700", fill=col, font=MONO)
    text(x + 38, y, d, size=9, fill=MUTED)
text(1354, y + 24, "a tag on a box = the release that box ships in; pages say 'build the white parts first'", size=9, fill=MUTED, style="italic")
text(1354, y + 40, "◆ diamond = a human gate   ● dot = start / end   dashed box = optional branch", size=9, fill=MUTED)

# how to use / rules of the pack
rect(40, 536, 900, 250, "#ffffff", LINE, rx=10)
text(54, 556, "How to use these pages", size=13, weight="700")
use = [
    "**If you are new**  read page 0, then the process flow, then the 'step by step' panel of each phase. One hour.",
    "**If you are building a phase**  read that page's 'build order' and 'done when' panels; the file paths tell you where code goes.",
    "**If a word is unclear**  every page defines its own words in the last panel; page 0 explains the whole system's words.",
    "**If something is missing**  a few details are not decided anywhere yet; they are marked on the page ('agree with the QE lead',",
    "   'confirm with Advik'). Do not guess silently — raise them.",
    "**If a page is wrong**  each page is generated by a small Python script (appendix). Change the text in the script, run it, and",
    "   the SVG and PNG are regenerated. Do not edit the SVG by hand.",
    "**What this pack is not**  it is not the API contract (that is the generated OpenAPI file) and not the database schema (that is",
    "   in the migrations). Where this pack and the code disagree, the code wins and the page must be fixed.",
]
for i, ln in enumerate(use):
    if ln.startswith("**"):
        term, rest = ln[2:].split("**  ", 1)
        text(54, 580 + i * 21, term, size=10, weight="700")
        text(54 + len(term) * 6.1 + 8, 580 + i * 21, rest, size=9.5, fill=MUTED)
    else:
        text(54, 580 + i * 21, ln.strip(), size=9.5, fill=MUTED)

rect(960, 536, 900, 250, GREEN_BG, GREEN, rx=10)
text(974, 556, "The six rules, repeated once here so nobody has to look them up", size=13, weight="700", fill=GREEN_INK)
rules = [
    "1  Deterministic first. Code writes the tests from the spec's facts. AI is asked only for what code cannot know, and it only drafts.",
    "2  A person decides at every gate. Readiness, rules, test cases, data, defects. The platform never files a defect by itself.",
    "3  One test case JSON is the truth. Scripts, Zephyr entries, reports and reruns are all derived from it and reference it by case_id.",
    "4  Secrets never enter the database, logs, Git, prompts or evidence. The only thing stored is the Secret Manager address.",
    "5  Everything is immutable and versioned. Spec versions, suites and runs are never edited; a change is a new version.",
    "6  Every table has team_id and a row-level security policy. The code filters by team; Postgres enforces it a second time.",
]
for i, ln in enumerate(rules):
    text(974, 582 + i * 26, ln, size=10, fill=GREEN_INK)
text(974, 760, "One image, one core, one database; a folder per phase; a pod group per kind of work. Split into services only if a module later needs its own team, database or release cadence.", size=9.5, fill=GREEN_INK, style="italic")

w("</svg>")
open("out/architecture-00-read-this-first.svg", "w").write("\n".join(out))
print("ok")
