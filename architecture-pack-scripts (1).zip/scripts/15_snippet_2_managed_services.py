import os
os.makedirs('out', exist_ok=True)
#!/usr/bin/env python3
"""Phase 4 Build — whiteboard-style, one example flowing through."""
FONT = "Inter, 'Segoe UI', Helvetica, Arial, sans-serif"
MONO = "'JetBrains Mono', SFMono-Regular, Consolas, 'Liberation Mono', monospace"
INK, MUTED, LINE = "#1f2937", "#6b7280", "#9ca3af"
BLUE, BLUE_BG = "#2563eb", "#eff6ff"
GREEN, GREEN_BG, GREEN_INK = "#059669", "#ecfdf5", "#065f46"
AMBER, AMBER_BG, AMBER_INK = "#d97706", "#fffbeb", "#92400e"
RED, RED_BG, RED_INK = "#dc2626", "#fef2f2", "#991b1b"
GRAY_BG = "#f3f4f6"
W, H = 900, 420
out = []
def w(s): out.append(s)
def esc(s): return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
def text(x, y, s, size=12, anchor="start", weight="normal", fill=INK, style="", font=FONT):
    st = f" font-style='{style}'" if style else ""
    lead = len(s) - len(s.lstrip(' '))
    s = '\u00a0' * lead + s.lstrip(' ')
    w(f"<text x='{x}' y='{y}' font-size='{size}' text-anchor='{anchor}' font-weight='{weight}' fill='{fill}'{st} dominant-baseline='middle' font-family=\"{font}\">{esc(s)}</text>")
def rect(x, y, wd, h, fill, stroke, rx=14, sw=2, dash=""):
    d = f" stroke-dasharray='{dash}'" if dash else ""
    w(f"<rect x='{x}' y='{y}' width='{wd}' height='{h}' rx='{rx}' fill='{fill}' stroke='{stroke}' stroke-width='{sw}'{d}/>")
def arrow(pts, color=INK, width=2.4, dashed=False):
    p = " ".join(f"{x},{y}" for x, y in pts)
    m = {INK: "a", BLUE: "aB", AMBER: "aA", RED: "aR", GREEN: "aG"}[color]
    d = " stroke-dasharray='7 5'" if dashed else ""
    w(f"<polyline points='{p}' fill='none' stroke='{color}' stroke-width='{width}'{d} stroke-linejoin='round' marker-end='url(#{m})'/>")
def badge(x, y, n, color=INK, r=15):
    w(f"<circle cx='{x}' cy='{y}' r='{r}' fill='{color}'/>")
    text(x, y, str(n), size=15, anchor="middle", weight="700", fill="#ffffff")
def doc(x, y, wd, h, title, lines, stroke=INK, fill="#ffffff", size=10.5, lh=15):
    # a "document" shape with a folded corner
    f = 14
    w(f"<path d='M{x},{y+8} q0,-8 8,-8 h{wd-8-f} l{f},{f} v{h-f-8} q0,8 -8,8 h{-(wd-16)} q-8,0 -8,-8 z' fill='{fill}' stroke='{stroke}' stroke-width='2'/>")
    w(f"<path d='M{x+wd-f},{y} v{f} h{f}' fill='none' stroke='{stroke}' stroke-width='2'/>")
    text(x + 12, y + 20, title, size=11, weight="700", fill=stroke if stroke != INK else MUTED, font=MONO)
    for i, ln in enumerate(lines):
        text(x + 12, y + 42 + i * lh, ln, size=size, fill=INK, font=MONO)
def bubble(x, y, wd, h, title, lines, stroke, fill, ink, tail=None):
    rect(x, y, wd, h, fill, stroke, rx=16)
    if tail:  # small triangle pointing up to (tx, y)
        tx = tail
        w(f"<path d='M{tx-10},{y+1} L{tx},{y-14} L{tx+10},{y+1} z' fill='{fill}' stroke='{stroke}' stroke-width='2'/>")
        w(f"<line x1='{tx-9}' y1='{y+1}' x2='{tx+9}' y2='{y+1}' stroke='{fill}' stroke-width='3'/>")
    text(x + 16, y + 24, title, size=14, weight="700", fill=ink)
    for i, ln in enumerate(lines):
        text(x + 16, y + 48 + i * 18, ln, size=11.5, fill=ink)

w(f"<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 {W} {H}' role='img' aria-labelledby='t'>")
w("<title id='t'>snippet — the whiteboard version</title>")
w("<defs>")
for mid, col in [("a", INK), ("aB", BLUE), ("aA", AMBER), ("aR", RED), ("aG", GREEN), ("aP", "#7c3aed")]:
    w(f"<marker id='{mid}' viewBox='0 0 10 10' refX='9' refY='5' markerWidth='6' markerHeight='6' orient='auto-start-reverse'><path d='M0,0 L10,5 L0,10 z' fill='{col}'/></marker>")
w("</defs>")
rect(0, 0, W, H, "#ffffff", "none", rx=0, sw=0)



PURPLE, PURPLE_BG, PURPLE_INK = "#7c3aed", "#f5f3ff", "#5b21b6"
def arrow(pts, color=INK, width=2.4, dashed=False):
    p = " ".join(f"{x},{y}" for x, y in pts)
    m = {INK: "a", BLUE: "aB", AMBER: "aA", RED: "aR", GREEN: "aG", PURPLE: "aP"}[color]
    d = " stroke-dasharray='7 5'" if dashed else ""
    w(f"<polyline points='{p}' fill='none' stroke='{color}' stroke-width='{width}'{d} stroke-linejoin='round' marker-end='url(#{m})'/>")
def steps_row(Y, cols, BH_=118):
    for x, wd, t, lines, col, fill, n in cols:
        rect(x, Y, wd, BH_, fill, col, rx=16, sw=2.5)
        tx = x + 18
        if n:
            badge(x + 26, Y + 26, n, col); tx = x + 50
        text(tx, Y + 26, t, size=16, weight="700", fill=col if col != INK else INK)
        for i, ln in enumerate(lines):
            text(x + 18, Y + 54 + i * 17, ln, size=12.5, fill=MUTED)
    for i in range(len(cols) - 1):
        x1 = cols[i][0] + cols[i][1]; x2 = cols[i + 1][0]
        arrow([(x1 + 4, Y + BH_ / 2), (x2 - 4, Y + BH_ / 2)], width=3)
def bracket(x1, x2, y, label, col=MUTED):
    w(f"<path d='M{x1},{y} v8 h{x2-x1} v-8' fill='none' stroke='{col}' stroke-width='1.5'/>")
    text((x1 + x2) / 2, y + 20, label, size=11, anchor="middle", fill=col, style="italic")
def table(x, y, wd, h, title, rows, kx=270, size=11.5):
    rect(x, y, wd, h, "#ffffff", LINE, rx=14, sw=1.5)
    text(x + 16, y + 24, title, size=13, weight="700")
    for i, (a, b) in enumerate(rows):
        text(x + 16, y + 50 + i * 24, a, size=size, weight="700", font=MONO)
        text(x + kx, y + 50 + i * 24, b, size=size, fill=MUTED)
def footer(done, remember):
    text(40, H - 42, "Done when:", size=12.5, weight="700", fill=GREEN_INK)
    text(130, H - 42, done, size=11.5, fill=GREEN_INK)
    text(40, H - 18, remember, size=12, fill=MUTED, style="italic")

GCP_BLUE = "#4285f4"
def node(x, y, wd, h, title, sub, col, fill="#ffffff", strike=False):
    rect(x, y, wd, h, fill, col, rx=8, sw=1.8)
    text(x + wd / 2, y + 18, title, size=11.5, weight="700", anchor="middle", fill=col if col not in (INK, GCP_BLUE) else INK)
    if strike: w(f"<line x1='{x+14}' y1='{y+18}' x2='{x+wd-14}' y2='{y+18}' stroke='{MUTED}' stroke-width='2'/>")
    for i, ln in enumerate(sub.split("|")):
        text(x + wd / 2, y + 36 + i * 13, ln, size=9.5, anchor="middle", fill=MUTED)
text(20, 26, "Snippet 2 — the managed services column inside the VPC (blue = already on your diagram, red = add)", size=15, weight="700")
items = [
    ("Cloud SQL", "PostgreSQL 16 · HA · pgvector|row-level security on every table|cross-region replica for DR", GCP_BLUE, "#ffffff", False, "app · ai"),
    ("Pub/Sub", "platform-jobs · run-events|ai-jobs · ai-results · jira-events|global — same in DR", RED, RED_BG, False, "app · ai · runners"),
    ("Cloud Storage", "buckets: inputs · evidence · reports|dual-region · evidence kept 90 days", RED, RED_BG, False, "app · runners"),
    ("Secret Manager", "+ CSI driver · the only place a|secret value lives · global", RED, RED_BG, False, "all, read-only"),
    ("Vertex AI", "Gemini · fast + strong tiers|context caching per workflow", GCP_BLUE, "#ffffff", False, "ai namespace ONLY"),
    ("Sensitive Data Protection", "(DLP) scans uploads, CSVs,|stories; 2 % sample of evidence", RED, RED_BG, False, "app"),
    ("Artifact Registry", "images pinned by digest,|scanned, SBOM published", RED, RED_BG, False, "GKE pulls"),
    ("Logging · Monitoring · Trace", "one trace id from the browser|to the runner pod", GCP_BLUE, "#ffffff", False, "all"),
    ("Redis", "not used by this product|remove, or keep as org-shared", MUTED, GRAY_BG, True, "—"),
    ("MongoDB Atlas + PSC", "not used by this product|(other teams on the platform)", MUTED, GRAY_BG, True, "—"),
]
for i, (t, sub, col, fill, strike, who) in enumerate(items):
    x = 20 + (i % 5) * 172; y = 50 + (i // 5) * 170
    node(x, y, 160, 76, t, sub, col, fill, strike)
    text(x + 80, y + 92, "reached by: " + who, size=9, anchor="middle", fill=col if col in (RED, BLUE) else MUTED, weight="600")
text(20, H - 14, "Draw ONE line from the cluster to each service; the 'reached by' label says which namespace may use it (that is the NetworkPolicy).", size=10, fill=MUTED, style="italic")
w("</svg>")
open("out/snippet-2-managed-services.svg", "w").write("\n".join(out))
print("ok")
