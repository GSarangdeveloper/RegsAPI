import os
os.makedirs('out', exist_ok=True)
#!/usr/bin/env python3
"""Phase 1 Onboard — developer architecture diagram (SVG)."""
FONT = "Inter, 'Segoe UI', Helvetica, Arial, sans-serif"
MONO = "'JetBrains Mono', SFMono-Regular, Consolas, 'Liberation Mono', monospace"
INK, MUTED, LINE = "#1f2937", "#6b7280", "#9ca3af"
BLUE, BLUE_BG, BLUE_INK = "#2563eb", "#eff6ff", "#1e40af"
GREEN, GREEN_BG, GREEN_INK = "#059669", "#ecfdf5", "#065f46"
AMBER, AMBER_BG, AMBER_INK = "#d97706", "#fffbeb", "#92400e"
RED, RED_BG, RED_INK = "#dc2626", "#fef2f2", "#991b1b"
PURPLE, PURPLE_BG, PURPLE_INK = "#7c3aed", "#f5f3ff", "#5b21b6"
GRAY_BG = "#f3f4f6"
W, H = 1900, 930
out = []
def w(s): out.append(s)
def esc(s): return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
def text(x, y, s, size=10, anchor="start", weight="normal", fill=INK, style="", font=FONT):
    st = f" font-style='{style}'" if style else ""
    w(f"<text x='{x}' y='{y}' font-size='{size}' text-anchor='{anchor}' font-weight='{weight}' fill='{fill}'{st} dominant-baseline='middle' font-family=\"{font}\">{esc(s)}</text>")
def rect(x, y, wd, h, fill, stroke, rx=8, sw=1.5, dash=""):
    d = f" stroke-dasharray='{dash}'" if dash else ""
    w(f"<rect x='{x}' y='{y}' width='{wd}' height='{h}' rx='{rx}' fill='{fill}' stroke='{stroke}' stroke-width='{sw}'{d}/>")
def arrow(pts, color=INK, dashed=False, width=1.6, both=False):
    p = " ".join(f"{x},{y}" for x, y in pts)
    m = {INK: "a", BLUE: "aBlue", AMBER: "aAmber", RED: "aRed", GREEN: "aGreen", PURPLE: "aPurple"}[color]
    d = " stroke-dasharray='5 4'" if dashed else ""
    ms = f" marker-start='url(#{m})'" if both else ""
    w(f"<polyline points='{p}' fill='none' stroke='{color}' stroke-width='{width}'{d} marker-end='url(#{m})'{ms}/>")
def badge(x, y, n, color=INK, r=10):
    w(f"<circle cx='{x}' cy='{y}' r='{r}' fill='{color}'/>")
    text(x, y, str(n), size=10, anchor="middle", weight="700", fill="#ffffff")
def card(x, y, wd, h, title, lines, fill="#ffffff", stroke=INK, tink=INK, mono_title=False, size=9.5, lh=13, num=None, numcol=INK, tag=None, tagcol=MUTED):
    rect(x, y, wd, h, fill, stroke)
    tx = x + 12
    if num is not None:
        badge(x + 16, y + 16, num, numcol); tx = x + 32
    text(tx, y + 16, title, size=11.5, weight="700", fill=tink, font=MONO if mono_title else FONT)
    if tag:
        tw_ = len(tag) * 5.2 + 12
        rect(x + wd - 10 - tw_, y + 7, tw_, 18, "#ffffff", tagcol, rx=9, sw=1)
        text(x + wd - 10 - tw_ / 2, y + 16, tag, size=9, anchor="middle", weight="600", fill=tagcol)
    for i, ln in enumerate(lines):
        mono = ln.startswith("`")
        text(x + 12, y + 36 + i * lh, ln.strip("`"), size=size, fill=MUTED if not mono else INK, font=MONO if mono else FONT)

w(f"<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 {W} {H}' role='img' aria-labelledby='t'>")
w("<title id='t'>Overall architecture — architecture for developers</title>")
w("<defs>")
for mid, col in [("a", INK), ("aBlue", BLUE), ("aAmber", AMBER), ("aRed", RED), ("aGreen", GREEN), ("aPurple", PURPLE)]:
    w(f"<marker id='{mid}' viewBox='0 0 10 10' refX='9' refY='5' markerWidth='7' markerHeight='7' orient='auto-start-reverse'><path d='M0,0 L10,5 L0,10 z' fill='{col}'/></marker>")
w("</defs>")
rect(0, 0, W, H, "#ffffff", "none", rx=0)







R3, R3_BG, R3_INK = PURPLE, PURPLE_BG, PURPLE_INK
def box(x, y, wd, h, title, sub, lines=(), stroke=INK, fill="#ffffff", tink=None, tag=None, tagcol=None, size=9, lh=12.5, tsize=12):
    rect(x, y, wd, h, fill, stroke, rx=10)
    text(x + 14, y + 18, title, size=tsize, weight="700", fill=tink or (stroke if stroke != INK else INK))
    if tag:
        tw_ = len(tag) * 5.4 + 12
        rect(x + wd - 12 - tw_, y + 9, tw_, 18, "#ffffff", tagcol or stroke, rx=9, sw=1)
        text(x + wd - 12 - tw_ / 2, y + 18, tag, size=9, anchor="middle", weight="700", fill=tagcol or stroke)
    if sub: text(x + 14, y + 34, sub, size=9, fill=MUTED, style="italic")
    for i, ln in enumerate(lines):
        text(x + 14, y + (50 if sub else 36) + i * lh, ln, size=size, fill=MUTED)

# ---------------------------------------------------------------- title
text(24, 34, "AI API Testing Platform — the whole system on one page", size=22, weight="700")
text(24, 60, "One code base, deployed as three kinds of pods plus a test-runner Job, around one database. People decide at five gates; AI only drafts; the runner is the only thing that touches the API under test.", size=11.5, fill=MUTED)
text(W - 24, 34, "white = release 1 (MVP)  ·  blue = release 2 (AI)  ·  purple = release 3 (triage, defects)", size=10.5, anchor="end", fill=LINE)
text(W - 24, 52, "read this page first; each phase has its own detailed page", size=10.5, anchor="end", fill=LINE)

# ---------------------------------------------------------------- row 1: who
Y1 = 84
text(40, Y1 + 10, "WHO  —  people and systems that start things", size=10, weight="700", fill=LINE)
who = [
    ("QE (tester)", "browser, single sign-on", ["creates workflows, uploads specs, reviews and", "approves test cases, reads reports, triages"], INK, "#ffffff", None),
    ("QE lead", "browser, single sign-on", ["everything a QE does, plus: accept a coverage gap,", "change thresholds, delete credentials, allow security tests"], INK, "#ffffff", None),
    ("CI pipeline", "API key, no login", ["after a deploy: POST /triggers/deploy → a P1 run", "duplicates within 60 s merged"], INK, "#ffffff", None),
    ("Schedule", "nightly, per workflow", ["a timed POST /runs on the chosen environment"], INK, "#ffffff", None),
    ("Jira", "webhook, signed", ["issue moves to 'ready for QA' → rerun the linked tests", "(release 3)"], R3, R3_BG, "R3"),
]
wx, ww = 40, 356
for i, (t, s_, ls, col, fill, tag) in enumerate(who):
    box(wx + i * (ww + 10), Y1 + 22, ww, 86, t, s_, ls, stroke=col, fill=fill, tag=tag, tagcol=col)
    arrow([(wx + i * (ww + 10) + ww / 2, Y1 + 108), (wx + i * (ww + 10) + ww / 2, Y1 + 136)], width=1.6)

# ---------------------------------------------------------------- row 2: GKE
Y2 = Y1 + 140
rect(40, Y2, W - 80, 330, "#fafafa", LINE, rx=14)
text(58, Y2 + 20, "WHERE THE CODE RUNS  —  Google Kubernetes Engine (GKE), one cluster", size=12, weight="700")
text(58, Y2 + 38, "one repository · one container image for everything Python · the entrypoint decides what a pod does · all three Deployments ship together with the same image tag", size=9.5, fill=MUTED)

# web
box(58, Y2 + 56, 250, 250, "web", "Angular app · nginx · 2 pods", [
    "screens only, no business logic:", "workflows · readiness · discover ·", "coverage · review queue · scripts ·", "runs · reports · triage",
    "", "talks to the API over REST;", "gets live updates over SSE"], stroke=INK)
arrow([(308, Y2 + 180), (338, Y2 + 180)], width=2, both=True)
text(323, Y2 + 166, "REST", size=8.5, anchor="middle", weight="600")

# namespace app: api + worker
rect(338, Y2 + 50, 740, 262, "#ffffff", LINE, rx=10, dash="5 3")
text(350, Y2 + 64, "namespace  app", size=9.5, weight="700", fill=MUTED, font=MONO)
box(350, Y2 + 74, 356, 226, "platform-api", "FastAPI · 2–20 pods · scales on HTTP load", [
    "answers every request in < 1 s, then hands off:", "• login check, permission check, team isolation", "• every status change and every human gate", "• the review queue and every decision (audited)",
    "• queues slow work for the worker", "• the only thing that writes to the database", "  status columns", "", "routes: /api/v1/… · SSE · /triggers · /webhooks"], stroke=INK, tag="all phases", tagcol=MUTED)
box(716, Y2 + 74, 350, 226, "platform-worker", "same image, entrypoint 'worker' · 1–N pods · scales on queue", [
    "runs the slow steps, one job at a time:", "• Phase 1 normalize, lint, smoke check", "• Phase 2 Discover (the API model)", "• Phase 3 rule engine + coverage", "• Phase 4 test data, templates, Git commit",
    "• Phase 5 pre-flight, start the Job, ingest results", "• Phase 6 report queries · (R3) triage, Jira, reruns", "", "never serves HTTP · long shutdown grace"], stroke=INK, tag="all phases", tagcol=MUTED)

# namespace ai
rect(1092, Y2 + 50, 330, 262, BLUE_BG, BLUE, rx=10, dash="5 3")
text(1104, Y2 + 64, "namespace  ai", size=9.5, weight="700", fill=BLUE, font=MONO)
box(1104, Y2 + 74, 306, 226, "ai-worker", "same image, entrypoint 'worker --ai' · 0–N pods", [
    "the ONLY pods allowed to call the model:", "• R2 rules from Jira stories", "• R2 test cases for coverage gaps", "• R2 CSV column mapping", "• R2 scripts when no template fits",
    "• R3 triage of failures", "", "AI only drafts. Every draft is checked by", "code and decided by a person."], stroke=BLUE, fill="#ffffff", tag="R2 · R3", tagcol=BLUE)

# namespace runners
rect(1436, Y2 + 50, 406, 262, "#ffffff", LINE, rx=10, dash="5 3")
text(1448, Y2 + 64, "namespace  runners", size=9.5, weight="700", fill=MUTED, font=MONO)
box(1448, Y2 + 74, 382, 226, "runner  (Kubernetes Job)", "different image: Java 21 + Karate · one Job per run · N pods = N shards", [
    "1 read the manifest  2 git clone at the pinned commit", "3 download data  4 secrets → AUTH_* variables", "5 run Karate by tags  6 mask request/response logs", "7 upload evidence  8 publish 'run completed'  9 exit",
    "", "network: the test environment, Storage, Pub/Sub, Git", "and nothing else. Never production. Never the DB.", "", "the ONLY thing that calls the API under test"], stroke=INK, tag="Phase 5", tagcol=MUTED)

# ---------------------------------------------------------------- row 3: data & external
Y3 = Y2 + 350
text(40, Y3 + 10, "WHAT IT USES  —  managed services (nothing self-hosted)", size=10, weight="700", fill=LINE)
text(W - 40, Y3 + 10, "every pod reaches these with its own service account · the runner only Storage, Pub/Sub, Git, Secret Manager · only ai-worker reaches Vertex AI", size=9, anchor="end", fill=MUTED, style="italic")
for xx in (528, 891):
    arrow([(xx, Y2 + 330), (xx, Y3 + 20)], width=1.4)
svc = [
    ("Cloud SQL · PostgreSQL", "the one database", ["team, workflow, environment, credential_profile, spec_version,", "target, field, dependency_edge, suite, test_case (JSON), script,", "run, result, triage_item, defect, audit_event, outbox · RLS on all"], INK, "#ffffff", None, 300),
    ("Cloud Storage", "3 buckets", ["inputs: raw + cleaned specs, samples, data files", "evidence: per run, masked, 90 days", "reports: summaries, 2 years"], INK, "#ffffff", None, 226),
    ("Pub/Sub", "the queue", ["platform-jobs · run-events", "ai-jobs · ai-results (R2)", "jira-events (R3) · via outbox"], INK, "#ffffff", None, 196),
    ("Secret Manager", "the only place a secret lives", ["written once by the credentials", "endpoint; pods read by address"], RED, RED_BG, None, 206),
    ("Git · test-assets", "generated Karate projects", ["one folder per workflow · one commit", "per generation · runs pin a commit"], INK, "#ffffff", None, 226),
    ("Vertex AI · Gemini", "the model", ["called only from ai-worker, through", "one interface; fast + strong tiers"], BLUE, BLUE_BG, "R2", 206),
    ("Jira · Zephyr", "read stories · write defects · test cases", ["Zephyr: publish cases, test cycles (R2)", "Jira: stories (R2), defects + webhook (R3)"], R3, R3_BG, "R2·R3", 236),
    ("Also", "", ["DLP: personal-data scan on uploads", "Teams / email: one message per event", "Workload Identity: pods log in, no keys"], INK, "#ffffff", None, 186),
]
sx = 40
for t, s_, ls, col, fill, tag, wd in svc:
    box(sx, Y3 + 22, wd, 96, t, s_, ls, stroke=col, fill=fill, tag=tag, tagcol=col, size=8.5, lh=12)
    sx += wd + 9

# ---------------------------------------------------------------- row 4: API under test + principles + phase map
Y4 = Y3 + 138
box(40, Y4, 520, 96, "APIs under test  ·  dev / qa / staging", "the customer's systems, per environment", [
    "reached ONLY by the runner Job (and one read-only smoke call from the worker during onboarding)", "never production: network rules make that impossible, not just forbidden",
    "login profiles per environment (default, member_b, read_only …) for role and ownership tests · Kafka (R3)"], stroke=BLUE, fill=BLUE_BG, size=8.5, lh=12)

rect(580, Y4, 640, 96, GREEN_BG, GREEN, rx=10)
text(594, Y4 + 18, "Six rules that hold the whole design together", size=12, weight="700", fill=GREEN_INK)
rules = [
    "1  Deterministic first: code writes the tests from the spec; AI only fills gaps, and only drafts.",
    "2  A person decides at every gate: readiness, rules, test cases, data, defects. Never auto-filed.",
    "3  One test case JSON is the truth; scripts, Zephyr, reports and reruns all derive from it.",
    "4  Secrets never enter the DB, logs, Git, prompts or evidence — only their Secret Manager address.",
    "5  Everything is immutable and versioned: spec versions, suites, runs. A change is a new version.",
    "6  Every table has team_id; Postgres row-level security is the second wall behind the code.",
]
for i, ln in enumerate(rules):
    text(594, Y4 + 36 + i * 11, ln, size=8.3, fill=GREEN_INK)

rect(1240, Y4, 620, 96, "#ffffff", LINE, rx=10)
text(1254, Y4 + 18, "The six phases and where each one runs", size=12, weight="700")
ph = [
    ("1 Onboard", "api + worker", "spec in → readiness report"),
    ("2 Understand", "worker (+ ai R2)", "spec → API model (+ rules)"),
    ("3 Design", "worker (+ ai R2)", "API model → approved test cases"),
    ("4 Build", "worker (+ ai R2)", "cases → data + Karate scripts in Git"),
    ("5 Run", "worker + runner Job", "scripts → results + evidence"),
    ("6 Close the loop", "worker (+ ai R3)", "results → report, defects, reruns"),
]
for i, (a, b, c) in enumerate(ph):
    y = Y4 + 36 + i * 10.5
    text(1254, y, a, size=8.3, weight="700")
    text(1354, y, b, size=8.3, fill=MUTED, font=MONO)
    text(1490, y, c, size=8.3, fill=MUTED)

# ---------------------------------------------------------------- row 5: the loop in one line
Y5 = Y4 + 116
rect(40, Y5, W - 80, 74, "#ffffff", LINE, rx=10, dash="4 3")
text(54, Y5 + 16, "How a run of the product reads, left to right — the five green diamonds are the human gates", size=11, weight="700")
chain = [("spec upload", INK), ("readiness ◆", GREEN), ("API model", INK), ("rules ◆ (R2)", GREEN), ("test cases", INK), ("approval ◆", GREEN), ("data ◆ (R2)", GREEN), ("scripts in Git", INK), ("run on GKE", BLUE), ("results", INK), ("triage ◆ (R3)", GREEN), ("Jira + rerun (R3)", R3), ("report", INK)]
cx = 54
yC = Y5 + 48
for i, (n, c) in enumerate(chain):
    wd = len(n) * 6.4 + 22
    fill = {INK: "#ffffff", GREEN: GREEN_BG, BLUE: BLUE_BG, R3: R3_BG}[c]
    rect(cx, yC - 12, wd, 24, fill, c, rx=12)
    text(cx + wd / 2, yC, n, size=9.5, anchor="middle", weight="700", fill=c if c != INK else INK)
    cx += wd
    if i < len(chain) - 1:
        arrow([(cx, yC), (cx + 22, yC)], width=1.4); cx += 24

w("</svg>")
open("out/architecture-0-overview.svg", "w").write("\n".join(out))
print("ok")
