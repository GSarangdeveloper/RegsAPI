import os
os.makedirs('out', exist_ok=True)
#!/usr/bin/env python3
"""Phase 1 Onboard — developer architecture diagram (SVG)."""
FONT = "Inter, 'Segoe UI', Helvetica, Arial, sans-serif"
MONO = "'JetBrains Mono', SFMono-Regular, Consolas, 'Liberation Mono', monospace"
INK, MUTED, LINE = "#1f2937", "#6b7280", "#9ca3af"
BLUE, BLUE_BG, BLUE_INK = "#2563eb", "#eff6ff", "#1e40af"
GREEN, GREEN_BG, GREEN_INK = "#059669", "#ecfdf5", "#065f46"
AMBER, AMBER_BG, AMBER_INK = "#d97706", "#fffbeb", "#92400e"
RED, RED_BG, RED_INK = "#dc2626", "#fef2f2", "#991b1b"
PURPLE, PURPLE_BG, PURPLE_INK = "#7c3aed", "#f5f3ff", "#5b21b6"
GRAY_BG = "#f3f4f6"
W, H = 1900, 1120
out = []
def w(s): out.append(s)
def esc(s): return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
def text(x, y, s, size=10, anchor="start", weight="normal", fill=INK, style="", font=FONT):
    st = f" font-style='{style}'" if style else ""
    w(f"<text x='{x}' y='{y}' font-size='{size}' text-anchor='{anchor}' font-weight='{weight}' fill='{fill}'{st} dominant-baseline='middle' font-family=\"{font}\">{esc(s)}</text>")
def rect(x, y, wd, h, fill, stroke, rx=8, sw=1.5, dash=""):
    d = f" stroke-dasharray='{dash}'" if dash else ""
    w(f"<rect x='{x}' y='{y}' width='{wd}' height='{h}' rx='{rx}' fill='{fill}' stroke='{stroke}' stroke-width='{sw}'{d}/>")
def arrow(pts, color=INK, dashed=False, width=1.6, both=False):
    p = " ".join(f"{x},{y}" for x, y in pts)
    m = {INK: "a", BLUE: "aBlue", AMBER: "aAmber", RED: "aRed", GREEN: "aGreen", PURPLE: "aPurple"}[color]
    d = " stroke-dasharray='5 4'" if dashed else ""
    ms = f" marker-start='url(#{m})'" if both else ""
    w(f"<polyline points='{p}' fill='none' stroke='{color}' stroke-width='{width}'{d} marker-end='url(#{m})'{ms}/>")
def badge(x, y, n, color=INK, r=10):
    w(f"<circle cx='{x}' cy='{y}' r='{r}' fill='{color}'/>")
    text(x, y, str(n), size=10, anchor="middle", weight="700", fill="#ffffff")
def card(x, y, wd, h, title, lines, fill="#ffffff", stroke=INK, tink=INK, mono_title=False, size=9.5, lh=13, num=None, numcol=INK, tag=None, tagcol=MUTED):
    rect(x, y, wd, h, fill, stroke)
    tx = x + 12
    if num is not None:
        badge(x + 16, y + 16, num, numcol); tx = x + 32
    text(tx, y + 16, title, size=11.5, weight="700", fill=tink, font=MONO if mono_title else FONT)
    if tag:
        tw_ = len(tag) * 5.2 + 12
        rect(x + wd - 10 - tw_, y + 7, tw_, 18, "#ffffff", tagcol, rx=9, sw=1)
        text(x + wd - 10 - tw_ / 2, y + 16, tag, size=9, anchor="middle", weight="600", fill=tagcol)
    for i, ln in enumerate(lines):
        mono = ln.startswith("`")
        text(x + 12, y + 36 + i * lh, ln.strip("`"), size=size, fill=MUTED if not mono else INK, font=MONO if mono else FONT)

w(f"<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 {W} {H}' role='img' aria-labelledby='t'>")
w("<title id='t'>Phase 4a From test case to .feature — architecture for developers</title>")
w("<defs>")
for mid, col in [("a", INK), ("aBlue", BLUE), ("aAmber", AMBER), ("aRed", RED), ("aGreen", GREEN), ("aPurple", PURPLE)]:
    w(f"<marker id='{mid}' viewBox='0 0 10 10' refX='9' refY='5' markerWidth='7' markerHeight='7' orient='auto-start-reverse'><path d='M0,0 L10,5 L0,10 z' fill='{col}'/></marker>")
w("</defs>")
rect(0, 0, W, H, "#ffffff", "none", rx=0)





def code(x, y, wd, h, title, lines, stroke=INK, fill="#ffffff", size=9, lh=12.6, hi=None):
    rect(x, y, wd, h, fill, stroke, rx=8)
    text(x + 12, y + 16, title, size=10.5, weight="700", fill=stroke if stroke != INK else INK)
    for i, ln in enumerate(lines):
        col = INK
        if hi and i in hi: col = hi[i]
        lead = len(ln) - len(ln.lstrip(' '))
        text(x + 12, y + 36 + i * lh, '\u00a0' * lead + ln.lstrip(' '), size=size, fill=col, font=MONO)

# ---------------------------------------------------------------- title
text(24, 34, "Phase 4a · How a test case becomes a .feature file — one worked example", size=22, weight="700")
text(24, 60, "A test case is a small JSON document (Phase 3). Build turns it into a Karate script in three moves: pick a template from the case's type → copy the case's values into the template's holes → check the result.", size=11.5, fill=MUTED)
text(24, 78, "No AI is involved for the six standard shapes. AI is asked only when no template fits, and even then it must write inside the same project and pass the same checks.", size=11.5, fill=MUTED)
text(W - 24, 34, "Companion to Phase 4 · Build", size=10.5, anchor="end", fill=LINE)

# ---------------------------------------------------------------- example 1: negative case
Y0 = 106
text(40, Y0 + 12, "Example 1 — a negative case (release 1, template only)", size=14, weight="700")

case_lines = [
    '{',
    '  "case_id": "TC-CLM-0031",',
    '  "title": "Reject claim without member id",',
    '  "type": "negative",  "priority": "p1",',
    '  "steps": [{',
    '    "alias": "create",',
    '    "target_key": "createClaim",        // POST /claims',
    '    "credential_profile": "default",',
    '    "request": { "body": {',
    '        "base": "sample",',
    '        "mutations": [{ "op": "remove",',
    '                        "path": "/memberId",',
    '                        "label": "memberId missing" }] } },',
    '    "expect": { "status": 400,',
    '      "body": [{ "path": "$.errorCode",',
    '                 "op": "eq", "value": "MISSING_FIELD" }] }',
    '  }],',
    '  "coverage_targets": ["op:createClaim:400",',
    '                       "field:createClaim:req:/memberId"],',
    '  "cleanup": []',
    '}',
]
code(40, Y0 + 30, 470, 310, "① the test case JSON  (test_case.spec, written by Phase 3)", case_lines,
     hi={1: BLUE, 3: GREEN, 6: PURPLE, 10: RED, 11: RED, 13: AMBER, 14: AMBER, 15: AMBER})

# decision
dx = 540
rect(dx, Y0 + 30, 300, 310, GRAY_BG, LINE, rx=8, sw=1)
text(dx + 12, Y0 + 46, "② pick the template — a fixed rule", size=10.5, weight="700")
dec = [
    ("type = positive", "→ positive_schema_match"),
    ("type = negative, one step,", ""),
    ("  status only, no body check", "→ status_only"),
    ("type = negative|boundary", ""),
    ("  one mutation on the body", "→ field_negatives_outline ✓"),
    ("type = security, other login", "→ security_identity"),
    ("type = security, injection", "→ injection_outline"),
    ("2+ steps, values passed on", "→ dependency_chain"),
    ("anything else", "→ None  (see example 2)"),
]
for i, (a, b) in enumerate(dec):
    text(dx + 12, Y0 + 66 + i * 14, a.replace("  ", "\u00a0\u00a0"), size=8.3, fill=INK if "✓" in b else MUTED, font=MONO)
    text(dx + 150, Y0 + 66 + i * 14, b, size=8.3, weight="700" if "✓" in b else "normal", fill=GREEN if "✓" in b else MUTED, font=MONO)
text(dx + 12, Y0 + 204, "the rule is ~30 lines of Python: select_template(case).", size=8.8, fill=MUTED)
text(dx + 12, Y0 + 218, "Same input, same answer, every time. Unit-test it.", size=8.8, fill=MUTED)
text(dx + 12, Y0 + 246, "③ render = copy values into holes", size=10.5, weight="700")
text(dx + 12, Y0 + 264, "case_id → the @TC- tag · target → the URL path", size=8.8, fill=MUTED)
text(dx + 12, Y0 + 278, "mutation → one Outline row · expect → the match lines", size=8.8, fill=MUTED)
text(dx + 12, Y0 + 292, "base: sample → read('data/{env}/TC-CLM-0031.json')", size=8.8, fill=MUTED)
text(dx + 12, Y0 + 306, "credential_profile → which token variable to use", size=8.8, fill=MUTED)
text(dx + 12, Y0 + 320, "Colours show where each value lands →", size=8.8, fill=MUTED, style="italic")
arrow([(510, Y0 + 185), (dx, Y0 + 185)], width=2)
arrow([(dx + 300, Y0 + 185), (870, Y0 + 185)], width=2)

feat = [
    '# generated: suite 12 case TC-CLM-0031 v1 template field_negatives_outline@3',
    'Feature: createClaim  (POST /claims)',
    '',
    '  Background:',
    '    * url baseUrl                          # from karate-config.js, never typed here',
    '    * def token = call read(\'auth/token.feature\') { profile: \'default\' }',
    '    * header Authorization = \'Bearer \' + token.value',
    '',
    '  @TC-CLM-0031 @p1 @negative @endpoint:createClaim',
    '  Scenario Outline: Reject claim without member id — <label>',
    '    * def body = read(\'data/<env>/TC-CLM-0031.json\')',
    '    * call read(\'helpers/mutate.feature\') { body: \'#(body)\', op: \'<op>\', path: \'<path>\' }',
    '    Given path \'/claims\'',
    '    And request body',
    '    When method POST',
    '    Then status <status>',
    '    And match response.errorCode == \'MISSING_FIELD\'',
    '',
    '    Examples:',
    '      | op     | path      | status | label            |',
    '      | remove | /memberId | 400    | memberId missing |',
]
code(870, Y0 + 30, 990, 310, "④ the generated file  features/createClaim.feature  (committed to Git)", feat,
     hi={0: MUTED, 1: PURPLE, 4: MUTED, 5: GREEN, 8: BLUE, 9: BLUE, 12: PURPLE, 15: AMBER, 16: AMBER, 19: RED, 20: RED}, size=8.8)

# checks strip
cy = Y0 + 352
rect(40, cy, W - 80, 56, GREEN_BG, GREEN, rx=8)
text(54, cy + 16, "⑤ before the commit, three checks on the generated text (no execution):", size=10.5, weight="700", fill=GREEN_INK)
text(54, cy + 34, "parse — is it valid Gherkin/Karate, does every read() file exist, is every variable defined before use?      static — no hard-coded URL, no secret, no Authorization typed in, @TC- tag present, no personal data", size=9, fill=GREEN_INK)
text(54, cy + 47, "contract — status 400 is documented for POST /claims and $.errorCode exists in the 400 response schema.      All three pass → the file is committed and the script row says valid. Any failure → needs_attention.", size=9, fill=GREEN_INK)

# ---------------------------------------------------------------- example 2: AI
Y1 = cy + 76
text(40, Y1 + 12, "Example 2 — when no template fits (release 2, AI writes the scenario)", size=14, weight="700")
text(40, Y1 + 30, "The rule engine and templates cover single-endpoint cases and simple chains. A business rule from a Jira story usually needs several steps with logic in between. select_template returns None → in release 1 the case is marked needs_attention for a QE to write; in release 2 it goes to ai-worker.", size=10, fill=MUTED)

case2 = [
    '{ "case_id": "TC-CLM-0142",',
    '  "title": "Reject update of an adjudicated claim",',
    '  "type": "negative", "priority": "p1",',
    '  "steps": [',
    '    { "alias": "create",     "target_key": "createClaim",',
    '      "expect": { "status": 201 } },',
    '    { "alias": "adjudicate", "target_key": "adjudicateClaim",',
    '      "request": { "path_params": { "claimId":',
    '         { "ref": "${create.response.body.claimId}" } } },',
    '      "expect": { "status": 200, "body": [',
    '         { "path": "$.status", "op": "eq", "value": "ADJUDICATED" }] } },',
    '    { "alias": "update",     "target_key": "updateClaim",',
    '      "request": { "body": { "base": "sample", "mutations": [',
    '         { "op": "set", "path": "/amount", "value": 500 }] } },',
    '      "expect": { "status": 409, "body": [',
    '         { "path": "$.errorCode", "op": "eq", "value": "CLAIM_LOCKED" }] } }',
    '  ],',
    '  "coverage_targets": ["op:updateClaim:409", "rule:R-12"],',
    '  "cleanup": [{ "alias": "create", "delete_target_key": "deleteClaim" }] }',
]
code(40, Y1 + 50, 560, 290, "the test case JSON (3 steps, a value passed from step 1 to steps 2 and 3, a business rule R-12)", case2, size=8.4, lh=12.2)

ax = 630
rect(ax, Y1 + 50, 380, 290, BLUE_BG, BLUE, rx=8)
text(ax + 12, Y1 + 66, "what ai-worker is given (and nothing else)", size=10.5, weight="700", fill=BLUE_INK)
given = [
    "• this one case JSON",
    "• the spec slice for the 3 endpoints (schemas, responses)",
    "• the helper features that exist (names + parameters)",
    "• the conventions guide (how our features are written)",
    "• 2 finished examples of the closest pattern",
    "",
    "what it must return",
    "• one Scenario as text, plus the list of helpers it used",
    "",
    "what happens to the answer",
    "• the SAME parse / static / contract checks as example 1",
    "• (R2) a run against a mock server built from the spec",
    "• any failure → sent back once with the error message",
    "• second failure → needs_attention, a QE takes over",
    "• the file header says 'generated by ai' so it is visible",
    "• AI never picks the case_id, the tags or the URL:",
    "  those are stamped by the platform after the answer",
]
for i, ln in enumerate(given):
    bold = ln in ("what it must return", "what happens to the answer")
    text(ax + 12, Y1 + 84 + i * 14.5, ln, size=8.8, weight="700" if bold else "normal", fill=BLUE_INK)

feat2 = [
    '# generated: suite 12 case TC-CLM-0142 v1 by ai (scripts graph v4)',
    '  @TC-CLM-0142 @p1 @negative @endpoint:updateClaim @rule:R-12',
    '  Scenario: Reject update of an adjudicated claim',
    '    * def create = call read(\'helpers/claim-create.feature\')',
    '    * def claimId = create.response.claimId',
    '    Given path \'/claims\', claimId, \'adjudicate\'',
    '    When method POST',
    '    Then status 200',
    '    And match response.status == \'ADJUDICATED\'',
    '    * def body = read(\'data/<env>/TC-CLM-0142.json\')',
    '    * set body.amount = 500',
    '    Given path \'/claims\', claimId',
    '    And request body',
    '    When method PUT',
    '    Then status 409',
    '    And match response.errorCode == \'CLAIM_LOCKED\'',
    '    * configure afterScenario = function(){ karate.call(\'helpers/cleanup.feature\', { claimId: claimId }) }',
]
code(1040, Y1 + 50, 820, 290, "what comes back — one Scenario inside features/updateClaim.feature", feat2, stroke=BLUE, size=8.6, lh=13.2, hi={0: MUTED, 1: BLUE, 4: PURPLE, 11: PURPLE, 16: MUTED})

# ---------------------------------------------------------------- endpoints + files
Y2 = Y1 + 360
rect(40, Y2, 900, 168, "#ffffff", LINE, rx=10)
text(54, Y2 + 18, "Endpoints involved in this (all in scripts.py) — and what each one does", size=12, weight="700")
eps = [
    ("POST /suites/{id}/scripts:generate", "starts the build for a suite (normally automatic on approval); 202 with a job id"),
    ("GET  /suites/{id}/scripts", "one row per case: template or ai, valid / needs_attention, locked, commit id"),
    ("GET  /scripts/{id}", "the file text, read from Git at the pinned commit"),
    ("PUT  /scripts/{id}", "save an edited file: commit under the user's name, set locked=true (If-Match: row_version)"),
    ("POST /scripts/{id}/validate", "run the three checks on the current text and update validation_status"),
    ("POST /scripts/{id}/unlock", "let the generator overwrite the file again on the next build"),
    ("POST /suites/{id}/regenerate  (R2)", "rebuild with a comment and a scope (one case, one endpoint, or all); locked files untouched"),
]
for i, (a, b) in enumerate(eps):
    text(54, Y2 + 40 + i * 17, a, size=9, weight="700", font=MONO)
    text(330, Y2 + 40 + i * 17, b, size=9, fill=MUTED)

rect(960, Y2, 900, 168, "#ffffff", LINE, rx=10)
text(974, Y2 + 18, "The generated project in Git — one folder per workflow (test-assets repo)", size=12, weight="700")
tree = [
    ("workflows/claims/karate-config.js", "reads BASE_URL and AUTH_* from environment variables; nothing typed in"),
    ("  auth/token.feature", "gets one token per login profile per run and caches it"),
    ("  helpers/*.feature", "hand-written building blocks: mutate, claim-create, cleanup …"),
    ("  features/{endpoint}.feature", "GENERATED: one file per endpoint, one Scenario per case"),
    ("  data/{env}/{case_id}.json | .csv", "GENERATED: the request body / rows for that case in that environment"),
    ("  schemas/{Name}.json", "GENERATED: response schemas copied from the spec, for match"),
    ("  manifest.json", "GENERATED: suite id, spec version, case_id → file:line, template versions"),
]
for i, (a, b) in enumerate(tree):
    text(974, Y2 + 40 + i * 17, a.replace("  ", "\u00a0\u00a0"), size=9, weight="700" if "GENERATED" not in b else "normal", font=MONO, fill=INK if "GENERATED" not in b else BLUE_INK)
    text(1260, Y2 + 40 + i * 17, b, size=9, fill=MUTED)

# footer
text(40, H - 22, "Rule of thumb for the team: the JSON is the truth, the .feature is a rendering of it. If a script looks wrong, fix the template (or, for AI output, the prompt/example) — not the individual file — unless the QE deliberately locks it.", size=10, fill=MUTED, style="italic")

w("</svg>")
open("out/architecture-4a-case-to-feature.svg", "w").write("\n".join(out))
print("ok")
