# AI API Testing Platform — Solution Design

Sep 24, 2026 · @Advik

## Goal and v1 scope

An AI-powered product that lets QE engineers go from an API contract to approved test cases, Karate scripts, execution on GKE, Jira/Zephyr defects and a report. AI proposes, the QE approves, and execution stays deterministic.

| Area | v1 decision |
| --- | --- |
| Inputs | Swagger/OpenAPI required; sample payloads, Jira stories, CSV data, existing Karate suites optional |
| API types | REST and GraphQL first; Kafka as its own test type (produce, wait, consume, assert) |
| Framework | Karate, open source (Karate Agent is licensed and not used) |
| Execution | Karate runner in Kubernetes Jobs on our GKE; CI export in a later phase |
| Credentials | Token, client ID/secret held in GCP Secret Manager; never in prompts or scripts |
| PHI | Synthetic or masked data only; nothing unmasked reaches the LLM |
| Environments | Dev, QA, Staging; never Prod |
| Source of truth | The test case; scripts are generated from it and locked once a QE edits them |

AI is used in five places only: business rule extraction, test case design, semantic test data, Karate script generation, and failure triage. Everything else is deterministic services.

## End-to-end flow

The flow has 20 steps in six phases, with two loops: coverage drives test design, and a resolved defect drives a rerun.

```mermaid
flowchart TD
  A[Onboard<br/>Ingest, Smoke check] --> B[Understand<br/>Discover, Rules review]
  B --> C[Design<br/>Test design, Coverage]
  C -- gaps --> C
  C --> D[QE approval<br/>then Zephyr sync]
  D --> E[Build<br/>Test data, Scripts, Dry run]
  E --> F[Run<br/>Pre-flight, Execute, Results sync]
  F --> G[Triage<br/>then Defect review, Jira defect]
  G --> H[Rerun on fix]
  H --> F
  G --> I[Report]
```

| Phase | Step | Who does it |
| --- | --- | --- |
| Onboard | 1. Ingest | Deterministic |
| Onboard | 2. Smoke check and readiness report | Deterministic, human gate on red |
| Understand | 3. Discover | AI-assisted |
| Understand | 4. Rules review | Human gate |
| Design | 5. Test design | AI-assisted |
| Design | 6. Coverage analysis and contract validation (loops to 5) | Deterministic |
| Design | 7. QE approval with confidence routing | Human gate |
| Design | 8. Publish test cases to Zephyr | Deterministic |
| Build | 9. Test data | AI-assisted |
| Build | 10. Data review | Human gate |
| Build | 11. Karate script generation | AI-assisted |
| Build | 12. Dry run validation | Deterministic |
| Run | 13. Pre-flight check | Deterministic |
| Run | 14. Execute | Deterministic |
| Run | 15. Publish results to Zephyr | Deterministic |
| Run | 16. Failure triage | AI-assisted |
| Close loop | 17. Defect review | Human gate |
| Close loop | 18. Create Jira defect (deduplicated) | Deterministic |
| Close loop | 19. Rerun on fix (loops to 13) | Deterministic |
| Close loop | 20. Report | AI-assisted summary |

## Modules

Eight modules, each with one input artifact and one output artifact, so any team can start at any stage.

| Module | Steps | Input | Output | Standalone use |
| --- | --- | --- | --- | --- |
| M1 Intake | Ingest, Smoke check, Pre-flight | Raw inputs | Workflow package, readiness report | Validate contract and connectivity |
| M2 Discovery | Discover, Rules review | Workflow package | API model | Map an API's dependencies |
| M3 Test Design | Test design, Coverage, QE approval | API model | Approved test cases | Generate cases for one endpoint |
| M4 Test Data | Test data, Data review | Test cases, CSV, samples | Data sets per scenario | Map a CSV to an API |
| M5 Script Gen | Scripts, Dry run | Test cases, data | Karate project | Convert Zephyr cases to Karate |
| M6 Execution | Pre-flight, Execute, Rerun | Karate project, environment | Run results | Run an existing Karate suite |
| M7 Analysis | Triage, Report | Run results | Failure classification, report | Analyze a Karate report |
| M8 Integration | Zephyr sync, Results sync, Jira defect | Cases, results, defects | Synced Zephyr and Jira records | Used by other modules |

Design rules:

- Every module exposes its own REST API; the UI, CI pipelines and MCP clients are all consumers.
- Modules do not call each other; they read and write versioned artifacts in shared storage, and an orchestrator chains them.
- Providers sit behind interfaces: LLM (Gemini on Vertex AI), generator (ours, or Karate Agent later), defect tracker (Jira), test management (Zephyr).
- Multi-team from day one: projects, access control, per-team environments, secrets and coverage thresholds.

Cross-cutting services: orchestrator, secret store, PHI masking, audit log, access control.

M4, M6, M7 and M8 are engine-agnostic and can be reused by the Angular UI testing product with a Playwright execution engine.

## Human-in-the-loop gates

Five gates keep humans in control; two are always required (QE approval, defect review).

| Gate | What the human reviews | Required | How it stays fast |
| --- | --- | --- | --- |
| Smoke check | Readiness report | Only on red | Yellow warnings need acknowledgment only |
| Rules review | AI-extracted business rules, inferred dependencies | Recommended | Skipped when no Jira stories are given |
| QE approval | Test cases | Always | Confidence routing: bulk-approve high confidence, review low confidence one by one |
| Data review | CSV column mapping, synthetic data samples | Required when a CSV is uploaded | AI pre-fills the mapping; QE fixes mismatches |
| Defect review | AI triage result before a Jira defect is created | Always in v1 | Later: auto-create high-confidence product bugs |

- At every gate the QE can approve, edit, reject, or regenerate with a comment.
- Every decision is recorded, for the audit trail and as few-shot examples to improve generation.
- Scripts have no required gate: the dry run must pass, review is optional, and an edited script is locked from auto-regeneration.

## Where AI is used

AI does five jobs; everything else is deterministic code or a human decision. Deterministic always runs first, and AI handles only what rules cannot.

| Stage | AI | Deterministic | Human |
| --- | --- | --- | --- |
| 1 Ingest | None | Parse and normalize spec, secure credentials, PHI scan, smoke check, spec diff | Fix red readiness items |
| 2 Discover | Business rules from stories; ambiguous dependency edges; resource lifecycle | Endpoint inventory, field catalog, explicit and name-based dependencies, auth model, coverage universe | Confirm rules and low-confidence edges |
| 3 Test design | Business-rule cases, semantic boundary cases, cases aimed at coverage gaps | Structural, response code, schema, boundary, dependency and security cases from rules; coverage math; contract validation; dedup; confidence | None (next gate) |
| 4 Approval and Zephyr | Mapping imported free-text Zephyr steps | Review queue, confidence routing, Zephyr upsert and sync | Approve, edit, reject; lead accepts gaps |
| 5 Test data | CSV column mapping; consistent realistic values; turning a data requirement into catalog filters | Base payload, one-field mutations, schema validation of rows, catalog matching, allocation, unique suffixes, relative dates | Confirm CSV mapping; add missing records |
| 6 Scripts | Complex scenarios: business flows, state transitions, Kafka correlation; repair after a failed validation | Framework, config, auth, standard scenarios from templates; parse, static, contract checks; mock run | Optional script review |
| 7 Execution | None | Pre-flight, Kubernetes Jobs, Karate run, retry on network errors, evidence masking, Zephyr results | Start manual runs |
| 8 Triage and defects | Classify failures the signals cannot settle; explain; draft the defect | Signal-based classification, clustering, fingerprint dedup, Jira create, webhook rerun | Confirm defect; close it |
| 9 Reporting | Plain-language run summary | Every number and chart | Release decision |

## Stage 1: Ingest

Ingest collects everything about one API, stores it safely, and proves it is usable before any AI work starts. It uses no AI.

A QE creates a workflow, one per API or API group. It holds the name, owning team, owner, and environments (Dev, QA, Staging), each with its own base URL and credentials.

### Inputs

| Input | Required | Form |
| --- | --- | --- |
| API contract | Yes | OpenAPI/Swagger file or URL; GraphQL SDL or introspection endpoint |
| Environment config | Yes | Base URL per environment; auth type (OAuth2 client credentials, bearer token, API key) |
| Credentials | Yes | Client ID/secret or token, sent straight to the secret store; the workflow keeps a reference only |
| Sample payloads | No | JSON request per endpoint |
| Jira stories | No | Story IDs, an epic, or a JQL query |
| CSV test data | No | Uploaded file |
| Existing Karate suite | No | Git repo link or zip upload |
| Kafka config | No | Brokers, topics, schema registry (Avro or JSON schema), credentials |

### Processing

1. Store raw inputs, versioned; every Swagger upload is kept as a version.
2. Normalize the contract: resolve `$ref`s, convert Swagger 2.0 to OpenAPI 3, flag lint issues such as missing response schemas.
3. Secure credentials in GCP Secret Manager: never logged, never stored in plain text, never sent to an LLM.
4. Scan sample payloads and CSVs for PHI with GCP Sensitive Data Protection or rules; warn, mask or block.
5. Run the smoke check (below).
6. Produce a readiness report: green, yellow or red.

### Smoke check

The smoke check calls only safe endpoints (GET, health, read-only), never POST, PUT or DELETE. With no safe endpoint, it stops at connectivity and auth.

| Check | What it confirms |
| --- | --- |
| Spec validity | Swagger parses; no broken references or missing schemas |
| Connectivity | Base URL reachable from GKE: network, firewall, DNS, TLS |
| Authentication | Credentials return a token and the API accepts it |
| Contract conformance | Responses match the Swagger schema; undocumented fields or codes flagged as spec drift |
| Sample payload | Validates against the request schema |
| CSV | Headers map to schema fields; rows are well-formed |
| Kafka | Broker reachable, topics exist, credentials can consume |

The same component runs again, lighter, as the pre-flight before every execution.

### Human gate and output

The QE reviews the readiness report: red blocks until fixed, yellow needs acknowledgment. The output is the workflow package: normalized contract, input inventory, environment references and readiness report.

### Spec versioning and diff

When a new Swagger version is uploaded, Ingest compares it with the previous one and lists endpoints and fields added, removed or changed. Downstream modules update only the impacted test cases and scripts instead of regenerating everything.

### Edge cases

- Swagger URL behind auth: fall back to file upload.
- GraphQL introspection disabled: require an SDL file.
- Contract does not match the API: flagged yellow; the QE decides whether the spec or the API is wrong.
- Several APIs share one auth server: configure auth once per environment and reuse it.

## Stage 2: Discover

Discover turns the workflow package into an API model: one structured understanding of the API that every later module reads. Most of it is deterministic; AI is used for business rules and for dependencies that names alone cannot reveal.

### What the API model contains

| Part | Contents | Built by | Feeds |
| --- | --- | --- | --- |
| Endpoint inventory | Per operation: method, path, parameters, request schema, responses, auth scopes, tags, and safety (safe, idempotent or mutating) | Deterministic | Structural and response code coverage |
| Field catalog | Every request and response field flattened to a path (patient.address.zip) with type, required, format, enum, min/max, example | Deterministic | Schema and boundary coverage, test data |
| Dependency graph | Operations as nodes; an edge when one operation's output feeds another's input | Deterministic, then AI | Dependency coverage, execution order |
| Resource lifecycle | Resources and their states, such as claim: created, submitted, adjudicated, closed | AI from stories, confirmed by QE | Business flow tests |
| Business rules | Structured rules with source, affected endpoints and fields, type, confidence | AI from Jira stories | Business and negative tests |
| Auth model | Auth type, scopes per operation, roles where known | Deterministic, plus QE input | Security coverage |
| Event catalog | Kafka topics, message schema, which operation publishes, correlation key | Deterministic from schema registry, AI for links | Kafka tests |
| Coverage universe | The denominator for each of the six coverage dimensions | Deterministic | Coverage analysis |

### Building the dependency graph

Edges come from three sources, in order of trust. Each edge records its source and a confidence score.

1. Explicit: OpenAPI `links`, and a response field that exactly matches another operation's path parameter.
2. Heuristic: name and path patterns, such as POST /claims returning `claimId` and GET /claims/{claimId}, or nesting like /members/{memberId}/claims.
3. AI inference: ambiguous names (`referenceNumber` feeding `trackingId`) and workflows described in stories.

From the graph, Discover derives the prerequisites for each operation (to test GET /claims/{claimId}, a claim must be created first), a safe execution order, and cleanup steps such as delete after create. Low-confidence edges go to the rules review gate.

### Prerequisite data

Decision: QA provides domain data, and the product matches it to test cases and shows the user which record each test case uses. Tests still create their own records through the API where that is allowed (for example claims); catalog records cover what cannot be created (for example members from the eligibility feed).

1. Data catalog: QA uploads domain records (for example memberId, plan type, coverage status, state, age). The product profiles the attributes, values and record counts per group.
2. Data requirement per test case: each case states what it needs in plain terms, such as an active member or a claim in ADJUDICATED status.
3. Matching: deterministic attribute filters; AI only translates requirements into filters (a senior member becomes age >= 65).
4. Transparency: every test case shows the record ID, key attributes, and why it was chosen. This appears at QE approval, in the report, and in Jira defects.
5. Gaps: when no record fits, the case is marked blocked with the exact record QA needs to add.
6. Consumption: read-only tests share records; tests that change state get their own record, allocated per run.
7. PHI: domain data is synthetic or masked; the LLM sees attribute names and value profiles only.

### Extracting business rules

AI reads the Jira stories (description and acceptance criteria) and writes each rule in a fixed structure:

| Field | Example |
| --- | --- |
| Rule | A claim cannot be updated after it is adjudicated |
| Condition and outcome | claim.status = ADJUDICATED and PUT /claims/{claimId} returns 409 |
| Type | State transition (others: validation, authorization, calculation) |
| Applies to | PUT /claims/{claimId}; field claim.status |
| Source | Story ID and the sentence it came from |
| Confidence | High, medium or low |

Discover also flags conflicts between the spec and the stories, for example a story that makes a field required when the spec marks it optional. Each conflict is a finding for the team, not only a test input.

### Existing Karate suites

When a suite is provided, Discover parses its features to record which endpoints are already covered, which reusable features exist (auth, helpers), and the team's style. The result is a coverage baseline and a set of style examples for script generation.

### REST, GraphQL and Kafka

- REST: operations come from paths and methods.
- GraphQL: each query and mutation is an operation; dependencies come from mutation return types feeding query arguments.
- Kafka: each topic is an event with a schema; an edge links the API operation that publishes it to the test that consumes and asserts it.

### Human gate: rules review

The QE sees the extracted rules and the medium and low-confidence dependency edges. They confirm, edit or reject each one, and can add rules the stories never wrote down. Confirmed rules become the source of truth for test design; rejected ones are kept for audit.

### Output

The API model, versioned with the spec version. When the spec changes, the model diff shows which rules, edges and coverage targets are affected.

### Standalone use

The API model is useful on its own as a dependency map and rules catalog for an API, even for teams that never generate a test.

## Stage 3: Test design and coverage

Test design turns the API model into draft test cases in one canonical format. Coverage then measures them against the API model and loops back until the thresholds are met. A rule engine generates most cases; AI adds business and semantic cases and fills the gaps coverage finds.

### Canonical test case model

This is the contract every later module depends on: data, scripts, Zephyr, execution and reporting all read it.

| Field | Meaning | Example |
| --- | --- | --- |
| ID, title | Stable identity | TC-0142: Reject update of adjudicated claim |
| Operations | One endpoint, or an ordered chain | PUT /claims/{claimId} |
| Type | Positive, negative, boundary, security, business flow, Kafka | Negative |
| Coverage targets | What it covers, per dimension | Response code 409; rule R-12; field claim.status |
| Preconditions | Prerequisite steps from the dependency graph | Create claim, move it to ADJUDICATED |
| Data requirement | What record it needs, in plain terms | A claim in ADJUDICATED status |
| Request variation | How the request differs from the valid base payload | amount changed to 500 |
| Expected result | Status, response assertions, side effects | 409, error code CLAIM\_LOCKED, no event published |
| Origin and source | Rule engine, AI, imported or manual; the rule or story it came from | AI, from rule R-12 (story ID) |
| Confidence | High, medium or low, with the reason | Medium: AI from a confirmed rule |
| Priority | P1 to P3 by business risk and usage | P1 |
| Status and links | Draft, approved or rejected; Zephyr key; Jira story; locked flag | Draft |

### Who generates what

| Dimension | Generator | What gets generated |
| --- | --- | --- |
| Structural | Rule engine | One positive case per endpoint and method |
| Response code | Rule engine, AI for business codes | One case per documented code: 400 invalid input, 401 no token, 403 wrong scope, 404 unknown ID, 409 and 422 from rules |
| Schema | Rule engine | Per request field: missing if required, null, wrong type. Response field assertions ride on positive cases rather than separate cases |
| Boundary | Rule engine, AI for semantic cases | Per constraint: min-1, min, max, max+1, empty, invalid enum, invalid format; AI adds cases such as a birth date in the future |
| Dependency | Rule engine from the graph | CRUD lifecycle chains, prerequisite chains, wrong-order and deleted-ID cases |
| Security | Templates, opt-in per environment | No, expired or wrong-scope token; another member's record (object-level authorization); injection strings; extra fields; sensitive fields in responses |
| Business rules | AI from confirmed rules | At least one positive and one negative case per rule |
| Kafka | Rule engine and AI | The API action publishes the expected event with the right key and payload |

Some codes cannot be triggered on purpose, such as 500 or 503. They are marked not triggerable, with a reason, and left out of the coverage denominator.

### Keeping the suite a usable size

A 50-endpoint API with 30 fields each can produce thousands of cases. Four controls keep it reviewable:

1. Field-level negatives for one endpoint become one data-driven case with many rows, not dozens of cases; in Zephyr it is one test case with parameterized data rows.
2. Duplicates are merged: the same operation with the same assertion is one case.
3. Every case gets a priority, so P1 runs first and P3 can be trimmed.
4. A per-endpoint cap is configurable per team.

### Design-time coverage

Each dimension is measured as covered targets divided by the universe from the API model. The thresholds below are the agreed defaults, configurable per team.

| Dimension | Target unit | Suggested threshold |
| --- | --- | --- |
| Structural | Endpoint and method | 100% |
| Response code | Documented, triggerable code per operation | 90% |
| Schema | Request field per operation | 100% of required fields, 80% of optional |
| Boundary | Constrained field | 80% |
| Dependency | High-confidence edge | 100% |
| Security | Protected operation (auth checks) | 100% |
| Business rules | Confirmed rule | 100% |

The coverage view is a matrix: endpoints as rows, dimensions as columns, gaps highlighted.

### Contract validation

Every draft case is checked against the spec before a human sees it. Cases expecting an undocumented status, asserting fields that do not exist, or labeled positive with an invalid request are rejected as hallucinations and regenerated.

### The coverage loop

1. Coverage lists the gaps, such as no 409 case for PUT /claims/{claimId}.
2. The rule engine or AI generates cases aimed at exactly those gaps.
3. Coverage re-measures. After three rounds, remaining gaps go to the QE as accepted gap or needs input.

### Confidence scoring

| Confidence | When |
| --- | --- |
| High | Rule engine case from an explicit spec constraint |
| Medium | AI case from a QE-confirmed rule |
| Low | AI case from an inference with no confirmed rule, or an expected result the spec does not document |

Confidence drives routing at the QE approval gate.

### Output

A draft test suite in the canonical model plus the design-time coverage report. Both go to the QE approval gate.

## Stage 4: QE approval and Zephyr publishing

The QE approves the draft suite through a review queue that routes by confidence. Approved cases are then published to Zephyr, linked to their Jira stories, and kept in sync from our product as the source of truth.

### Review queue

Cases are grouped by endpoint, then by confidence, so the QE spends time where the AI is least certain.

| Confidence | How it is reviewed |
| --- | --- |
| High | Bulk approve per endpoint or dimension, after spot-checking a few |
| Medium | One by one, with the source rule shown beside the case |
| Low | One by one, with the reason it is low shown; cannot be bulk approved |

Each case shows its plain-English steps, expected result, source rule or story, data requirement and the record bound to it, and the coverage targets it hits.

### Actions

- Approve, or edit inline and then approve.
- Reject with a reason.
- Regenerate with a comment, such as add a case for an expired token.
- Add a manual case, recorded with origin manual.

The coverage matrix updates live. If rejecting a case drops a dimension below its threshold, the QE sees it immediately.

### Roles

| Role | Can do |
| --- | --- |
| QE | Review, edit, approve and reject cases |
| QE lead | Everything a QE can do, plus accept coverage gaps and change thresholds |

Accepted gaps need a QE lead, so a gap is never waved through silently.

### Ready to publish

The suite can be published when every P1 case is reviewed and every dimension meets its threshold or has an accepted gap. P2 and P3 cases still in draft can be published later.

### Zephyr mapping

| Our field | Zephyr field |
| --- | --- |
| Title | Test case name |
| Steps and expected result | Test script steps with expected results |
| Data rows | Parameterized test data |
| Priority | Priority |
| Type and coverage targets | Labels |
| Jira story | Traceability link to the story |
| Workflow and endpoint | Folder |
| Our case ID, origin, confidence | Custom fields |

### Sync rules

1. Our product is the source of truth; each case stores its Zephyr key.
2. Publishing is an upsert by our case ID, so republishing never creates duplicates.
3. A changed case (for example after a spec diff) updates the existing Zephyr case, not a new one.
4. Rejected or retired cases are marked deprecated in Zephyr, never deleted, to keep execution history.
5. Edits made directly in Zephyr are detected and shown to the QE, who chooses to import or overwrite them.
6. Zephyr API failures and rate limits go to a retry queue, and the QE sees a publish report of what landed.

### Importing from Zephyr

Teams with existing Zephyr cases can import them into the canonical model and enter the flow here. AI maps free-text steps to operations and expected results, and imported cases go through the same review queue.

### Output

Approved test cases with Zephyr keys and Jira story links: the input to test data and script generation.

## Stage 5: Test data

For every approved case, Test data builds the exact request values and the prerequisite records it will run with, and shows the QE that binding. Most data is produced by rules and mutation; AI maps CSVs and supplies realistic values where rules cannot.

### Two kinds of data

| Kind | What it is | Where it comes from |
| --- | --- | --- |
| Request data | The values sent in the request | CSV rows, sample payload, schema rules, AI for semantic values |
| Prerequisite records | Records that must already exist for the case to run | QA data catalog, or created through the API during the run (see Stage 2, Prerequisite data) |

### Building request data

1. Base payload: the QE's sample payload. Without one, a minimal valid payload is built from the schema: required fields, enums, formats and examples.
2. Realistic values: a synthetic data generator fills names, addresses and dates; AI is used only for values that must be consistent with each other, such as a zip code that matches the state.
3. Variations: each negative or boundary case is the base payload plus exactly one mutation (for example dob set to tomorrow). One change per case means a failure always points to one field.

### CSV flow

1. The QE uploads a CSV.
2. AI proposes a column-to-field mapping from the headers and a few masked rows, such as mbr\_id to memberId.
3. The QE confirms or fixes the mapping at the data review gate.
4. Each row is validated against the schema, so bad data is flagged as a data problem, not a test failure.
5. Rows are classified: an expected\_status column makes a row positive or negative; without it, schema validation proposes the class and the QE confirms.
6. Gap analysis lists what the CSV misses (for example no null groupId, no boundary dates) and offers generated rows to fill it.
7. Rows attach to data-driven cases as parameterized data.

Optional CSV columns: expected\_status, expected\_error, description, and test\_case\_id to tie a row to one case.

### Prerequisite records

Cases are matched to QA catalog records by attribute, as decided in Stage 2. Read-only cases share records; state-changing cases get their own record allocated per run. When no record fits, the case is marked blocked with the exact record QA needs to add.

### Runtime values

Values created during a run, such as the claimId returned by POST /claims, are defined here as placeholders and filled in at execution. This is what lets dependency chains pass data from one call to the next.

### Practical rules

| Rule | Why |
| --- | --- |
| Data sets and catalogs are per environment | Member IDs in QA differ from Staging |
| Dates are stored as relative expressions, such as today minus 30 days | Data never goes stale |
| Fields that must be unique get a run-specific suffix | Reruns do not fail with 409 duplicate |
| Data is synthetic or masked, stored encrypted | PHI safety |
| The LLM sees headers, masked samples and value profiles only | No full records reach the model |

### Human gate: data review

- CSV mapping: required when a CSV is uploaded.
- A sample of generated values per endpoint: optional spot-check.
- Blocked cases: the list of records QA needs to add.

### Output

A versioned data set per case and environment: base payload, variations, data rows, runtime placeholders and bound records, stored in a form Karate reads directly (JSON and CSV).

## Stage 6: Karate script generation and dry run

Script generation turns approved cases and their data sets into a Karate project. Templates produce most of it; the LLM writes only what templates cannot express. Every script is validated before a QE sees it.

### Karate project structure

| Part | Purpose |
| --- | --- |
| Environment config | Base URL and auth settings per environment, read from variables injected at run time; no secrets in files |
| Auth feature | Gets a token once per run and shares it with every scenario |
| Helper features | Reusable prerequisite chains and cleanup, such as create a claim and move it to ADJUDICATED |
| Feature files | One per operation; one scenario per test case; data-driven cases as scenario outlines |
| Data folder | Base payloads and data rows per case and environment, from Stage 5 |
| Schemas folder | Response schemas taken from the spec, for schema matching |
| Kafka helper | A small Java library for produce and consume-with-timeout, called from Karate; built once, reused everywhere |

Every scenario is tagged with its case ID, Zephyr key, priority and type. Tags let the runner execute any subset: one case, all P1, or only the cases linked to a defect.

### Karate reference framework

The LLM never generates the framework. Engineers build one reference Karate framework once, and the LLM only writes scenarios inside it.

| Part | What it holds |
| --- | --- |
| Framework skeleton | Config, auth, helper conventions, folder layout, tagging rules, Kafka helper |
| Pattern library | One worked example per pattern: CRUD chain, positive with schema match, field negatives as an outline, prerequisite chain with cleanup, GraphQL query, Kafka publish-and-assert |
| Conventions guide | Naming, assertion style, how to call helpers, what never to hardcode |
| Templates | The pattern examples turned into fill-in templates for the rule engine |

The pattern examples are the LLM's few-shot examples and the conventions guide is part of its instructions, so generated scenarios look like the reference. It is built and proven against one pilot API before any generation work starts, and it is versioned in the test assets repo. Teams' existing suites and QE-edited scripts are added as further examples over time.

### Templates first, LLM second

| Part | How it is generated |
| --- | --- |
| Project skeleton, config, auth, schemas, data files | Templates |
| Standard scenarios: status check, schema match, field negatives as outlines | Templates filled from the canonical case |
| Business flows, state transitions, computed assertions, Kafka correlation | LLM |

The LLM receives the canonical case, the relevant slice of the spec, the list of available helper features, and style examples from the team's existing suites and QE-edited scripts. Templates stay consistent, cheap and free of hallucination, so the LLM handles only the harder minority of scenarios.

### Validation before review

1. Parse check: every feature parses, called features exist, and every variable resolves.
2. Static checks: no hardcoded URLs, secrets or PHI; tags present; auth comes from the shared feature.
3. Contract check: every asserted status and field exists in the spec.
4. Mock run (recommended): the suite runs against a Karate mock server built from the spec, which proves the script logic works without touching a real environment.
5. Repair: on failure, the LLM gets the error and fixes the script, up to two attempts. After that the scenario is flagged needs attention for the QE.

### Edits, locking and versioning

- All Karate projects live in one Git repository owned by the product, with one folder per workflow, kept separate from the product's own source code; each generation is a commit. This gives diffs, history, and a ready path to CI export later.
- The QE can review scripts side by side with their test cases and edit them in the product.
- An edited scenario is locked. If its test case later changes, the QE sees a flag with the case diff instead of an overwrite.
- After a spec change, only scenarios affected by the spec diff are regenerated.

### GraphQL and Kafka

- GraphQL: queries and variables are stored as files and sent through the same scenario structure.
- Kafka: scenarios call the Kafka helper to wait for the expected event, match it by correlation key, and assert its payload.

### Human gate

None required. The review is optional, and the validation steps above must pass.

### Output

A validated, tagged, versioned Karate project per workflow: the input to execution.

## Stage 7: Execution on GKE

Each run executes a tagged subset of the Karate project as an isolated Kubernetes Job in our GKE cluster, after a pre-flight check. No AI is involved, so every run is reproducible.

### Triggers and scope

| Trigger | Typical scope |
| --- | --- |
| Manual, by a QE | Any tag selection: all, P1, one endpoint, one case |
| Schedule, such as nightly | Full regression |
| Jira defect resolved (webhook) | Cases linked to that defect, plus cases on the same endpoint and dependency chain |
| Deploy event (CI calls the product API) | The suite for the deployed API |
| Rerun failed | Cases that failed or errored in a chosen run |

### Run lifecycle

1. Request: workflow, environment, scope and who or what triggered it.
2. Pre-flight: connectivity, token, one safe call, Kafka reachability, and allocation of consumable catalog records. Blocked cases are excluded with their reason. If the environment is not healthy, the run stops as environment not ready instead of reporting hundreds of failures.
3. Launch: a Kubernetes Job from the runner image (Java, Karate standalone runner, Kafka helper). It checks out the workflow folder at a pinned commit and loads the data set for that environment. Secrets are injected as environment variables from Secret Manager.
4. Execute: Karate's parallel runner, with a timeout per case and bounded waits for Kafka events. Large suites are split across several pods by feature.
5. Collect: Karate JSON, JUnit XML and HTML reports, plus the request and response for every call. Tokens and sensitive fields are masked before anything is stored.
6. Clean up: helper teardown removes created data, allocated records are released, and the pod is deleted.
7. Hand off: results go to Zephyr and to failure triage.

### Isolation and safety

- Runner pods live in their own namespace, with CPU and memory limits.
- Network policies allow only the target environment's hosts; there is no route to Prod.
- A concurrency limit per environment keeps runs from overloading shared QA systems.
- Security tests run only where the environment allows them.

### Result states

| State | Meaning |
| --- | --- |
| Passed | All assertions held |
| Failed | An assertion did not hold |
| Error | The script or environment broke before the assertion could be checked |
| Flaky | Failed with a network or 5xx error, then passed on one automatic retry |
| Skipped | Excluded by scope |
| Blocked | No matching data, or pre-flight excluded it |

Only network and 5xx errors get an automatic retry; assertion failures never do. A case that passes on retry is reported as flaky, not passed, and the flaky rate is tracked per case.

### Run record

Every run stores its ID, workflow, environment, spec version, script commit, data set version, trigger, start and end time, and per-case state, duration and evidence. Pinning the commit and data version means any run can be repeated exactly.

### Zephyr results sync

Each run is published as a Zephyr test cycle named by workflow, environment and date. Each case's state maps to a Zephyr execution status, with a link to its evidence in the product. Flaky and blocked cases carry a comment explaining why.

### Output

The run record and evidence: the input to failure triage and reporting.

## Stage 8: Failure triage, Jira defects and rerun

Triage classifies every failure so that only confirmed product bugs become Jira defects. Each defect is deduplicated, linked to its story and test case, and carries the evidence to reproduce it. When a defect is resolved, a rerun closes the loop.

### Triage inputs

For each failed or errored case: the masked request and response, the expected result and assertion error, the test case and the rule it came from, the spec, the case's history in earlier runs, the pre-flight result, and the other failures in the same run.

### Classification

Deterministic signals are checked first; AI classifies what they cannot settle and explains its reasoning in plain language with a confidence score.

| Category | Typical signal | What happens next |
| --- | --- | --- |
| Product bug | API response violates the spec or a confirmed rule | Defect review, then a Jira defect |
| Contract drift | Undocumented field, status or format in the response | QE chooses: Jira defect, or spec update |
| Test issue | Script error before the request was sent, or a wrong expectation | Back to test design or script generation, with the failure as context |
| Data issue | 404 on a bound record, 409 duplicate, record in an unexpected state | Flagged for catalog or data fix; no defect |
| Environment issue | Timeouts, 502 to 504, connection refused, 401 on every case | Environment owner notified; rerun later; no defect |
| Flaky | Passed on retry | Tracked; a defect only when the flaky rate passes a threshold |

### Clustering

Failures with the same root cause are grouped into one triage item. If 40 cases fail with the same 500 from POST /claims, the QE reviews one item and one defect is raised, listing all 40 cases.

### Human gate: defect review

The QE sees the category, confidence, AI explanation and evidence. They can reclassify, edit the defect draft, or dismiss it. Every reclassification is recorded as feedback to improve triage.

### Jira defect content

| Part | Contents |
| --- | --- |
| Summary | One line: operation, what went wrong, such as PUT /claims/{claimId} accepts update of adjudicated claim |
| Description | Expected versus actual, the business rule it breaks, steps to reproduce, the data record used, environment, and a link to the run |
| Attachments | Masked request and response, the relevant Karate log |
| Fields | Component (the API), severity from case priority and category, labels for the product and workflow |
| Links | Jira story (relates to), Zephyr test case and execution |

### Deduplication

Each failure gets a fingerprint: operation, assertion type and normalized error (status, error code, message pattern).

- Open defect with the same fingerprint: add a comment with the new occurrence instead of a new defect.
- Closed defect with the same fingerprint: raise a new defect marked as a possible regression, linked to the old one.

### Rerun loop

1. A Jira webhook fires when a defect moves to the team's ready-for-QA status (status names configurable per team).
2. The rerun covers the linked cases plus cases on the same endpoint and dependency chain.
3. All pass: the product comments on the defect with evidence and updates Zephyr. Closing the defect stays with the QE.
4. Still failing: the product comments with the new evidence and moves the defect back to reopened.
5. New failures nearby: they enter triage as possible regressions introduced by the fix.

Ready for QA means the fix is ready for testing. Jira's webhook sends only the defect key and new status; the product already knows which cases are linked to the defect it raised. Pre-flight records the deployed build version where the API exposes one, so each rerun result names the build it tested.

### Jira access

A service account with permission only for the projects in use, through Jira and Zephyr REST APIs or the Atlassian MCP server (open decision).

### Output

Triage records, Jira defects and rerun results: the inputs to reporting.

## Stage 9: Reporting

Reporting turns runs, coverage and defects into four views for different readers. Every number is computed deterministically; AI only writes the plain-language summary and never calculates a metric.

### Views by audience

| View | Reader | Question it answers |
| --- | --- | --- |
| Run report | QE | What failed, why, and what to do next |
| Workflow dashboard | QE lead | Is this API's suite healthy over time |
| Portfolio dashboard | Engineering and product leadership | Which APIs are below coverage or quality thresholds |
| Release readiness | Release decision makers | Is this API ready to ship |

### Run report

1. AI summary: three to five sentences, such as pass rate, the product bugs found and where, environment problems, and the recommended next step.
2. Counts by state: passed, failed, error, flaky, skipped, blocked.
3. Run-time coverage per dimension, as planned, executed and passed, with the endpoint-by-dimension matrix.
4. Failures grouped by triage category and cluster, with defects raised or updated.
5. Blocked cases, with the data QA needs to add.
6. Change since the previous run: new failures, fixed, still failing.
7. Per-case drill-down: masked request and response, data record used, assertions, Karate log.

### Workflow dashboard

Trends across runs for one API: pass rate, coverage per dimension, flaky rate, open defects by severity, time from defect raised to verified fix, spec drift findings, and cases blocked by data.

### Portfolio dashboard

Across all workflows: coverage per API, APIs below threshold, and open defects by team. It also measures the product itself:

| Metric | What it shows |
| --- | --- |
| AI acceptance rate | Share of generated cases approved without edits |
| Edit rate | Share of cases or scripts the QE had to change |
| Triage accuracy | Share of AI classifications the QE did not reclassify |
| Workflows onboarded | Adoption across teams |

### Release readiness

A green, yellow or red summary per API and release: P1 pass rate, open critical defects, coverage thresholds met, and security checks passed. It is advice for the release decision, not an automatic gate.

### Delivery

- Dashboards and run reports in the product, each run with a shareable link.
- Export as PDF or HTML; Karate's own HTML report is kept as raw evidence.
- A summary notification on run completion to Teams or email.
- Results are already in the Zephyr test cycle from Stage 7.

### Output

Reports and dashboards. This is the last stage of the flow; the next step is the architecture.

## Architecture

Four deployables on GKE: an Angular web app, one Python codebase run as two process types (a FastAPI platform API and LangGraph AI workers), and Karate runner jobs. Java appears only inside the runner image, because Karate needs it. Pub/Sub connects the long-running work. The eight modules are logical boundaries inside these deployables, not eight microservices.

```mermaid
flowchart LR
  UI[Angular web app] --> P[Platform API<br/>Python FastAPI]
  P --> DB[(Cloud SQL PostgreSQL<br/>+ pgvector)]
  P --> GCS[(Cloud Storage)]
  P --> GIT[(Test assets Git repo)]
  P -- jobs --> PS[Pub/Sub]
  PS --> AI[AI workers<br/>Python LangGraph]
  AI --> DB
  AI --> LLM[LLM<br/>Gemini on Vertex AI]
  P -- launches --> R[Karate runner<br/>Kubernetes Jobs]
  R --> T[APIs and Kafka<br/>under test]
  R -- results --> PS
  P <--> J[Jira and Zephyr]
```

The platform API owns every human gate; AI workers share the same code and database but only produce drafts; runners only execute.

### Components

| Component | Technology | Responsibility |
| --- | --- | --- |
| Web app | Angular | Workflow setup, review queues, coverage matrix, script editor, reports |
| Platform API | Python, FastAPI, Pydantic, SQLAlchemy | Modules M1 to M8 as packages: intake, API model, rule engine and coverage, data rules, templates and validation, run orchestration, reporting, Jira and Zephyr integration; workflow state, access control, audit |
| AI workers | Python, LangGraph, same codebase as the platform API | Graphs for rule extraction, test design, CSV mapping, script generation and repair, and failure triage; call the rule engine, coverage and contract validation directly in-process |
| Runner | Kubernetes Jobs; image with Java, Karate standalone runner, Kafka helper | Executes runs, and validates generated scripts with parse checks and mock runs |
| Messaging | Pub/Sub | AI job requests and results, run completion events, inbound Jira webhooks |
| Database | Cloud SQL PostgreSQL with pgvector | Workflows, API model, rules, cases, data catalogs, runs, results, triage, audit; story and example embeddings |
| Object storage | Cloud Storage | Raw inputs, CSVs, masked evidence, exported reports |
| Test assets | Product-owned Git repo | Karate projects, one folder per workflow |
| Secrets | Secret Manager with Workload Identity | Target API credentials, Jira service account; no keys in pods |
| PHI guard | Sensitive Data Protection (DLP) | Scans uploads and every LLM request |
| LLM | Gemini on Vertex AI, behind a provider interface; a faster model for mapping and triage, a stronger one for test design and scripts | Called only by AI workers |

### Why Pub/Sub is used, and where it is not

AI jobs take seconds to minutes and runs take minutes, so they cannot sit on an HTTP request. Pub/Sub gives retries and lets AI workers and runners scale on their own. Everything else is plain REST between the web app and the platform service. Four topics are enough: ai-jobs, ai-results, run-events, jira-events.

### Example request flow: generate test cases

1. The QE clicks generate in the web app; the platform API creates a job and publishes it to ai-jobs.
2. An AI worker runs the test design graph. It calls the rule engine, coverage and contract validation directly in-process, since they share one codebase.
3. Drafts are saved to the database, and the job-done event goes to ai-results.
4. The platform API pushes a live update to the web app, and the cases appear in the review queue.

Human gates live in the platform API, not inside LangGraph. Each graph runs to completion and stops; the next graph starts only after the QE approves. This keeps graphs short-lived and easy to retry.

### Deployment on GKE

| Namespace | Runs |
| --- | --- |
| app | Web app and platform API |
| ai | AI workers |
| runners | Karate runner jobs, on their own node pool, with network policies that allow only target environments |

Deployed with Helm through the company's standard CI/CD. The product itself has its own dev, staging and prod environments, separate from the environments it tests.

### AI loops and evaluation harness

Each AI capability is a small LangGraph graph with explicit steps, bounded loops and validated outputs, not an open-ended autonomous agent.

| Graph | Loop | Limit |
| --- | --- | --- |
| Test design | Generate, measure coverage, target the gaps | 3 rounds |
| Script generation | Generate, validate (parse, contract, mock run), repair | 2 repairs |
| CSV mapping | Propose mapping, validate against schema | 1 retry |
| Rule extraction and triage | Single pass with structured output | None |

Rules every graph follows:

- Outputs are validated against a schema (Pydantic); an invalid output is retried, then failed, never passed on.
- Tools are deterministic functions from the shared codebase, called in-process: API model slice, coverage, contract validation, catalog query, Karate parse and mock run. MCP is not needed inside the product in v1.
- Context is a slice, never the whole spec: the operation, its schemas, the confirmed rules, and a few approved examples retrieved from pgvector.
- Every LLM call passes the PHI guard and carries a token budget and timeout per job.

The evaluation harness is a golden set of three to five representative internal APIs with known-good test cases and labeled failures. Every prompt, model or graph change runs against it in the product's CI and must not regress on these measures:

| Measure | Meaning |
| --- | --- |
| Contract validity | Share of generated cases that pass contract validation |
| Coverage reached | Coverage after the loop, per dimension |
| Duplicate rate | Share of generated cases merged as duplicates |
| Script pass rate | Share of scripts that pass validation without repair |
| Triage accuracy | Share of labeled failures classified correctly |

In production, the acceptance, edit and triage accuracy metrics from Stage 9 show the same thing from real use.

### Scalability

| Part | How it scales |
| --- | --- |
| Platform API | Stateless replicas with a Horizontal Pod Autoscaler |
| AI workers | More Pub/Sub consumers as the backlog grows; a rate limiter keeps calls inside the LLM quota |
| Runners | One Job per run, split across pods for large suites; a dedicated node pool with the cluster autoscaler; a concurrency limit per target environment |
| Database | Cloud SQL, with a read replica for dashboards when needed |
| Large specs | Processed in slices by resource or tag |

### Sizing

About 2,000 APIs in the first year, with runs on every deploy and every regression. The figures below are estimates; the endpoint count per API and deploy frequency are assumptions to confirm.

| Measure | Estimate | Basis |
| --- | --- | --- |
| APIs onboarded | About 40 a week | 2,000 a year |
| Test cases | 300,000 to 600,000 | 150 to 300 cases per API after consolidation (assumes about 20 endpoints per API) |
| Cases to review | About 8,000 a week | 40 APIs a week at about 200 cases each |
| Runs | Several hundred a day, peaking in release windows | Each API deployed about weekly, plus regression runs |

What this changes:

1. AI cost follows onboarding and spec changes, not runs, because execution uses no AI. This is what makes 2,000 APIs affordable. Vertex AI quota needs to be requested up front, and bulk onboarding runs through the rate-limited queue.
2. Human review is the real bottleneck. Confidence routing and bulk approval are required from the MVP, and each API's cases are reviewed by its owning team's QE, not a central group.
3. Onboarding must be self-service and support bulk import of specs from the API catalog or gateway, not one upload at a time.
4. Deploy-triggered runs come from CI pipelines calling the product API, so CI export is not needed for v1. The runner node pool autoscales, can use spot nodes for cost, and keeps its per-environment concurrency limits.
5. Evidence volume is large: Cloud Storage lifecycle rules keep full evidence for a set period (for example 90 days) and summaries longer; results tables are partitioned by month.
6. Zephyr receives hundreds of thousands of cases: publishing is asynchronous, batched and within API rate limits.
7. One test assets repo with 2,000 folders is workable to start; move to per-team repos if permissions or size require it.
8. The platform is multi-tenant from day one, since the UI testing product and later other applications share it.

### Observability

- Logs: structured JSON to Cloud Logging from Java, Python and runners, all carrying workflow ID, run ID and job ID so one request can be followed end to end.
- Traces: OpenTelemetry in the platform API and AI workers, sent to Cloud Trace or the company's existing APM tool.
- Metrics: job duration, queue backlog, run pass rate, and for the LLM: latency, tokens, cost and error rate per graph.
- LLM audit: every prompt and response is stored masked with its job, for audit and debugging. A self-hosted LLM tracing tool such as Langfuse can be added later; SaaS tracing is avoided because of PHI.
- Alerts: failed jobs, growing backlog, LLM errors, runner failures, environment not ready.
- The audit log (who approved, edited or rejected what) is kept separately from application logs.

### Security

- Company SSO through OIDC; roles (QE, QE lead, admin) enforced in the platform API.
- Workload Identity for every pod; secrets from Secret Manager, never logged.
- Network policies: runners reach only target test environments; no route to Prod.
- The PHI guard on uploads and on every LLM call; evidence masked before storage.

### What we are not building in v1

- A microservice per module: one modular monolith, split later only if a module needs to scale on its own.
- Neo4j or a separate vector database: PostgreSQL with pgvector.
- Kafka for internal messaging: Pub/Sub; Kafka appears only as a system under test.
- A multi-agent swarm: five bounded graphs.
- A service mesh, unless the cluster already has one.

### Build order

| Release | Scope |
| --- | --- |
| MVP | Ingest and smoke check, Discover for REST, rule engine test design and coverage, QE review, template Karate scripts, execution on GKE, run report |
| Release 2 | AI business rules and test design, CSV and data catalog, Zephyr sync, LLM scripts with repair, evaluation harness |
| Release 3 | Triage, Jira defects and rerun loop, GraphQL, Kafka tests, dashboards and release readiness |

## Data model

Fourteen core entities, plus five supporting ones, hold everything the product remembers. They live in PostgreSQL, with flexible parts in JSONB and large files in Cloud Storage. The same entities serve the Angular UI testing product, because test targets and test cases are engine-agnostic.

```mermaid
flowchart TD
  TM[Team] --> WF[Workflow]
  WF --> EN[Environment]
  WF --> SV[Spec version]
  SV --> TG[Target<br/>operation or screen]
  TG --> DE[Dependency edge]
  SV --> BR[Business rule]
  TG --> TC[Test case]
  BR --> TC
  TC --> SC[Script]
  TC --> DR[Data record<br/>via binding]
  WF --> RN[Run]
  RN --> RS[Result]
  RS --> TI[Triage item]
  TI --> DF[Defect]
```

Read top to bottom: a team owns workflows; each spec version defines targets and rules; test cases hang off targets and rules; runs produce results that roll up into triage items and defects. Each result also points back to its test case.

### Core entities

| Entity | What it is | Key fields | Links to |
| --- | --- | --- | --- |
| Team | Tenant; every other row belongs to one | Name, members and roles | Workflows |
| Workflow | One API (or one UI application) under test | Name, type (api or ui), owner, status | Team, environments, spec versions, runs |
| Environment | A place tests run | Name (Dev, QA, Staging), base URL, auth type, secret reference, security tests allowed, concurrency limit | Workflow |
| Spec version | One uploaded contract, immutable | Version number, normalized spec location, diff from previous, readiness report | Workflow, targets, rules |
| Target | What a test exercises: an API operation, a Kafka topic, or a UI screen | Kind, method and path or screen name, safety, schemas (JSONB), auth scopes | Spec version, dependency edges, test cases |
| Dependency edge | One target's output feeding another's input | From target, to target, field mapping, source (explicit, heuristic, AI), confidence, status | Two targets |
| Business rule | A structured rule from stories or a QE | Rule text, condition and outcome, type, source story, confidence, status, embedding | Spec version, targets, test cases |
| Test case | The canonical test case from Stage 3 | Stable case ID, version, engine (karate or playwright), type, priority, status, confidence, origin, data requirement, expected result (JSONB), locked flag, Zephyr key, Jira story | Targets, rules, script, data bindings, results |
| Data record | One QA catalog record | Environment, attributes (JSONB), shared or consumable, current state | Environment, data bindings |
| Script | The generated scenario for one case version | Repo path, commit, generated by (template or AI), validation status, locked flag | Test case |
| Run | One execution | Environment, trigger, scope, spec version, script commit, data version, build version, status, start and end | Workflow, results |
| Result | One case in one run | State, duration, retry flag, failure fingerprint, evidence location | Run, test case, triage item |
| Triage item | A cluster of failures with one cause | Category, confidence, AI explanation, QE decision | Results, defect |
| Defect | A Jira defect the product raised or updated | Jira key, fingerprint, status, severity, regression-of link | Triage items, test cases |

### Supporting entities

| Entity | Purpose |
| --- | --- |
| Coverage link | One row per test case and coverage target (dimension plus target), so coverage is a fast query across hundreds of thousands of cases |
| Data binding | Which data record or data set a case uses in an environment, and why it was chosen |
| Data set | Base payload, variations, rows and runtime placeholders per case and environment, stored in Cloud Storage |
| AI job | Each graph run: inputs, status, tokens, cost, and the location of the masked prompt and response |
| Audit event | Who approved, edited, rejected or reclassified what, with before and after |

### Design rules

1. Tenancy: every row carries its team, and every query filters by it.
2. Immutability: spec versions, test case versions and runs are never changed; a change creates a new version. This gives the audit trail and exact reproducibility.
3. Stable case IDs: a test case keeps its ID across versions, so Zephyr upserts and Karate tags always point at the same case.
4. Traceability: story, rule, test case, script, result and defect are all linked, so each can be traced to the others.
5. Engine-agnostic: the target kind and test case engine let Karate and Playwright share the same model.
6. Scale: results are partitioned by month; cases are indexed by workflow and status, results and defects by fingerprint.
7. One definition: the Pydantic models in the Python codebase are these entities, and AI outputs are validated into them.

## Stages still to detail

Each stage below gets its own section as we go through it.

- [x] Stage 3: Test design and coverage (six dimensions: structural, response code, schema, boundary, dependency, security)
- [x] Stage 4: QE approval and Zephyr publishing
- [x] Stage 5: Test data (schema rules, CSV mapping, synthetic data, PHI masking)
- [x] Stage 6: Karate script generation and dry run
- [x] Stage 7: Execution on GKE (pre-flight, Kubernetes Jobs, results)
- [x] Stage 8: Failure triage, Jira defects and rerun
- [x] Stage 9: Reporting
- [x] Architecture

## Open decisions and later phases

### Open decisions

- [x] Shared platform: decided, shared with the Angular UI testing product now and open to other applications later; execution engines (Karate, Playwright) plug in behind one interface
- [x] Orchestration language: decided, all Python: FastAPI platform API and LangGraph AI workers in one codebase; Java only in the Karate runner image
- [ ] Jira/Zephyr access through the Atlassian MCP server or direct REST APIs; and which Zephyr: Scale (case keys like PROJ-T123, native data rows) or Squad (tests are Jira issues)
- [x] LLM: decided, Gemini on Vertex AI
- [x] Coverage thresholds: decided, Stage 3 defaults, configurable per team

### Later phases

| Phase | Item | Why later |
| --- | --- | --- |
| v2 | Test generation from traffic (gateway or Istio logs, HAR files) | Needs PHI governance sign-off |
| v2 | Export Karate projects to CI pipelines | In-product execution comes first |
| v2 | Expose the product as an MCP server for IDE use | Core workflow first |
| v2 | Evaluate Karate Agent as a pluggable generator | Licensed; needs procurement |
| v3 | Learning from reviewer decisions beyond few-shot examples | Needs history to learn from |
| v3 | Neo4j for enterprise-wide dependency and impact analysis | PostgreSQL tables and pgvector are enough for v1 |
| Out of scope | SOAP/WSDL, testing against Prod | Not neededi th |
