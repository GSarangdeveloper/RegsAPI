# Diagram prompts — AI API Testing Platform

Paste one prompt at a time into an AI diagramming tool (Eraser, Lucidchart AI, Miro AI, draw.io "Generate", Whimsical AI, Mermaid Chart). Each prompt is self-contained: nodes, groups, edges, styles and layout rules. If the tool supports Mermaid, the Mermaid blocks at the end can be pasted directly.

---

## Prompt 1 — End-to-end process flow

```
Draw a process flow diagram titled "AI API Testing Platform — End-to-end process flow".

LAYOUT
- Six vertical columns left to right, one per phase. Each column has a grey header, a stack of step boxes flowing top to bottom, and a dashed footer stating the artifact the phase produces.
- The flow leaves the LAST step of each column and enters the FIRST step of the next column (orthogonal connector through the gutter). Never cross a box with a line.
- Start marker (filled circle, "QE creates a workflow") before step 1. End marker (bullseye, "release decision") after step 20.
- Loops and stops in amber. Everything else black. No swimlanes.

STEP BOX FORMAT
- Left: a numbered circle. Title in bold. One line of detail in grey. A small pill on the right naming the actor: Platform, Runner, AI, QE, QE gate, Zephyr, Jira, "Platform + AI".
- Style by kind: deterministic = white box, black border. AI-assisted = light blue fill, blue border. Human gate = light green fill, green border, diamond instead of a circle. External sync = grey fill, grey dashed border.

COLUMN 1 — "1 Onboard" (in: contract, env config, credentials + optional samples, stories, CSV, existing suite, Kafka config)
1 Ingest [Platform, deterministic] — secure credentials in Secret Manager first; normalize spec; stable key per operation; PHI scan
2 Smoke check [Platform, deterministic] — safe endpoints only: connectivity, auth, contract conformance, samples, CSV, Kafka
G Readiness gate [QE, gate] — red blocks until fixed; yellow needs acknowledgment; green passes
Footer: out: workflow package + readiness report

COLUMN 2 — "2 Understand" (in: workflow package)
3 Discover [Platform, deterministic] — endpoint inventory, field catalog, dependency graph, auth model, coverage universe
3 Extract rules [AI] — business rules from Jira stories, structured with source sentence and confidence
4 Rules review [QE gate] — confirm, edit or reject rules and low-confidence edges; add unwritten rules
Footer: out: API model (versioned with the spec)

COLUMN 3 — "3 Design" (in: API model)
5 Test design [Platform, deterministic] — rule engine: structural, response code, schema, boundary, dependency, security cases
5 Cases for gaps [AI] — business-rule and semantic cases aimed at coverage gaps
6 Coverage + contract [Platform, deterministic] — measure 7 dimensions; reject hallucinated cases; dedup; priority; confidence
7 QE approval [QE gate] — bulk-approve high confidence; review low confidence one by one; lead accepts gaps
8 Publish to Zephyr [Zephyr, external] — optional per team; upsert by case ID; P1/P2 by default
Footer: out: approved test cases (canonical model + assertion DSL)

COLUMN 4 — "4 Build" (in: approved cases, CSV, samples, catalog)
9 Test data [Platform, deterministic] — base payload, one mutation per case, catalog bindings, runtime placeholders
9 CSV mapping [AI] — column-to-field mapping; consistent semantic values
10 Data review [QE gate] — only when a CSV was uploaded; blocked cases list what QA must add
11 Scripts [Platform + AI] — templates first; AI only for business flows, state transitions, Kafka; repair up to 2 times
12 Dry run [Platform, deterministic] — parse, static, contract checks; mock run against Prism; commit to Git; locks respected
Footer: out: data sets + validated Karate project (Git)

COLUMN 5 — "5 Run" (in: Karate project, environment, trigger)
13 Pre-flight [Platform, deterministic] — env health, tokens, safe call, record allocation, freeze windows, build version
14 Execute [Runner, deterministic] — Kubernetes Job at pinned commit; parallel shards; retry only network / 5xx
15 Results [Platform + Zephyr, deterministic] — ingest, mask evidence, fingerprint, clean up created resources; Zephyr test cycle
Footer: out: run record + masked evidence
Below the footer: an amber rounded pill "Stop: environment not ready → notify owner", reached by an amber dashed arrow from step 13 labelled "red".

COLUMN 6 — "6 Close the loop" (in: run results)
16 Triage [Platform + AI] — signals first (env, data, drift, flaky); AI classifies the rest; cluster by root cause
17 Defect review [QE gate] — confirm, reclassify or dismiss; every decision feeds triage back
18 Jira defect [Jira, external] — fingerprint dedup: comment on open, new + regression link on closed
19 Rerun on fix [Platform, deterministic] — webhook on ready-for-QA; linked cases + same endpoint + dependency chain; comment result
20 Report [Platform + AI] — every number computed; AI writes the summary; run, workflow, portfolio, release readiness
Footer: out: defects, rerun evidence, report + dashboards

LOOPS (amber arrows, routed outside the boxes)
- Coverage loop: from step 6 back to step 5 (label "gaps → regenerate, ≤ 3 rounds").
- Rerun loop: from step 19, down and along the bottom of the diagram, back up into step 13 (label "rerun after a fix: Jira webhook (ready for QA) → linked cases, same endpoint, dependency chain").
- Spec change: an amber pill above column 2, "New spec version → impacted targets only", with an arrow down into the column header.

LEGEND (bottom)
Deterministic step (Platform / Runner) · AI-assisted step — drafts only · Human gate: approve, edit, reject, regenerate · Sync to an external system · Amber arrow = loop or stop.
Note: "Steps that share a number run in the same stage (deterministic first, AI only for what rules cannot do)."
```

---

## Prompt 2 — Architecture (single deployment view, numbered request paths)

```
Draw an architecture diagram titled "AI API Testing Platform — Architecture". Subtitle: "Four deployables on GKE (one Python codebase) and the managed services each one uses. Numbers trace a request."
Style: clean grid, orthogonal arrows, every arrow labelled or numbered; managed GCP services carry a small "GCP" chip; external systems are grey with dashed border; no big nested boundaries except the three namespace groups.

LEFT COLUMN — who calls it
- QE / QE lead (browser, OIDC via company IdP): reviews, approves, runs, reads reports [green]
- CI pipeline (per-team API key): deploy trigger → run P1 or full
- Jira webhook (HMAC-signed): defect ready for QA → rerun linked cases

CENTER — GKE deployables
- Group "GKE · namespace: app": web (Angular, nginx: screens only — review queue, matrix, editor) and platform-api (Python 3.12, FastAPI, HPA 2–20: modules M1–M8 as packages — intake, discovery, design, data, scripts, execution, analysis, integration; owns every state transition and human gate; rule / coverage / contract engines; Karate templates; run orchestration; outbox relay; SSE; RLS; audit; API keys) [indigo].
- Group "GKE · namespace: ai" above-right: ai-worker (same image, entrypoint worker, scales on backlog: 5 LangGraph graphs — rules, design, csv mapping, scripts, triage → drafts only) [blue].
- Group "GKE · namespace: runners · own node pool" below-right: karate-runner Kubernetes Job (Temurin 21, Karate, Kafka helper, Prism: one Job per run sharded by feature; pinned script commit + data version) [amber].
- Pub/Sub sits between ai-worker and karate-runner (4 topics + dead-letter, CloudEvents: ai-jobs, ai-results, run-events, jira-events; outbox out, idempotent consumers in) [purple, GCP chip].

STORES next to their consumers
- Cloud SQL (PostgreSQL 16, pgvector; workflows, API model, cases, runs, results, audit, outbox; RLS on every tenant table) above-left of platform-api [GCP].
- Vertex AI (Gemini, context caching; fast tier for mapping and triage, strong tier for design and scripts) right of ai-worker [blue, GCP].
- Bottom row under platform-api / runner: Sensitive Data Protection (DLP: scans uploads and stories, nightly evidence sample), Cloud Storage (3 buckets, 90-day lifecycle: raw inputs, data sets, masked evidence, reports), Secret Manager (CSI driver, Workload Identity: credential profiles, Jira SA; DB and Git hold references) [red border].
- Logging · Trace · Monitoring (OpenTelemetry, JSON logs; one trace id browser → runner; SLO alerts) top-right, no arrows.

RIGHT — targets and externals
- Dev · QA · Staging (per workflow, credential profiles: REST/GraphQL APIs, Kafka topics + schema registry, QA data catalog) right of the runner.
- Prod (red, struck through): never a target, no network route. Not connected.
- Group "External systems · behind provider interfaces": Jira (REST, webhook out: stories in, defects out, fingerprint dedup), Zephyr Scale or Squad (REST, rate-limited: cases upserted by case ID, test cycles per run), Git test-assets repo (folder per workflow, commit per generation).

NUMBERED ARROWS
1 QE → web (HTTPS). 2 web → platform-api (REST + SSE). 3 CI pipeline → platform-api and Jira webhook → platform-api. 4 platform-api → Cloud SQL (SQL, RLS). 5 platform-api → Pub/Sub, purple, "outbox". 6 Pub/Sub ↔ ai-worker, purple, "pull ai-jobs / publish ai-results". 7 ai-worker → Vertex AI, blue. 8 ai-worker → Cloud SQL, blue, routed over the top, "validated drafts + coverage links (same repositories, RLS)". 9 Pub/Sub → platform-api, purple, "ai-results, run-events, jira-events". 10 platform-api → karate-runner, "creates Job (manifest, shards)". 11 Secret Manager → karate-runner, red dashed, "credential profiles via CSI". 12 karate-runner → Dev/QA/Staging, "HTTP(S) / mTLS, Kafka — the runner's only egress". 13 karate-runner → Cloud Storage, grey, "evidence (masked in pod)". 14 karate-runner → Pub/Sub, purple, "run-events". 15 platform-api → Jira / Zephyr / Git, grey, along the bottom, with a red branch up into Secret Manager labelled "secret refs, write once". Also platform-api → Sensitive Data Protection "PHI scan on ingest" and platform-api → Cloud Storage (objects).

BOTTOM PANEL "Follow a request"
Generate test cases: 1–2 QE clicks Generate; web calls platform-api (SSE pushes updates back). 4 platform-api runs the rule engine, coverage and contract checks in-process and saves drafts. 5 It writes an ai_job row and its event in one transaction; the outbox relay publishes to ai-jobs. 6–7 An ai-worker pulls the job, builds a masked spec slice, asks Gemini for cases aimed at the gaps. 8 Only drafts that pass schema and contract validation are saved, with coverage links. 9 ai-results tells platform-api; the review queue updates; the QE approves — a state transition owned by platform-api.
Run a suite: 3 A QE, a schedule, a CI deploy or a Jira webhook requests a run. 4 Pre-flight: env health, tokens, safe call, record allocation, freeze windows; red stops the run as env not ready. 10 platform-api creates a Kubernetes Job pinned to a script commit and a data version. 11 Secret Manager mounts the credential profiles; the runner never touches the DB. 12 Karate shards run against Dev/QA/Staging only; retries only on network or 5xx. 13–15 Evidence masked in the pod and stored; run-events → results ingested, fingerprinted, cleaned up; Zephyr cycle and Jira defects.
Rules line: platform-api owns every state transition and human gate · modules are packages in one codebase and never call each other over HTTP · AI cost scales with onboarding, not runs · every run is reproducible from its pinned versions · no route to Prod.

LEGEND: black = synchronous call; purple = Pub/Sub event (outbox out, idempotent in); blue = the only LLM paths, drafts never approvals; red = credentials by reference, values only in Secret Manager; GCP chip = managed service; grey = external.
```

---

## Prompt 3 — Detailed deployment view (C4 container level), optional

```
Draw a C4 container diagram on GKE for the AI API Testing Platform.
People: QE / QE lead (browser, company SSO); CI pipeline (API key).
External systems (grey, dashed): Jira (REST, webhook), Zephyr (Scale or Squad), Git (test-assets repo), Company IdP (OIDC).
Boundary "GKE cluster — product's own dev/staging/prod; Workload Identity, Helm, NetworkPolicy default-deny per namespace":
- namespace app: web (Angular, nginx, 2 replicas) and platform-api (Python 3.12, FastAPI, HPA 2–20: modules M1–M8 as packages; state machines and every human gate; rule, coverage and contract engines; template generation and validation; run orchestration; integrations; auth, RLS, audit, outbox relay, SSE).
- namespace ai: ai-worker (same image, entrypoint worker, scales on Pub/Sub backlog; 5 LangGraph graphs; writes drafts only; the only package that imports the LLM client; PHI guard + token budget per call).
- namespace runners (dedicated autoscaled node pool, spot allowed): karate-runner Kubernetes Job (Temurin 21, Karate standalone, Kafka helper, Prism for validation; one Job per run sharded by feature; pinned script commit + data version; egress only to the target environment's hosts; no route to Prod; no DB access).
Boundary "GCP managed services": Cloud SQL (PostgreSQL 16, pgvector, RLS; workflows, API model, cases, runs, results, audit, outbox), Cloud Storage (3 buckets: raw inputs, masked evidence, reports, LLM traces; 90-day lifecycle), Secret Manager (target API credential profiles, Jira service account; CSI driver; never in DB or logs), Pub/Sub (topics ai-jobs, ai-results, run-events, jira-events + dead-letter; CloudEvents; ordering keys; transactional outbox; idempotent consumers), Vertex AI (Gemini; fast tier for mapping and triage, strong tier for design and scripts; context caching), Sensitive Data Protection (DLP on uploads and stories; nightly 2% sample of evidence), Cloud Logging/Trace/Monitoring (OpenTelemetry; one trace id browser → runner).
Boundary "Environments under test (per workflow)": Dev, QA, Staging (base URL, credential profiles, limits; REST/GraphQL APIs, Kafka topics + schema registry, freeze windows, concurrency), Prod (crossed out: never a target), Data catalog (QA-supplied, synthetic/masked records bound to cases per environment).
Edges (label each): QE → web "HTTPS, SSO"; CI → platform-api "POST /triggers/deploy, X-Api-Key"; web → platform-api "REST + SSE"; platform-api → Cloud SQL "SQL, RLS"; platform-api → Cloud Storage "objects, signed URLs"; platform-api → Secret Manager "secret refs only (write once, verify)" in red; platform-api → Pub/Sub "outbox relay → ai-jobs, run-events, jira-events" in purple; Pub/Sub → platform-api "ai-results, run-events, jira-events (idempotent)" in purple; Pub/Sub ↔ ai-worker "ai-jobs (pull) / ai-results" in purple; ai-worker → Cloud SQL "drafts + coverage links; in-process engines" in blue; ai-worker → Vertex AI "masked spec slice in, JSON-schema output" in blue; platform-api → runner "creates Kubernetes Job (manifest, shards)"; runner → Pub/Sub "run-events: completed" in purple; runner → Cloud Storage "evidence (masked in pod)"; Secret Manager → runner "credential profiles mounted via CSI → AUTH_* env vars" red dashed; runner → Dev/QA/Staging "HTTP(S) / mTLS, Kafka produce & consume"; platform-api → Jira/Zephyr/Git "REST; webhook in (HMAC)"; IdP → platform-api "OIDC tokens, group → role".
Legend: solid = synchronous call; purple = Pub/Sub event; blue = the only LLM paths; red = credential paths (values only in Secret Manager); grey dashed box = external system behind a provider interface.
Rules to print beside the diagram: platform-api owns every state transition and human gate; modules are packages in one codebase and never call each other over HTTP; AI cost scales with onboarding and spec changes, not runs; runs are reproducible (spec version, script commit, data version, build version pinned); every tenant table carries team_id and RLS is the second wall; not in v1: microservices, service mesh, Kafka internally, Neo4j, separate vector DB, multi-agent swarm.
```

---

## Mermaid (paste directly where Mermaid is supported)

### Process flow (compact)

```mermaid
flowchart LR
  subgraph P1[1 Onboard]
    direction TB
    S1[1 Ingest<br/>Platform] --> S2[2 Smoke check<br/>Platform] --> G1{Readiness gate<br/>QE}
  end
  subgraph P2[2 Understand]
    direction TB
    S3[3 Discover<br/>Platform] --> S3b[3 Extract rules<br/>AI] --> G2{4 Rules review<br/>QE}
  end
  subgraph P3[3 Design]
    direction TB
    S5[5 Test design<br/>Platform] --> S5b[5 Cases for gaps<br/>AI] --> S6[6 Coverage + contract<br/>Platform] --> G3{7 QE approval} --> S8[8 Publish to Zephyr]
    S6 -. gaps, ≤3 rounds .-> S5b
  end
  subgraph P4[4 Build]
    direction TB
    S9[9 Test data<br/>Platform] --> S9b[9 CSV mapping<br/>AI] --> G4{10 Data review<br/>QE} --> S11[11 Scripts<br/>Platform + AI] --> S12[12 Dry run<br/>Platform]
  end
  subgraph P5[5 Run]
    direction TB
    S13[13 Pre-flight<br/>Platform] --> S14[14 Execute<br/>Runner] --> S15[15 Results<br/>Platform + Zephyr]
    S13 -. red .-> STOP([Stop: env not ready])
  end
  subgraph P6[6 Close the loop]
    direction TB
    S16[16 Triage<br/>Platform + AI] --> G5{17 Defect review<br/>QE} --> S18[18 Jira defect] --> S19[19 Rerun on fix<br/>Platform] --> S20[20 Report<br/>Platform + AI]
  end
  START((start)) --> S1
  G1 --> S3
  G2 --> S5
  S8 --> S9
  S12 --> S13
  S15 --> S16
  S19 -. rerun after fix .-> S13
  SPEC([New spec version]) -. impacted only .-> S3
  S20 --> END(((release decision)))
  classDef ai fill:#eff6ff,stroke:#2563eb;
  classDef gate fill:#ecfdf5,stroke:#059669;
  classDef ext fill:#f3f4f6,stroke:#6b7280,stroke-dasharray:4 3;
  class S3b,S5b,S9b,S11,S16,S20 ai;
  class G1,G2,G3,G4,G5 gate;
  class S8,S18 ext;
```

### Architecture backbone (compact)

```mermaid
flowchart LR
  QE[QE / lead<br/>browser · SSO] --> WEB[web<br/>Angular]
  CI[CI pipeline<br/>API key] --> API
  WEB -->|REST + SSE| API[platform-api<br/>FastAPI · gates · engines · outbox]
  API -->|SQL · objects · secret refs · REST| STORES
  subgraph STORES[stores and integrations]
    direction LR
    GCS[(Cloud Storage)] --- SQL[(Cloud SQL<br/>RLS · pgvector)] --- SM[Secret Manager] --- JZ[Jira · Zephyr · Git]
  end
  API -->|outbox| PS[Pub/Sub<br/>4 topics]
  PS -->|pull| AIW[ai-worker<br/>LangGraph · drafts only]
  AIW -->|LLM| VX[Vertex AI<br/>Gemini]
  AIW -->|drafts| SQL
  API -->|creates Job| RUN[karate-runner Job<br/>pinned commit + data]
  RUN -->|run-events| PS
  RUN -->|evidence| GCS
  SM -.->|creds via CSI| RUN
  RUN -->|HTTP(S) / mTLS · Kafka| ENV[Envs under test<br/>Dev · QA · Staging]
  PROD[Prod — never a target]
  classDef ai fill:#eff6ff,stroke:#2563eb; classDef ev fill:#f5f3ff,stroke:#6d28d9; classDef red fill:#fef2f2,stroke:#b91c1c;
  class AIW,VX ai; class PS ev; class SM,PROD red;
```
