# AI API Testing Platform — Technical Specification for Build

Sep 24, 2026 · @Advik

## How to use this spec

This is the build contract for the coding agent. It supersedes the "AI API Testing Platform — Solution Design" doc (Sep 24, 2026) wherever the two differ; the design doc remains the rationale.

Non-negotiable rules for every change the agent makes:

1. Build only what the current release (MVP first) lists; everything later is behind an interface, not implemented.
2. AI runs in five places only: business rule extraction, test case design, semantic test data, Karate scenario generation, failure triage. No other module imports the LLM client.
3. Deterministic first: the rule engine, coverage engine and contract validator produce or check every case before any LLM call, and every LLM output is validated into a Pydantic model or rejected.
4. The canonical test case (section 7) is the only source of truth; scripts, Zephyr cases, data sets and results derive from it and reference it by stable `case_id`.
5. Secrets never enter the database, logs, prompts, Git or evidence. Credentials go to Secret Manager first, through their own endpoint.
6. Every Pub/Sub consumer is idempotent; every job is published through the transactional outbox.
7. Every table carries `team_id`; Postgres row-level security is on, not optional.
8. Spec versions, test case versions and runs are immutable; changes create new versions.
9. No new infrastructure (service mesh, Kafka, Neo4j, separate vector DB, WebSocket server) without a written decision in section 19.
10. Definition of done for any task: unit tests, contract test against the OpenAPI of the platform, lint and type check pass, and the evaluation harness does not regress.

## 1. Design changes from the review

The design shape is unchanged; these 16 changes close gaps found in review and are binding in this spec.

| # | Change | Why | Where in this spec |
| --- | --- | --- | --- |
| 1 | Credentials are captured by a dedicated endpoint and written to Secret Manager before any other input is stored | Secrets must never touch raw storage or logs | 9, 16 |
| 2 | Module rule restated: no module calls another module's API; shared packages are imported in-process; the orchestrator sequences stages | The old wording contradicted pre-flight and integration reuse | 5, 8 |
| 3 | Structured assertion DSL for expected results | Templates and contract validation need machine-readable assertions | 7 |
| 4 | Stable target key: `operationId`, else `METHOD + normalized path`; rename detection on re-upload | Spec diff and impacted-only regeneration need it | 6, 11 |
| 5 | Transactional outbox for Pub/Sub publishing; idempotent consumers keyed by `job_id` | Pub/Sub is at-least-once | 10 |
| 6 | Credential profiles per environment (several identities, roles, mTLS) | Object-level authorization and scope tests need two identities | 6, 16 |
| 7 | Dry run uses a spec-driven mock (Prism) sidecar; parse and static checks run in Python | Karate has no spec-generated mock | 13 |
| 8 | Zephyr publishing optional per team, default approved P1 and P2 only; asynchronous and batched | Zephyr API rate limits at 300k+ cases | 15 |
| 9 | Created-resource ledger per run plus orphan sweeper | Teardown can fail | 14 |
| 10 | Optimistic locking (`row_version`) on test case and script edits | Concurrent QE review | 6, 9 |
| 11 | Explicit workflow and suite state machine owned by the platform API | Orchestrator was one sentence | 8 |
| 12 | Machine auth: per-team API keys and HMAC-signed webhooks | CI and Jira are not SSO users | 15, 16 |
| 13 | Postgres row-level security with `app.team_id` per request | Second wall behind application filtering | 6, 16 |
| 14 | Schema generation handles `oneOf/anyOf/allOf`, discriminators, recursion depth cap, `readOnly/writeOnly` | Real specs use them | 11 |
| 15 | Field-based masking from the field catalog; DLP on uploads and a sample of evidence, not every response | Cost and latency at hundreds of runs a day | 16 |
| 16 | Direct Jira and Zephyr REST for v1 (no MCP hop); SSE for live UI updates; Gemini context caching | Simpler, cheaper | 4, 15, 17 |

Deferred to R2 or later on the same grounds: AI resource-lifecycle inference, style learning from existing Karate suites, pgvector few-shot retrieval, Langfuse, portfolio product metrics, release readiness view.

## 2. Scope and build order

Three releases; the MVP is a working REST-only loop with no LLM on the critical path, so the platform, rule engine and runner are proven before AI is added.

| Release | In scope | Explicitly out | Done when |
| --- | --- | --- | --- |
| MVP | Team, workflow, environment, credential profiles; Ingest (OpenAPI 3 and Swagger 2), smoke check, readiness report; Discover for REST (inventory, field catalog, explicit and heuristic dependency edges); rule engine cases for all six dimensions; coverage engine and matrix; contract validation; review queue with bulk approve; template-only Karate generation; parse and static validation; execution on GKE with pre-flight, retry and evidence masking; result ingestion; run report; SSE updates; audit log; RLS; outbox | Any LLM call, Jira, Zephyr, CSV, data catalog, GraphQL, Kafka, dry-run mock, triage, dashboards | One pilot API onboarded end to end by a QE without engineering help; 100% structural coverage generated, reviewed and executed; run reproducible from run record |
| R2 | AI graphs: rule extraction, test design, CSV mapping, script generation with repair; Jira story ingestion; data catalog and bindings; Zephyr publish and sync; Prism dry run; evaluation harness in CI; Gemini context caching; spec diff with impacted-only regeneration | Triage, Kafka, GraphQL, dashboards | Harness thresholds met (section 18); AI acceptance rate measured on three pilot APIs |
| R3 | Failure triage graph; Jira defects with dedup; webhook rerun loop; GraphQL targets; Kafka test type and helper; workflow and portfolio dashboards; release readiness; bulk onboarding from API catalog; CI trigger endpoint hardened | Traffic-based generation, MCP server, Karate Agent, Neo4j | Rerun loop closes a defect on a pilot API without manual steps |

MVP milestones in build order (each is a mergeable increment):

1. Platform skeleton: FastAPI app, Alembic migrations, RLS, auth (OIDC and API keys), audit, outbox relay, SSE, Helm chart, CI.
2. Tenancy and workflow CRUD, environment and credential profile endpoints, Secret Manager client.
3. Ingest: upload, normalize, lint, spec version, target key, readiness report; smoke check as a shared package.
4. Discover: API model tables, field catalog flattening, dependency edges, coverage universe.
5. Rule engine and assertion DSL, coverage engine, contract validator, dedup and priority.
6. Review queue API and Angular screens: coverage matrix, bulk approve, edit, reject, lock.
7. Karate reference framework repo, templates, generator, parse and static checks, Git commit per generation.
8. Runner image, Kubernetes Job launcher, pre-flight, result ingestion, evidence masking, cleanup ledger.
9. Run report and per-case drill-down; workflow state machine end to end; pilot API onboarding.

## 3. Process flow

Six phases, five human gates, three loops (coverage, rerun on fix, spec change). The standalone swimlane diagram is delivered alongside this doc; this is the same flow in text form for the agent.

```mermaid
flowchart TD
  A[1 Ingest and smoke check] -->|red: fix inputs| A
  A --> B[2 Discover: API model]
  B --> G1{Gate: rules review}
  G1 --> C[3 Test design: rule engine + AI]
  C --> D[4 Coverage and contract validation]
  D -->|gaps, max 3 rounds| C
  D --> G2{Gate: QE approval}
  G2 --> E[5 Test data and bindings]
  E --> G3{Gate: data review}
  G3 --> F[6 Script generation and dry run]
  F --> H[7 Pre-flight and execute]
  H -->|env not ready| STOP[Stop: environment not ready]
  H --> I[8 Triage]
  I --> G4{Gate: defect review}
  G4 --> J[Jira defect and Zephyr sync]
  J -->|ready for QA webhook| H
  I --> K[9 Report]
  S[New spec version] -->|impacted targets only| B
```

Read top down: a workflow enters at Ingest once and re-enters at Discover on every spec change; execution is the only stage entered repeatedly.

| Phase | Step | Owner | Entry state | Exit state | AI |
| --- | --- | --- | --- | --- | --- |
| Onboard | Ingest, normalize, secure credentials | Platform | `workflow.created` | `spec_version.ready` or `red` | No |
| Onboard | Smoke check and readiness report | Platform, human on red | `spec_version.ready` | `spec_version.accepted` | No |
| Understand | Discover: inventory, catalog, edges, universe | Platform | `spec_version.accepted` | `api_model.draft` | No |
| Understand | Rule extraction from stories (R2) | AI worker | `api_model.draft` | `api_model.awaiting_review` | Yes |
| Understand | Rules review gate | QE | `api_model.awaiting_review` | `api_model.confirmed` | No |
| Design | Rule engine generation | Platform | `suite.generating` | `suite.measuring` | No |
| Design | AI test design for gaps (R2) | AI worker | `suite.measuring` | `suite.measuring` | Yes |
| Design | Coverage, contract validation, dedup, confidence | Platform | `suite.measuring` | `suite.awaiting_review` | No |
| Design | QE approval gate | QE, QE lead for gaps | `suite.awaiting_review` | `suite.approved` | No |
| Design | Zephyr publish (R2) | Platform | `suite.approved` | `suite.published` | No |
| Build | Test data and bindings | Platform, AI for CSV mapping (R2) | `suite.approved` | `data.awaiting_review` or `data.ready` | Partly |
| Build | Data review gate | QE | `data.awaiting_review` | `data.ready` | No |
| Build | Script generation, validation, repair | Platform, AI for complex scenarios (R2) | `data.ready` | `scripts.valid` | Partly |
| Run | Pre-flight | Platform | `run.requested` | `run.running` or `run.env_not_ready` | No |
| Run | Execute on GKE, collect, clean up | Runner | `run.running` | `run.completed` | No |
| Run | Results sync to Zephyr (R2) | Platform | `run.completed` | `run.synced` | No |
| Close | Triage (R3) | Platform signals, AI worker | `run.completed` | `triage.awaiting_review` | Yes |
| Close | Defect review gate | QE | `triage.awaiting_review` | `triage.decided` | No |
| Close | Jira defect, dedup, rerun on webhook (R3) | Platform | `triage.decided` | `defect.open` | No |
| Close | Report | Platform, AI summary (R3) | `run.completed` | — | Summary only |

## 4. Architecture

Four deployables on GKE: Angular web app, one Python codebase run as the platform API and as AI workers, and Karate runner Jobs. Pub/Sub carries only long-running work. The detailed container and deployment diagram is delivered alongside this doc.

```mermaid
flowchart LR
  U[QE / QE lead<br/>browser, SSO] --> W[Angular web app]
  CI[CI pipelines<br/>API key] --> P
  W -->|REST + SSE| P[Platform API<br/>FastAPI]
  P --> DB[(Cloud SQL Postgres<br/>RLS + pgvector)]
  P --> GCS[(Cloud Storage<br/>inputs, evidence)]
  P --> GIT[(Test assets Git)]
  P -->|outbox relay| PS[Pub/Sub<br/>4 topics]
  PS --> AI[AI workers<br/>LangGraph]
  AI --> DB
  AI --> LLM[Gemini on Vertex AI]
  P -->|K8s API| R[Karate runner Job]
  R --> SUT[APIs and Kafka under test<br/>Dev / QA / Staging]
  R -->|results| PS
  P <-->|REST, webhooks| J[Jira + Zephyr]
  SM[Secret Manager] -.-> P
  SM -.-> R
```

The platform API owns every state transition and every human gate; AI workers only write drafts; runners only execute.

### Containers

| Container | Runtime | Scaling | Owns |
| --- | --- | --- | --- |
| `web` | Angular 18+, served by nginx | 2 replicas | Screens only; no business logic |
| `platform-api` | Python 3.12, FastAPI, Uvicorn | HPA on CPU and request latency, 2 to 20 | All REST endpoints, state machine, rule and coverage engines, template generation, validation, run orchestration, integrations, SSE, outbox relay (leader-elected) |
| `ai-worker` | Same image as `platform-api`, entrypoint `worker` | KEDA or HPA on Pub/Sub backlog, 0 to N; rate limiter for Vertex quota | LangGraph graphs; pulls `ai-jobs`, publishes `ai-results` |
| `runner` | Kubernetes Job; image with Temurin JDK 21, Karate standalone JAR, Kafka helper JAR, Prism (dry run only) | One Job per run; parallelism by feature shards; dedicated node pool with autoscaler | Executes and validates scripts; writes evidence to GCS; publishes `run-events` |
| `webhook-ingress` | Route on `platform-api` behind an internal load balancer with allowlist | Same as API | HMAC-verified Jira webhooks, CI triggers |

### Namespaces and network

| Namespace | Workloads | Egress allowed |
| --- | --- | --- |
| `app` | `web`, `platform-api` | Cloud SQL, GCS, Pub/Sub, Secret Manager, Git host, Jira and Zephyr, Vertex AI (none in MVP) |
| `ai` | `ai-worker` | Cloud SQL, Pub/Sub, Secret Manager, Vertex AI |
| `runners` | runner Jobs, node pool `runners` (optionally spot) | Target environment hosts only, per-environment NetworkPolicy; Pub/Sub; GCS; never Prod CIDRs |

### Request flow: generate test cases (R2 with AI; MVP is the deterministic path only)

```mermaid
sequenceDiagram
  participant QE
  participant API as Platform API
  participant DB as Postgres
  participant PS as Pub/Sub
  participant W as AI worker
  QE->>API: POST /suites/{id}/generate
  API->>DB: rule engine cases + coverage (in-process)
  API->>DB: insert ai_job + outbox row (one txn)
  API-->>QE: 202 job_id
  API->>PS: relay outbox -> ai-jobs
  PS->>W: job
  W->>DB: read API model slice, rules
  W->>W: test design graph (Gemini)
  W->>DB: validated draft cases, coverage links
  W->>PS: ai-results job.done
  PS->>API: job.done
  API-->>QE: SSE suite.updated
```

### Request flow: execute a run

1. `POST /runs` creates `run(status=requested)` and an outbox event; the pre-flight worker (a platform API background task) runs connectivity, token, safe call, record allocation.
2. On green, the launcher creates a Kubernetes Job with a pinned `script_commit`, `data_version`, environment reference and shard list; secrets are mounted via Workload Identity and Secret Manager CSI, never in the Job spec.
3. The runner executes shards, streams evidence to GCS under `runs/{run_id}/`, and publishes `run.completed` with report locations.
4. The results ingester parses Karate JSON into `result` rows, applies masking rules, releases records, marks the run `completed`, and emits SSE.
5. Cleanup: helper teardown, then the ledger sweeper deletes anything left; the Job is deleted after log capture.

## 5. Repository layout, tech stack and coding standards

One monorepo (`apitest-platform`) with three top-level apps and one shared Python package; a second repo (`test-assets`) holds only generated Karate projects.

```markdown
apitest-platform/
  backend/
    apitest/                 # one Python package, both process types
      core/                  # settings, db session, RLS, auth, audit, outbox, sse, errors
      domain/                # Pydantic models = the entities in section 6 (single definition)
      modules/
        intake/              # M1: upload, normalize, lint, spec version, smoke/preflight (shared pkg)
        discovery/           # M2: inventory, field catalog, dependency edges, coverage universe
        design/              # M3: rule engine, coverage engine, contract validator, dedup, confidence
        data/                # M4: payload builder, mutations, csv, catalog matching, bindings
        scripts/             # M5: karate templates, generator, parse/static checks, git client
        execution/           # M6: preflight runner, k8s launcher, result ingester, cleanup ledger
        analysis/            # M7: triage signals, clustering, report queries
        integration/         # M8: jira, zephyr clients, webhook verification
      ai/                    # LangGraph graphs; only package allowed to import llm client
        graphs/{rules,design,csv_mapping,scripts,triage}/
        llm/                 # provider interface, gemini impl, phi guard, budgets, caching
        harness/             # golden set runner
      api/                   # FastAPI routers, one per module + auth, teams, workflows, runs, jobs
      worker/                # Pub/Sub consumers: ai_jobs, ai_results, run_events, jira_events
      orchestration/         # state machines (section 8), transitions, gate checks
    alembic/
    tests/{unit,integration,contract}/
  web/                       # Angular workspace: features/{workflows,review,coverage,scripts,runs,reports}
  runner/                    # Dockerfile, entrypoint.sh, kafka-helper/ (Java, Gradle), prism config
  karate-reference/          # reference framework + pattern library (source of templates)
  deploy/helm/               # charts: platform, ai-worker, runners (Job template), web
  docs/                      # ADRs (one per decision in section 20), openapi/platform.yaml
  .github/ or cloudbuild/    # CI: lint, type, tests, harness, image build, helm lint
```

### Stack

| Layer | Choice | Notes |
| --- | --- | --- |
| Language | Python 3.12, typed (mypy strict), Ruff | One codebase for API and workers |
| API | FastAPI, Pydantic v2, SQLAlchemy 2 async, Alembic | OpenAPI generated from routers is the platform contract |
| AI | LangGraph, Vertex AI SDK (Gemini), provider interface `LLMProvider` | Two model tiers: fast (mapping, triage), strong (design, scripts) |
| Web | Angular 18+, standalone components, Signals, Angular Material, ngx-monaco for the script editor | SSE via `EventSource` |
| Data | Cloud SQL PostgreSQL 16, pgvector, monthly partitions on `result` | RLS on every tenant table |
| Messaging | Pub/Sub, 4 topics, dead-letter topics, outbox relay | No Kafka internally |
| Storage | GCS buckets: `inputs`, `evidence`, `reports`; lifecycle 90 days on evidence | Object versioning on |
| Git | Product-owned `test-assets` repo, service account, one folder per workflow | Commit per generation, tagged with suite version |
| Runtime | GKE Standard, Workload Identity, Helm, Secret Manager CSI driver | NetworkPolicy per namespace |
| Runner | Temurin JDK 21, Karate 1.5.x standalone, Kafka helper (Java 21, kafka-clients, Avro), Prism | Images pinned by digest, scanned in CI |
| Observability | OpenTelemetry SDK, Cloud Logging, Cloud Trace, Cloud Monitoring | Structured JSON logs |

### Coding standards

- Domain models are Pydantic and are the only shape crossing module boundaries; SQLAlchemy models stay inside a module's `repository.py`.
- Modules expose a `service.py` (use cases) and a `router.py`; cross-module use goes through `service` imports, never through HTTP.
- Every write that must emit an event uses `outbox.publish(session, topic, payload)` inside the same transaction.
- Every request sets `SET LOCAL app.team_id` via the DB session dependency; tests assert RLS blocks cross-team reads.
- All LLM prompts are versioned files under `ai/graphs/*/prompts/`, with a `prompt_version` recorded on the `ai_job`.
- No secret values in Pydantic models; only `secret_ref` strings of the form `projects/{p}/secrets/{name}/versions/{v}`.
- Feature flags per team in `team.settings` JSONB, read through `settings.get(team, key, default)`; no scattered `if` on team names.
- ADR required for any new dependency, topic, table partition scheme or external system.

## 6. Domain model

22 tables in PostgreSQL; every tenant table has `team_id uuid not null` with an RLS policy, `created_at`, `updated_at`, `created_by`; ids are UUIDv7. JSONB holds the flexible parts, GCS holds large blobs.

```mermaid
flowchart TD
  TM[team] --> WF[workflow]
  WF --> EN[environment] --> CP[credential_profile]
  WF --> SV[spec_version] --> TG[target]
  TG --> DE[dependency_edge]
  SV --> BR[business_rule]
  SV --> ST[suite] --> TC[test_case]
  TC --> CL[coverage_link]
  TC --> SC[script]
  TC --> DB1[data_binding] --> DR[data_record]
  WF --> RN[run] --> RS[result] --> TI[triage_item] --> DF[defect]
  RN --> CR[created_resource]
```

A suite is the set of test case versions generated from one spec version; approving a suite freezes it, and a spec change creates a new suite that carries unchanged cases forward.

### Tables

| Table | Key columns (beyond id, team\_id, timestamps) | Notes |
| --- | --- | --- |
| `team` | `name`, `settings jsonb` (thresholds, zephyr\_enabled, publish\_priorities, caps), `sso_group` | Tenant |
| `team_member` | `team_id`, `user_id`, `role enum(qe, qe_lead, admin)` | From SSO groups, cached |
| `api_key` | `team_id`, `key_hash`, `label`, `scopes[]`, `expires_at`, `last_used_at` | Machine auth for CI |
| `workflow` | `name`, `kind enum(api, ui)`, `owner_user_id`, `status`, `current_spec_version_id`, `git_folder` | One API under test |
| `environment` | `workflow_id`, `name enum(dev, qa, staging)`, `base_url`, `security_tests_allowed bool`, `concurrency_limit int`, `rate_limit_rps int`, `freeze_windows jsonb`, `kafka_config jsonb` | Never prod |
| `credential_profile` | `environment_id`, `name` (default, member\_b, read\_only…), `auth_type enum(oauth2_cc, bearer, api_key, mtls)`, `secret_ref`, `scopes[]`, `role_label` | Value only in Secret Manager |
| `spec_version` | `workflow_id`, `version int`, `format enum(openapi3, swagger2, graphql_sdl)`, `raw_uri`, `normalized_uri`, `lint jsonb`, `diff_from_previous jsonb`, `readiness enum(green, yellow, red)`, `readiness_report jsonb`, `status` | Immutable |
| `target` | `spec_version_id`, `target_key text` (operationId or METHOD path), `kind enum(operation, graphql_field, kafka_topic, ui_screen)`, `method`, `path`, `safety enum(safe, idempotent, mutating)`, `request_schema jsonb`, `responses jsonb`, `auth_scopes[]`, `tags[]`, `not_triggerable_codes jsonb` | Unique `(spec_version_id, target_key)` |
| `field` | `target_id`, `direction enum(request, response)`, `path text` (dotted, `[]` for arrays), `type`, `required`, `format`, `enum jsonb`, `min`, `max`, `min_len`, `max_len`, `pattern`, `example`, `sensitive bool` | Field catalog; `sensitive` drives masking |
| `dependency_edge` | `spec_version_id`, `from_target_id`, `to_target_id`, `field_mapping jsonb`, `source enum(explicit, heuristic, ai)`, `confidence numeric`, `status enum(proposed, confirmed, rejected)` | Graph |
| `business_rule` | `spec_version_id`, `rule_text`, `condition jsonb`, `outcome jsonb`, `rule_type enum(validation, state_transition, authorization, calculation)`, `applies_to_target_ids[]`, `applies_to_fields[]`, `source_story`, `source_sentence`, `confidence`, `status`, `embedding vector(768)` | R2 |
| `suite` | `workflow_id`, `spec_version_id`, `version int`, `status` (section 8), `coverage_snapshot jsonb`, `generation_round int`, `approved_by`, `approved_at` | Freezes on approval |
| `test_case` | `suite_id`, `case_id text` (stable, `TC-{workflow_short}-{seq}`), `version int`, `title`, `engine enum(karate, playwright)`, `type enum(positive, negative, boundary, security, business_flow, kafka)`, `priority enum(p1, p2, p3)`, `status enum(draft, approved, rejected, deprecated)`, `confidence enum(high, medium, low)`, `confidence_reason`, `origin enum(rule_engine, ai, imported, manual)`, `source_rule_id`, `source_story`, `spec jsonb` (canonical case, section 7), `locked bool`, `zephyr_key`, `jira_story`, `row_version int` | Unique `(suite_id, case_id)` |
| `test_case_target` | `test_case_id`, `target_id`, `ordinal int` | Ordered chain |
| `coverage_link` | `test_case_id`, `dimension enum(structural, response_code, schema, boundary, dependency, security, business_rule)`, `target_ref text` (e.g. `op:{key}:409`, `field:{key}:req:member.dob`) | Coverage is a group-by on this table |
| `data_set` | `test_case_id`, `environment_id`, `version int`, `uri` (GCS JSON), `rows_uri` (CSV), `placeholders jsonb` | Per case and environment |
| `data_record` | `environment_id`, `catalog_name`, `attributes jsonb`, `mode enum(shared, consumable)`, `state`, `allocated_run_id` | QA catalog (R2) |
| `data_binding` | `test_case_id`, `environment_id`, `data_record_id`, `reason text`, `status enum(bound, blocked)`, `blocked_reason` | Shown at approval and in defects |
| `script` | `test_case_id`, `test_case_version`, `repo_path`, `commit_sha`, `generated_by enum(template, ai)`, `validation jsonb`, `validation_status enum(valid, needs_attention)`, `locked bool`, `row_version int` | One per case version |
| `run` | `workflow_id`, `environment_id`, `trigger enum(manual, schedule, jira_webhook, ci, rerun)`, `triggered_by`, `scope jsonb` (tags), `spec_version_id`, `suite_id`, `script_commit`, `data_version`, `build_version`, `status`, `preflight jsonb`, `k8s_job_name`, `started_at`, `ended_at`, `counts jsonb` | Reproducible from these fields |
| `result` | `run_id`, `test_case_id`, `state enum(passed, failed, error, flaky, skipped, blocked)`, `duration_ms`, `retried bool`, `fingerprint text`, `evidence_uri`, `assertion_error text`, `data_record_id` | Partitioned by month on `created_at` |
| `created_resource` | `run_id`, `target_id`, `resource_ref` (path with id), `delete_target_key`, `deleted_at` | Cleanup ledger |
| `triage_item` | `run_id`, `category enum(product_bug, contract_drift, test_issue, data_issue, environment_issue, flaky)`, `confidence`, `explanation`, `result_ids[]`, `qe_decision`, `defect_id` | R3 |
| `defect` | `workflow_id`, `jira_key`, `fingerprint`, `status`, `severity`, `regression_of_defect_id`, `test_case_ids[]` | R3 |
| `ai_job` | `kind enum(rules, design, csv_mapping, scripts, triage)`, `status`, `input_ref jsonb`, `prompt_version`, `model`, `tokens_in`, `tokens_out`, `cost_usd`, `trace_uri` (masked prompt and response in GCS), `attempts`, `error` | One per graph run |
| `outbox` | `topic`, `payload jsonb`, `published_at`, `attempts` | Relay polls unpublished rows |
| `audit_event` | `actor`, `action`, `entity`, `entity_id`, `before jsonb`, `after jsonb` | Separate from app logs; append-only |

### Rules

1. `case_id` never changes across versions; Zephyr keys and Karate tags use it.
2. `target_key` is computed at ingest: `operationId` if present and unique, else `f"{METHOD} {path}"` with path parameters normalized to `{}`; the diff step matches by key, then proposes renames where key differs but request and response schemas are equal.
3. Indexes: `(team_id, workflow_id, status)` on test\_case; `(run_id)` and `(fingerprint)` on result; `(suite_id, dimension)` on coverage\_link; `(published_at) where published_at is null` on outbox.
4. RLS policy on every table above except `outbox` and `team`: `using (team_id = current_setting('app.team_id')::uuid)`; the migration test fails if a new table lacks it.
5. `row_version` is checked with `WHERE row_version = :expected` on test\_case and script updates; mismatch returns 409.

## 7. Canonical test case and assertion DSL

`test_case.spec` is a JSON document conforming to the `TestCaseSpec` Pydantic model below; templates render Karate from it, the contract validator checks it, and Zephyr steps are generated from it. Prose appears only in `title` and `notes`.

```markdown
TestCaseSpec
  case_id: str                      # TC-CLM-0142
  title: str
  type: positive|negative|boundary|security|business_flow|kafka
  priority: p1|p2|p3
  steps: list[Step]                 # ordered; one step for single-endpoint cases
  data_requirement: DataRequirement | null
  coverage_targets: list[str]       # "op:PUT /claims/{}:409", "rule:R-12", "field:..."
  cleanup: list[CleanupRef]         # created resources to delete, by step alias
  notes: str | null

Step
  alias: str                        # "create_claim" — referenced by ${create_claim.response.body.claimId}
  target_key: str                   # operationId or "POST /claims"
  credential_profile: str = "default"
  request: RequestSpec
  expect: ExpectSpec
  side_effects: list[SideEffect]    # Kafka event expected/not expected (R3)
  timeout_ms: int = 30000

RequestSpec
  path_params: dict[str, Value]
  query: dict[str, Value]
  headers: dict[str, Value]         # never Authorization; auth comes from the profile
  body: BodySpec | null

BodySpec
  base: "sample" | "minimal_valid" | "data_row" | {"inline": object}
  mutations: list[Mutation]         # applied in order; negative/boundary cases have exactly one

Mutation
  op: set|remove|set_null|wrong_type|append_extra_field
  path: str                         # JSON pointer, "/member/dob"
  value: Value | null
  label: str                        # "dob in future" — shows in review and report

Value = literal | {"ref": "${alias.response.body.path}"} | {"gen": "uuid|now|today-30d|unique_suffix|email|zip_for_state:${...}"}

ExpectSpec
  status: int | [int]               # 409 or [200, 201]
  headers: list[HeaderAssertion]
  body: list[BodyAssertion]
  schema_ref: str | null            # "#/components/schemas/Claim" -> karate match schema
  max_latency_ms: int | null

BodyAssertion
  path: str                         # JSONPath, "$.errorCode"
  op: eq|neq|present|absent|contains|matches|gt|gte|lt|lte|in|type
  value: Value | null
  message: str | null

SideEffect
  kind: kafka_event
  topic: str
  correlation: {"key_path": "$.claimId", "from": "${create_claim.response.body.claimId}"}
  expected: bool                    # false = assert no event within timeout
  assertions: list[BodyAssertion]
  timeout_ms: int = 10000

DataRequirement
  description: str                  # "an active member over 65"
  filters: dict[str, Filter]        # {"status": {"eq": "ACTIVE"}, "age": {"gte": 65}}
  mode: shared|consumable
```

### Worked example

```markdown
{
  "case_id": "TC-CLM-0142",
  "title": "Reject update of adjudicated claim",
  "type": "negative", "priority": "p1",
  "steps": [
    {"alias": "create", "target_key": "createClaim",
     "request": {"body": {"base": "sample", "mutations": []}},
     "expect": {"status": 201, "body": [{"path": "$.claimId", "op": "present"}]}},
    {"alias": "adjudicate", "target_key": "adjudicateClaim",
     "request": {"path_params": {"claimId": {"ref": "${create.response.body.claimId}"}}},
     "expect": {"status": 200, "body": [{"path": "$.status", "op": "eq", "value": "ADJUDICATED"}]}},
    {"alias": "update", "target_key": "updateClaim",
     "request": {"path_params": {"claimId": {"ref": "${create.response.body.claimId}"}},
                 "body": {"base": "sample", "mutations": [{"op": "set", "path": "/amount", "value": 500, "label": "amount changed"}]}},
     "expect": {"status": 409, "body": [{"path": "$.errorCode", "op": "eq", "value": "CLAIM_LOCKED"}]}}
  ],
  "coverage_targets": ["op:updateClaim:409", "rule:R-12", "field:updateClaim:req:/status"],
  "cleanup": [{"alias": "create", "delete_target_key": "deleteClaim"}]
}
```

### Validation rules the model enforces

1. Every `target_key` exists in the suite's spec version; every `expect.status` is documented for that target (or the case is rejected as a hallucination).
2. Every `BodyAssertion.path` resolves to a field in the response schema for that status, unless `op` is `absent`.
3. Every `${alias...}` reference points to an earlier step.
4. `type=negative|boundary` has exactly one mutation across all steps' bodies; `type=positive` has none.
5. Data-driven cases carry `body.base = data_row` and one attached data set; each row is one Karate Scenario Outline example.
6. `headers` never contain `Authorization`, `Cookie` or `X-Api-Key`; credentials are injected from the profile at run time.
7. Case IDs are minted by the platform, never by the LLM; AI drafts arrive with `case_id = null` and are assigned on insert.

## 8. Workflow state machine and human gates

Three state machines (spec version, suite, run) live in `orchestration/`; every transition is a function that checks the guard, writes the new status, an audit event and an outbox event in one transaction. Gates are transitions only a human role may call.

```mermaid
stateDiagram-v2
  [*] --> generating
  generating --> measuring: rule engine done
  measuring --> generating: gaps and round < 3
  measuring --> awaiting_review: thresholds met or round = 3
  awaiting_review --> awaiting_review: approve / edit / reject case
  awaiting_review --> approved: QE approves (guard: P1 reviewed, thresholds or accepted gaps)
  approved --> building: data + scripts started
  building --> ready: all scripts valid
  building --> needs_attention: script repair failed
  needs_attention --> building: QE fixed or regenerated
  ready --> superseded: new spec version
  approved --> published: Zephyr publish (optional)
```

| Machine | States | Actors |
| --- | --- | --- |
| `spec_version` | `uploaded → normalized → checking → ready(green/yellow) / red → accepted → superseded` | Platform; QE acknowledges yellow, fixes red |
| `suite` | as in the diagram | Platform, AI worker (draft writes only), QE, QE lead |
| `run` | `requested → preflight → env_not_ready / running → collecting → completed → synced`; `cancelled` from any pre-terminal state | Platform, runner, QE cancel |
| `ai_job` | `queued → running → done / failed / cancelled` with `attempts ≤ 3` | Worker |

### Gate definitions

| Gate | Transition | Who | Guard | Recorded |
| --- | --- | --- | --- | --- |
| Smoke check | `spec_version: ready → accepted` | QE (yellow), platform (green) | Red blocks; yellow needs `ack_reason` | audit + readiness report |
| Rules review (R2) | `api_model: awaiting_review → confirmed` | QE | Every low-confidence edge and rule has a decision | per-item decisions as few-shot feedback |
| QE approval | `suite: awaiting_review → approved` | QE; QE lead for `accept_gap` and threshold changes | All P1 cases decided; every dimension ≥ threshold or has an accepted gap; low-confidence cases cannot be bulk approved | audit per case |
| Data review (R2) | `data: awaiting_review → ready` | QE | Required only if a CSV was uploaded; blocked bindings listed | mapping decisions |
| Defect review (R3) | `triage_item: awaiting_review → decided` | QE | Category and defect draft confirmed, reclassified or dismissed | reclassification as triage feedback |

Actions at every gate are `approve`, `edit`, `reject(reason)`, `regenerate(comment)`, and for cases `add_manual`. Bulk actions take a filter (`endpoint`, `dimension`, `confidence=high`) and are logged as one audit event with the affected ids.

### Orchestrator rules

1. A graph or engine step runs to completion and stops; the next step starts only on a transition, never inside LangGraph.
2. Transitions are idempotent: calling `approve` on an approved suite returns 200 with no change.
3. A new spec version supersedes the open suite; unchanged cases (same target key, same schema hash, same rule set) are copied into the new suite as `approved` with the same `case_id`; impacted cases return to `draft` with the diff attached.
4. Locked cases and scripts are never overwritten by regeneration; they receive a `stale` flag with the diff.
5. Cancel is allowed on `ai_job` and `run`; a cancelled run's Job is deleted and allocated records released.

## 9. Platform REST API

All routes under `/api/v1`, JSON, cursor pagination (`?cursor=&limit=`), problem-details errors (RFC 9457), `Idempotency-Key` header honoured on every POST that creates work. The generated OpenAPI file is committed to `docs/openapi/platform.yaml` and is the contract for the Angular app, CI clients and the UI testing product.

| Area | Endpoints (MVP unless marked) | Notes |
| --- | --- | --- |
| Auth | `GET /me`; `POST /teams/{id}/api-keys`, `DELETE …/{keyId}` | OIDC bearer for users, `X-Api-Key` for machines |
| Teams | `GET/PATCH /teams/{id}` (settings), `GET /teams/{id}/members` | Admin, QE lead |
| Workflows | `POST/GET /workflows`, `GET/PATCH/DELETE /workflows/{id}` | `kind=api` here; `ui` shared |
| Environments | `POST/GET /workflows/{id}/environments`, `PATCH /environments/{id}` | Freeze windows, limits |
| Credentials | `POST /environments/{id}/credential-profiles` (body holds the secret once, written to Secret Manager, response returns `secret_ref` only), `GET` (no values), `DELETE`, `POST …/{id}/verify` | Separate router, request body never logged |
| Spec versions | `POST /workflows/{id}/spec-versions` (multipart file or `url`), `GET …`, `GET …/{v}/diff`, `POST …/{v}/accept` (yellow ack), `GET …/{v}/readiness` | Triggers normalize and smoke check |
| API model | `GET /spec-versions/{v}/targets`, `GET …/fields`, `GET …/dependency-edges`, `PATCH /dependency-edges/{id}` (confirm/reject), `GET …/coverage-universe` | Discover output |
| Rules (R2) | `POST /spec-versions/{v}/stories` (ids, epic or JQL), `GET/PATCH /business-rules/{id}`, `POST /spec-versions/{v}/rules/confirm` | Gate |
| Suites | `POST /spec-versions/{v}/suites` (generate), `GET /suites/{id}`, `GET …/coverage` (matrix), `POST …/regenerate` (comment, scope), `POST …/approve`, `POST …/accept-gap` (lead), `POST …/publish` (R2) | 202 with `job_id` for long work |
| Test cases | `GET /suites/{id}/test-cases?endpoint=&dimension=&confidence=&status=`, `GET/PATCH /test-cases/{id}` (`If-Match: row_version`), `POST …/approve`, `POST …/reject`, `POST /suites/{id}/test-cases:bulk` (action + filter), `POST /suites/{id}/test-cases` (manual) | Review queue |
| Data (R2) | `POST /suites/{id}/csv` (upload), `GET/PATCH /csv/{id}/mapping`, `POST …/confirm`, `GET /test-cases/{id}/data-sets`, `GET /environments/{id}/catalog`, `POST …/catalog` (upload), `GET /suites/{id}/blocked` | Data gate |
| Scripts | `POST /suites/{id}/scripts:generate`, `GET /suites/{id}/scripts`, `GET/PUT /scripts/{id}` (content via Git, `If-Match`), `POST /scripts/{id}/validate`, `POST /scripts/{id}/unlock` | Editing locks |
| Runs | `POST /runs` (workflow, environment, scope tags, trigger), `GET /runs?workflow=&env=`, `GET /runs/{id}`, `GET …/results`, `GET /results/{id}/evidence` (signed URL), `POST /runs/{id}/cancel`, `POST /runs/{id}/rerun-failed` | Scope tags: `@TC-…`, `@p1`, `@endpoint:…` |
| Reports | `GET /runs/{id}/report`, `GET /workflows/{id}/dashboard` (R3), `GET /portfolio` (R3), `GET /runs/{id}/report.pdf` (R3) | Numbers computed in SQL |
| Triage and defects (R3) | `GET /runs/{id}/triage`, `PATCH /triage-items/{id}` (reclassify, edit draft, dismiss), `POST …/create-defect`, `GET /workflows/{id}/defects` | Gate |
| Jobs | `GET /jobs/{id}`, `POST /jobs/{id}/cancel`, `GET /workflows/{id}/jobs` | AI jobs and long tasks |
| Events | `GET /events/stream?workflow=` (SSE) | `suite.updated`, `run.updated`, `job.updated`, `script.updated` |
| Webhooks | `POST /webhooks/jira` (R3, HMAC), `POST /triggers/deploy` (API key; workflow, environment, build\_version) | Internal LB only |
| Health | `GET /healthz`, `GET /readyz`, `GET /metrics` | Prometheus format |

Role matrix: `qe` may do everything except `accept-gap`, threshold changes, team settings, API keys and credential deletion; `qe_lead` adds those within the team; `admin` adds team creation and member management. Every handler calls `authorize(user, action, entity)`; there is no route without a permission.

## 10. Pub/Sub topics, event contracts, outbox and idempotency

Four topics, each with a dead-letter topic after 5 delivery attempts; every message is a CloudEvents 1.0 JSON envelope with `id` (= outbox row id), `type`, `source`, `subject` (entity id), `time`, `team_id`, `trace_id`, `data`.

| Topic | Producer | Consumer | Event types | Ordering key |
| --- | --- | --- | --- | --- |
| `ai-jobs` | platform-api (outbox) | ai-worker | `ai_job.requested` | `job_id` |
| `ai-results` | ai-worker | platform-api worker | `ai_job.done`, `ai_job.failed` | `job_id` |
| `run-events` | platform-api (outbox), runner | platform-api worker | `run.requested`, `run.shard_done`, `run.completed`, `run.failed` | `run_id` |
| `jira-events` | webhook route (outbox) | platform-api worker | `defect.status_changed` | `jira_key` |

### Outbox relay

1. Any service method that must emit an event calls `outbox.publish(session, topic, event)`; the row commits with the business change.
2. A single leader-elected relay task (Kubernetes Lease) polls `outbox where published_at is null order by id limit 500` every 500 ms, publishes with `ordering_key`, sets `published_at`; failures increment `attempts` and back off.
3. Rows are purged 7 days after publishing.

### Consumer idempotency

- Every consumer records `processed_event(event_id)` in the same transaction as its side effects; a duplicate event is acknowledged and skipped.
- AI workers claim a job with `UPDATE ai_job SET status='running', attempts=attempts+1 WHERE id=:id AND status='queued'`; zero rows means another worker has it.
- Results ingestion upserts `result` on `(run_id, test_case_id)`.
- Jira and Zephyr writes carry the platform's ids in custom fields and upsert on them; comments carry a hidden marker `[apitest:{event_id}]` to detect duplicates.

### Message payloads

```markdown
ai_job.requested.data
  job_id, kind, team_id, workflow_id, input_ref {suite_id | spec_version_id | run_id, scope}, prompt_version_pin?, budget {max_tokens, timeout_s}

ai_job.done.data
  job_id, output_ref {drafts_count, warnings[]}, usage {tokens_in, tokens_out, cost_usd, model}

run.requested.data
  run_id, workflow_id, environment_id, scope_tags[], script_commit, data_version, shards[]

run.completed.data
  run_id, shards_done, report_uris {karate_json, junit_xml, html}, evidence_prefix, exit_code

defect.status_changed.data
  jira_key, from_status, to_status, changed_by, received_at
```

SSE events to the browser are derived from these after the platform has applied them; the browser never subscribes to Pub/Sub.

## 11. Rule engine, coverage engine and contract validation

Three pure, deterministic Python packages in `modules/design/`; they take the API model and return `TestCaseSpec` objects, coverage numbers, or validation findings, with no I/O, so they are unit-testable and callable from AI graphs in-process.

### Rule engine generators

| Generator | Input | Emits per | Cases |
| --- | --- | --- | --- |
| `structural` | target | operation | One positive: `minimal_valid` body, documented success status, `schema_ref` match |
| `response_code` | target.responses | documented code | 400 (one required field removed), 401 (`credential_profile=none`), 403 (`credential_profile=read_only` or wrong scope), 404 (unknown id, `gen: uuid`), 405 (undocumented method, only if the spec lists 405); 409 and 422 only from rules (R2) |
| `schema` | request fields | operation | One data-driven case with rows: per required field `remove`, `set_null`, `wrong_type`; per optional field `wrong_type`; `append_extra_field` once if `additionalProperties: false` |
| `boundary` | constrained fields | operation | Rows: `min-1`, `min`, `max`, `max+1`, empty string, `minLength-1`, `maxLength+1`, invalid enum, invalid format (date, email, uuid), unicode and whitespace strings |
| `dependency` | confirmed edges | edge chain | CRUD lifecycle (create, get, update, delete, get-after-delete = 404), prerequisite chain, wrong-order call, deleted-id reuse |
| `security` | protected targets, environment flag | operation | No token 401, expired token 401, wrong scope 403, other identity's record 403/404 (`credential_profile=member_b`), injection strings in string params (expect 400/422, never 500), response contains no field marked `sensitive` beyond the schema |
| `business_rule` (R2) | confirmed rules | rule | Handed to the AI design graph; the engine emits only the coverage target so the gap is visible |

Schema handling in `minimal_valid` and mutations:

1. `allOf` merged; `oneOf`/`anyOf` generate one positive per branch (discriminator value set), boundary rows only on the first branch unless the team cap allows more.
2. Recursion depth capped at 3; arrays get `minItems` or 1 element; `readOnly` fields are omitted from requests, `writeOnly` from response assertions.
3. `nullable` fields get a `set_null` positive row rather than a negative.
4. Examples in the spec win over generated values; the sample payload wins over both.

### Consolidation, priority and confidence

- Dedup key: `(sorted target_keys, expect.status, sorted body assertion (path, op, value), sorted mutations)`; duplicates merge, keeping the union of `coverage_targets`.
- Priority: P1 = positive cases, security auth checks, and any case on a target tagged critical or on a mutating operation; P2 = response codes and dependency; P3 = boundary and optional-field rows. Teams may override by tag in `team.settings`.
- Confidence: rule-engine cases from explicit constraints are `high`; anything from a heuristic edge is `medium`; AI cases follow section 12.
- Per-endpoint cap (default 40 cases, rows counted separately) enforced by dropping lowest priority first, recording what was dropped as a coverage gap of kind `capped`.

### Coverage engine

Coverage per dimension is `count(distinct covered target_ref) / count(universe target_ref)`, computed from `coverage_link` against the `coverage_universe` built by Discover.

| Dimension | Universe `target_ref` | Default threshold |
| --- | --- | --- |
| structural | `op:{key}` | 100% |
| response\_code | `op:{key}:{code}` minus not-triggerable | 90% |
| schema | `field:{key}:req:{path}` | 100% required, 80% optional |
| boundary | `field:{key}:req:{path}` where constrained | 80% |
| dependency | `edge:{from}->{to}` with confidence ≥ 0.8 or confirmed | 100% |
| security | `sec:{key}:{check}` for protected ops | 100% |
| business\_rule | `rule:{id}` confirmed | 100% |

The engine returns the matrix (target × dimension: covered, total, gap list) and a `suite.coverage_snapshot` is stored on every measurement so history survives.

### Contract validator

Runs on every draft, whatever its origin, before it is saved as `draft`:

1. Target exists; status documented for target; assertion paths exist in the response schema for that status.
2. Mutation paths exist in the request schema; `wrong_type` value type differs from the declared type.
3. Positive cases send a body that validates against the request schema after mutations (there are none); negative cases send one that fails validation for exactly the mutated field, or that targets a documented business error.
4. Findings are `error` (reject and regenerate) or `warning` (keep, show at review). AI drafts with errors are returned to the graph as repair input; rule-engine drafts with errors fail the build, since that indicates an engine bug.

The coverage loop: `generate → validate → measure → target gaps`, at most 3 rounds; the MVP runs one round because only the rule engine produces cases.

## 12. AI graphs (LangGraph)

Five short-lived graphs, each a fixed sequence of nodes with a bounded loop and a Pydantic output schema; there is no free-form agent and no tool the graph can discover at run time. All are R2 except triage (R3); the MVP ships the `LLMProvider` interface and the PHI guard with no graph wired.

| Graph | Trigger | Context given to the model | Output model | Loop and limit | Model tier |
| --- | --- | --- | --- | --- | --- |
| `rules` | Stories attached to a spec version | Story text (masked), endpoint inventory names and paths only, field names for referenced resources | `list[BusinessRuleDraft]` with `source_sentence` required | Single pass; structured output | Strong |
| `design` | Coverage gaps after the rule engine | For one target: its schema slice, documented responses, confirmed rules touching it, current gap list, 3 approved example cases (reference set in R2, pgvector in R3), the `TestCaseSpec` schema | `list[TestCaseSpec]` (`case_id` null) | Generate → contract-validate → regenerate only invalid or missing; 3 rounds | Strong |
| `csv_mapping` | CSV uploaded | Headers, 5 masked rows, field catalog for the chosen target | `Mapping {column → field_path, confidence}` | Validate against schema; 1 retry | Fast |
| `scripts` | Cases not coverable by templates | One `TestCaseSpec`, the spec slice, helper feature signatures, conventions guide, 2 pattern examples for the matched pattern | `KarateScenario {feature_path, gherkin, helpers_used}` | Generate → parse, static, contract, Prism run → repair with the error; 2 repairs | Strong |
| `triage` (R3) | Failures signals cannot settle | Masked request and response, expected vs actual, rule, spec slice, case history, cluster peers | `TriageDecision {category, confidence, explanation, defect_draft}` | Single pass | Fast |

### Rules every graph follows

1. Nodes call deterministic functions from `modules/` in-process: `api_model.slice(target)`, `contract_validator.validate(case)`, `coverage.measure(suite)`, `karate.parse(feature)`, `prism.run(feature)`.
2. Every model call goes through `LLMProvider.complete(prompt, schema, budget)`; the provider enforces the PHI guard on input, JSON schema on output, token budget, timeout, and records an `ai_job` usage line.
3. Invalid output (schema or contract) is retried once with the error appended; a second failure marks the job `failed` with the artifacts kept for the harness. Nothing invalid is ever saved as a draft.
4. Prompts are files with a version; the system prompt states the deterministic rules already applied so the model does not duplicate them ("structural, schema and boundary cases already exist; produce only business and semantic cases for the gaps listed").
5. Context is a slice: never the whole spec, never full data records, never credentials, never stack traces with hostnames.
6. Gemini context caching is used for the stable prefix (conventions guide, pattern library, schema definitions) per workflow; cache TTL 1 hour.
7. Confidence assigned by the graph: `medium` when every assertion traces to a confirmed rule or documented response; `low` otherwise. The graph cannot emit `high`.

### Provider interface

```markdown
class LLMProvider(Protocol):
    def complete(self, *, system: str, user: str, schema: type[BaseModel],
                 tier: Literal["fast", "strong"], budget: Budget, cache_key: str | None) -> Completion

class Completion(BaseModel):
    parsed: BaseModel
    usage: Usage           # tokens_in, tokens_out, cost_usd, model, cached_tokens
    raw_uri: str           # GCS path of masked prompt+response
```

The Gemini implementation is the only one in v1; the interface exists so the evaluation harness can run a recorded-response provider offline in CI.

## 13. Karate reference framework, templates and dry-run validation

Engineers build the reference framework by hand against the pilot API before any generator code is written; the generator only fills templates derived from it, and the `scripts` graph (R2) writes scenarios that must fit inside it.

### Generated project layout (one folder per workflow in `test-assets`)

```markdown
workflows/{workflow_slug}/
  karate-config.js          # reads env vars: BASE_URL, AUTH_*; selects env by karate.env
  auth/token.feature        # one token per credential profile per run, cached with callSingle
  helpers/                  # prerequisite chains and cleanup, e.g. claim-create-adjudicate.feature
  features/{target_key}.feature   # one feature per operation; one Scenario per case; Outline for rows
  data/{env}/{case_id}.json       # base payload, variations (from Stage 5)
  data/{env}/{case_id}.csv        # rows for outlines
  schemas/{SchemaName}.json       # response schemas from the spec
  kafka/                    # helper jar reference and topic config (R3)
  manifest.json             # suite_id, spec_version, case_id → feature:line, template versions
```

Every Scenario carries tags `@TC-{case_id} @{priority} @{type} @endpoint:{target_key} @zephyr:{key}`; the runner selects by tag expression only.

### Template catalogue (MVP)

| Template | Covers | Rendered from |
| --- | --- | --- |
| `positive_schema_match` | structural | status + `match response == read('schemas/X.json')` + body assertions |
| `status_only` | response codes 401, 403, 404, 405 | credential profile switch + status |
| `field_negatives_outline` | schema, boundary rows | Scenario Outline with columns `path, op, value, expected_status, label`; a shared helper applies the mutation with `karate.set` |
| `dependency_chain` | dependency cases | sequential steps with `def` captures, cleanup in `afterScenario` via helper |
| `security_identity` | object-level authorization | token from `member_b` profile, expect 403 or 404 |
| `injection_outline` | security injection | Outline over an injection string set, expect status in \[400, 422\] |
| `graphql_query` (R3) | GraphQL | query file + variables JSON |
| `kafka_publish_assert` (R3) | Kafka | call helper jar, poll with timeout, match |

Template selection is deterministic: `select_template(spec) -> template | None`; `None` means the case needs the AI graph (R2) or is marked `needs_attention` in the MVP.

### Rendering rules

1. `${alias.response.body.path}` becomes a Karate `def` captured after that step and referenced by variable name.
2. `gen:` values become `karate-config` helpers (`uuid()`, `today(-30)`, `uniqueSuffix()`); no literal dates in features.
3. Credentials are read from variables injected by the runner: `AUTH_{PROFILE}_TOKEN_URL`, `AUTH_{PROFILE}_CLIENT_ID`, `AUTH_{PROFILE}_CLIENT_SECRET` or `AUTH_{PROFILE}_BEARER`; mTLS profiles get `AUTH_{PROFILE}_CERT_PATH`.
4. Generated files carry a header comment `# generated: suite {id} case {case_id} v{n} template {name}@{ver}` so drift is detectable; a locked script keeps the same header with `# locked by {user}`.

### Validation pipeline

| Step | Where | Tool | Fails when |
| --- | --- | --- | --- |
| Parse | platform-api | Python Gherkin parser + Karate keyword grammar | Feature does not parse, called feature missing, undefined variable |
| Static | platform-api | Regex and AST rules | Hardcoded URL, secret-looking string, `Authorization` header, missing tags, PHI pattern |
| Contract | platform-api | Contract validator on the rendered assertions | Asserted status or path not in spec |
| Mock run (R2) | runner Job, `validate` mode | Prism sidecar serving the normalized spec with `--errors`; Karate runs the feature against it | Scenario fails against the mock for reasons other than dynamic examples |
| Repair (R2) | ai-worker | `scripts` graph with the error | After 2 repairs, `needs_attention` |

The mock run only proves script logic and contract fit; dynamic chains that need real ids are executed with Prism's `x-` example overrides or skipped with a warning, never marked failed.

### Git handling

- Each generation is one commit by the service account: `suite {id} v{n}: {added}/{changed}/{unchanged}`; the commit SHA is stored on every `script` row and pinned by every run.
- QE edits through the product produce a commit with the user's name in the message; direct pushes to the repo are blocked by branch protection.
- Regeneration after a spec change touches only files for impacted cases; locked files are never written.

## 14. Execution runner

One Kubernetes Job per run in the `runners` namespace, from a pinned image, with everything it needs passed as a run manifest; the platform never execs into pods and the runner never talks to the database.

### Runner image

| Layer | Content |
| --- | --- |
| Base | `eclipse-temurin:21-jre` (pinned digest) |
| Karate | `karate-1.5.x.jar` standalone, checksum verified at build |
| Helpers | `kafka-helper.jar` (R3), `prism` binary (validate mode only) |
| Entrypoint | `entrypoint.sh`: fetch manifest, `git clone --depth 1` at `script_commit`, download data set version, resolve secrets to env vars, run shards, upload artifacts, publish `run-events` via Pub/Sub REST, exit |
| Security | Non-root, read-only root filesystem, no shell for the Job's service account beyond entrypoint, CPU 1 to 2, memory 2 to 4 GiB per pod |

### Job spec (rendered by the launcher)

- Labels: `run_id`, `workflow_id`, `team_id`, `environment`; `ttlSecondsAfterFinished: 3600`; `backoffLimit: 0` (retries are per case, not per Job); `activeDeadlineSeconds` = team setting, default 3600.
- `parallelism` = number of shards (features split by estimated duration, max 8); each pod takes shard `JOB_COMPLETION_INDEX`.
- Secrets: Workload Identity service account per team; Secret Manager CSI mounts the credential profiles listed in the manifest to `/var/run/secrets/apitest/`; entrypoint exports them as the `AUTH_*` variables and never echoes them.
- NetworkPolicy per environment allows egress to that environment's hosts, GCS, Pub/Sub and the Git host only.
- Node selector `pool=runners`, toleration for spot; priority class lower than platform workloads.

### Pre-flight (platform side, before the Job)

1. Freeze window and concurrency limit for the environment; queue if exceeded, with a visible position.
2. Token for each credential profile in scope; one safe call per workflow; Kafka reachability if in scope.
3. Allocate consumable `data_record` rows for the cases in scope; mark unmatched cases `blocked`.
4. Record `build_version` from the API's version endpoint when one is configured.
5. Any red item stops the run as `env_not_ready` with the failing check; the QE and the environment owner are notified once, not per case.

### Retry, flake and timeout

- Karate runs with `-T` parallel threads per pod (default 4) and per-scenario timeout from the case (`timeout_ms`).
- The entrypoint reruns scenarios whose failure matches network or 5xx patterns once, using a rerun tag file; the result carries `retried=true`; a pass after retry is recorded as `flaky`. Assertion failures are never retried.
- Per-environment `rate_limit_rps` is enforced with a token bucket in `karate-config.js` (`karate.pause`) so shared QA systems are not overloaded.

### Evidence and masking

- Every request and response is captured through a Karate `HttpLogModifier` that masks `Authorization`, `Cookie`, `X-Api-Key`, and any JSON path whose field is `sensitive=true` in the field catalog; masking happens in the pod before upload.
- Artifacts under `gs://evidence/{team}/{run_id}/`: `karate-summary.json`, `junit/*.xml`, `html/`, `calls/{case_id}/{step}.json`, `logs/pod-{index}.log`.
- Lifecycle: full evidence 90 days, summaries 2 years; bucket has object versioning and uniform access.

### Result ingestion (platform worker on `run.completed`)

1. Download `karate-summary.json`; map each scenario by its `@TC-` tag to a `test_case_id`; upsert `result` rows with state, duration, retried flag, assertion error and evidence path.
2. Compute `fingerprint = sha1(target_key | assertion_type | status | normalized_error)`; normalized error strips ids, timestamps and UUIDs.
3. Update `run.counts`, set `completed`, release records, emit SSE and, when enabled, the Zephyr sync event.
4. Cleanup: the manifest lists `created_resource` rows written by the helper features through a tiny log the entrypoint uploads; the sweeper deletes any resource without `deleted_at` using the recorded delete target, then marks it; failures after 3 attempts appear on the run report as "orphaned resources".

## 15. Integrations: Jira, Zephyr, webhooks, CI trigger

All external systems sit behind interfaces in `modules/integration/` (`DefectTracker`, `TestManagement`, `SpecSource`); v1 implements Jira Cloud or Data Center REST and one Zephyr flavour, chosen in week one (section 19).

### Zephyr (R2)

| Concern | Rule |
| --- | --- |
| Enablement | `team.settings.zephyr.enabled`, `publish_priorities` (default `[p1, p2]`), `project_key`, `folder_root` |
| Identity | Our `case_id` in a Zephyr custom field; upsert by it; the Zephyr key stored on `test_case.zephyr_key` |
| Mapping | Title → name; steps rendered from `TestCaseSpec` (one step per `Step`, expected result from `ExpectSpec`); rows → parameterized data (Scale) or a table in the description (Squad); priority → priority; type and dimensions → labels; workflow and target → folder; story → traceability link |
| Publishing | Asynchronous job, batches of 50, respects `Retry-After`; publish report lists created, updated, failed with reasons |
| Deprecation | Rejected or retired cases set to a `Deprecated` status, never deleted |
| Drift | Nightly compare of Zephyr `updatedOn` with our publish time; changed-in-Zephyr cases flagged for import or overwrite |
| Results | One test cycle per run named `{workflow} {env} {yyyy-mm-dd} #{run_no}`; execution status mapping: passed→Pass, failed→Fail, error→Fail with comment, flaky→Pass with comment, blocked→Blocked, skipped→Not executed; each execution links to the evidence URL |

### Jira (R2 stories, R3 defects)

- Stories: `GET /rest/api/3/search` by ids, epic or JQL, with fields summary, description, acceptance criteria custom field (configurable), comments off by default (PHI risk); description is run through the PHI guard before storage.
- Defects: issue type Bug, fields component (API), priority from severity matrix (P1 product bug → Highest), labels `apitest`, `{workflow_slug}`; custom fields `apitest_fingerprint`, `apitest_case_ids`; links `relates to` the story, remote link to the Zephyr execution and to the run report.
- Dedup: search by `apitest_fingerprint`; open → comment with occurrence; closed → new issue with `regression_of` link.
- Rerun trigger: webhook on issue transition; `team.settings.jira.ready_for_qa_statuses` names the statuses; payload verified by HMAC secret per team (Jira Cloud) or shared secret header (Data Center); the handler only reads `issue.key` and the new status, looks up our `defect` row and enqueues `run.requested` with scope `defect:{key}`.
- Comments the product writes carry `[apitest:{event_id}]` for idempotency and a link back.

### CI deploy trigger (MVP endpoint, hardened R3)

`POST /triggers/deploy` with `X-Api-Key`; body `{workflow_id, environment, build_version, scope?: "p1" | "full"}`; returns `202 {run_id}`; rate limited per key; a run already queued for the same workflow and environment within 60 seconds is coalesced.

### Spec sources (R3)

`SpecSource` interface with `list()` and `fetch(id)`; first implementation for the company API gateway or catalog so onboarding can import specs in bulk; the MVP implements file and URL upload only.

### Notifications

On `run.completed`, `run.env_not_ready` and `suite.awaiting_review`: Teams webhook and email per team settings, one message per event with a deep link; no per-case notifications.

## 16. Security, PHI, tenancy, secrets

The platform handles no unmasked PHI by design; the controls below make that true in code, not policy.

| Control | Implementation | Verified by |
| --- | --- | --- |
| User auth | OIDC (company IdP) via Authorization Code + PKCE in Angular; platform validates JWT, maps groups to `team_member.role` | Integration test with a mock IdP |
| Machine auth | `api_key` hashed with Argon2id, scoped (`runs:write`, `triggers:deploy`), expiry, last-used tracking | Unit tests |
| Authorization | `authorize(user, action, entity)` in every handler; role matrix in section 9 | Contract test enumerates routes and asserts a permission is declared |
| Tenancy | `team_id` on every row; RLS with `app.team_id` set per session; service-role connections used only by the outbox relay and migrations | Migration test fails on a table without RLS; cross-team read test |
| Secrets | Written only by the credential endpoint to Secret Manager; DB stores `secret_ref`; pods read via Workload Identity and CSI; rotation by creating a new secret version and updating the ref | Log scrubber test with canary secrets |
| PHI in uploads | Sensitive Data Protection inspect on sample payloads, CSVs, stories; findings block (`block` mode for SSN, MRN patterns) or mask | Fixture uploads with seeded PHI |
| PHI in evidence | Field-catalog masking by path in the runner plus header masking; a nightly DLP scan on a 2% sample of evidence objects alerts on leaks | Sample scan job |
| PHI to the LLM | `PHIGuard.check(prompt)` runs the same field-based masking plus regex patterns; full data records never leave the platform, only attribute names and value profiles | Unit tests on the guard; harness prompts audited |
| Network | NetworkPolicy default deny per namespace; runner egress per environment; no route to Prod CIDRs; internal load balancer for webhooks with Jira IP allowlist | Policy tests in CI (`kubectl` dry run) and a quarterly egress probe |
| Transport | TLS everywhere; mTLS to target APIs when the profile requires it | Smoke check |
| Supply chain | Images pinned by digest, scanned (Artifact Registry), SBOM published; Karate JAR checksum verified | CI gate |
| Audit | `audit_event` append-only, retained 7 years, exported to the company SIEM | Retention policy |
| Data retention | Evidence 90 days, summaries 2 years, LLM traces (masked) 1 year, raw uploads for the life of the workflow | Bucket lifecycle rules |

Security tests against target APIs (injection strings, identity swaps) run only where `environment.security_tests_allowed` is true, and that flag can be set only by a QE lead; the generated injection set is the OWASP-style benign probe list, never payloads that could write or delete data.

## 17. Observability, SLOs, cost controls

Every log line, span and metric carries `team_id`, `workflow_id`, and where present `run_id`, `job_id`, `suite_id`; one trace id follows a request from the browser through Pub/Sub to the runner.

### SLOs (product's own, measured monthly)

| SLO | Target | Alert |
| --- | --- | --- |
| Platform API availability | 99.9% | Error ratio > 1% for 5 min |
| Review queue load time (p95) | < 1.5 s for a 500-case suite | p95 > 3 s |
| Rule-engine suite generation | < 60 s for 50 endpoints | > 180 s |
| AI job latency (p95, R2) | Design < 5 min per target batch; CSV mapping < 30 s | Queue age > 15 min |
| Run start latency | Pre-flight to pod running < 90 s | > 5 min |
| Result ingestion lag | < 60 s after `run.completed` | > 5 min |
| Outbox lag | < 5 s | Unpublished rows older than 60 s |

### Metrics (Prometheus names)

`apitest_http_requests_total`, `apitest_http_duration_seconds`, `apitest_outbox_unpublished`, `apitest_ai_job_duration_seconds{kind}`, `apitest_ai_tokens_total{kind,model,direction}`, `apitest_ai_cost_usd_total{team,kind}`, `apitest_run_duration_seconds`, `apitest_run_results_total{state}`, `apitest_preflight_failures_total{check}`, `apitest_flaky_rate{workflow}`, `apitest_zephyr_publish_failures_total`, `apitest_orphaned_resources_total`.

### Logging and tracing

- Structured JSON via `structlog`; secrets and PHI scrubbed by a processor that runs before emit; log level per module via settings.
- OpenTelemetry auto-instrumentation for FastAPI, SQLAlchemy, Pub/Sub client, HTTPX; manual spans per graph node; exporter to Cloud Trace.
- LLM traces: masked prompt and response stored in GCS per `ai_job`, viewable in the product for QE leads and admins; no SaaS tracing.
- Runner pod logs shipped by the GKE logging agent with the run labels.

### Cost controls

| Lever | Rule |
| --- | --- |
| Token budgets | Per graph run (`Budget.max_tokens`) and per workflow per month (`team.settings.ai.monthly_token_cap`); over cap → job queued and QE lead notified |
| Model tiers | Fast tier for mapping and triage; strong tier for design and scripts; tier per graph configurable without code change |
| Context caching | Stable prefix cached per workflow for 1 hour; cached-token share reported on the dashboard |
| Deterministic first | Rule engine covers structural, schema, boundary, dependency and security; AI is asked only for gaps, so tokens scale with rules and gaps, not endpoints |
| Runner nodes | Autoscaled node pool, spot allowed, `activeDeadlineSeconds`, per-environment concurrency |
| Storage | Evidence lifecycle 90 days; results partitioned monthly; old partitions moved to cheaper storage class by export |
| Zephyr | Publish only configured priorities; batch and rate-limit aware |

Cost is shown per workflow (AI spend, run minutes, storage) on the workflow dashboard (R3) and available from `GET /workflows/{id}/costs` in the MVP.

## 18. Testing strategy and evaluation harness

Four test layers gate every merge; the evaluation harness is the fifth and gates every prompt, model or graph change.

| Layer | Scope | Tooling | Gate |
| --- | --- | --- | --- |
| Unit | Rule engine, coverage engine, contract validator, template renderer, state machines, masking, fingerprinting | pytest, property-based tests (Hypothesis) for schema generators over random OpenAPI fragments | 90% line coverage on `modules/design`, `modules/scripts`, `orchestration` |
| Integration | Repositories with RLS, outbox relay, Pub/Sub consumers, Secret Manager client, Git client | Testcontainers (Postgres 16 + pgvector), Pub/Sub emulator, fake Secret Manager, local bare Git repo | All pass |
| Contract | Platform OpenAPI vs Angular client and vs the UI testing product's client; Jira and Zephyr clients vs recorded responses | Schemathesis against the running API; VCR-style cassettes for external APIs | No breaking change without a version bump |
| End to end | Pilot API flow: upload spec → generate → approve → scripts → run on a kind cluster against a Prism mock of the pilot spec → report | Playwright for the Angular flow, kind + local runner image | Nightly and before release |
| Evaluation harness (R2) | Golden set of 3 to 5 internal APIs with approved cases and labeled failures | `ai/harness` runner with a recorded-response provider for PR checks and the live provider nightly | Thresholds below |

### Harness measures and thresholds

| Measure | Definition | Threshold to merge |
| --- | --- | --- |
| Contract validity | Generated cases passing the contract validator on first try | ≥ 95% |
| Coverage reached | Business-rule and response-code coverage after 3 rounds on the golden set | ≥ 90% each |
| Duplicate rate | Generated cases merged by dedup | ≤ 10% |
| Script pass rate | AI scenarios passing validation without repair | ≥ 80%; ≥ 95% after 2 repairs |
| Triage accuracy (R3) | Labeled failures classified correctly | ≥ 85% |
| Cost per API | Tokens for a golden API run through design and scripts | No more than 20% above the previous baseline |

A change that lowers any measure below threshold fails CI; a change that lowers one by more than 5 points from the baseline needs an explicit override in the PR with reason.

### Test data for the pilot

The `karate-reference` folder ships a synthetic "Claims" OpenAPI spec (members, claims, adjudication, Kafka `claims.adjudicated`) and a Prism mock with stateful examples; every layer above uses it, so no real environment is needed for CI.

## 19. MVP acceptance criteria and open decisions

The MVP is accepted when a QE completes the scenarios below on the pilot API in the product's staging environment without engineering help.

- [ ] Create a team, workflow, QA environment and two credential profiles (`default`, `member_b`); the secret value appears nowhere in the DB, logs or Git.
- [ ] Upload the pilot OpenAPI 3 spec and a Swagger 2 variant; both normalize; lint issues and target keys are listed; readiness report is green within 60 s.
- [ ] Re-upload a changed spec; the diff lists added, removed and changed targets, and the new suite carries unchanged approved cases with the same `case_id`.
- [ ] Discover shows the endpoint inventory, field catalog, explicit and heuristic edges with confidence, and the coverage universe.
- [ ] Generate produces rule-engine cases for all six dimensions; the coverage matrix meets every default threshold except business rules (no rules in MVP); every case passes contract validation.
- [ ] A 50-endpoint spec generates in under 60 s and yields at most the per-endpoint cap, with dropped cases shown as `capped` gaps.
- [ ] Review queue: filter by endpoint, dimension and confidence; bulk approve high confidence; edit a case with `If-Match`; a concurrent edit gets 409; reject with reason; a rejection that drops a dimension below threshold is shown immediately; approve blocked until P1 reviewed; QE lead accepts a gap.
- [ ] Script generation commits a Karate project to `test-assets` with tags per scenario; parse and static checks pass; an edited script is locked and survives regeneration with a `stale` flag.
- [ ] Run on QA: pre-flight passes, Kubernetes Job launches with pinned commit, results ingested, evidence masked (canary secret and a `sensitive` field), created resources cleaned, flaky retry recorded as `flaky`.
- [ ] A run against an unreachable environment ends as `env_not_ready` with one notification.
- [ ] Run report shows counts, matrix, failures grouped, blocked cases, change since previous run and drill-down; run record reproduces the run from its fields.
- [ ] Cross-team access returns 404 both through the API and through a direct SQL session with another `app.team_id`.
- [ ] CI deploy trigger with an API key starts a P1 run and coalesces duplicates within 60 s.
- [ ] All SLOs in section 17 are met during a 1-hour soak with 20 concurrent runs.

### Open decisions (owner: Advik; decide before the milestone that needs them)

| Decision | Options | Needed by | Recommendation |
| --- | --- | --- | --- |
| Zephyr flavour | Scale (native data rows, case keys) or Squad (tests are Jira issues) | R2 start | Confirm with the Jira admin in week one; the `TestManagement` interface isolates the choice |
| Jira hosting | Cloud or Data Center | R2 start | Determines auth (OAuth 2.0 3LO vs PAT) and webhook signing |
| API gateway for bulk import | Apigee, other, or none | R3 | Implement `SpecSource` for whatever exposes an export API |
| Company APM | Cloud Trace only, or existing vendor | Milestone 1 | OpenTelemetry exporter makes this a config change |
| Runner spot nodes | On or off for the runner pool | Milestone 8 | On for scheduled regression, off for manual and rerun-on-fix |
| Security test payload set | Internal AppSec list or OWASP benign probes | R2 | AppSec sign-off required before `security_tests_allowed` is offered |
| Vertex AI quota and region | Region for data residency, TPM quota | R2 start | Request quota for 2× the sizing estimate before R2 |
| Test assets repo split | One repo or per team | When permissions require | Start with one; split by team when a team asks for isolation |

Everything else in the solution design stands as decided: shared platform with the UI testing product, all-Python codebase with Java only in the runner, Gemini on Vertex AI, Stage 3 coverage thresholds as defaults, direct REST for Jira and Zephyr.
